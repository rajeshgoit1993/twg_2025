@extends('layouts.master')
@section('content')
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<!-- Content Header (Page header) -->
<!-- Main content -->
<section class="content">
<div class="row">
<div class="col-md-12">
<div class="panel panel-default">

<div class="panel-body">

  <a href="{{URL::to('/tours')}}" class="btn btn-success"><i class="glyphicon glyphicon-arrow-left"> </i> Back</a>
  <h3 class="box-title"> Package Gallery Management</h3>
<div class="collapse" id="UploadPhotos">
<div class="well well-sm">
<div class="modal-body">
	<div >

<form action="{{url('/packagefile_upload')}}"   enctype="multipart/form-data" method="POST">
            {{csrf_field()}}
<input type="hidden" name="package_id" value="{{Request::segment(2)}}">
<div class="row">
	<div class="col-md-1">Country: </div>
	<div class="col-md-6">

<select class="form-control" onchange="get_states(this)" name="country">
 			<option value='0'>Select Country</option>
                @foreach($countries as $cont)
    <option value="{{ $cont->name }}" c_id="{{ $cont->id }}" >{{ $cont->name }} 
    </option>
                @endforeach   
</select>



	</div>
</div>
<br>
<div class="row">
	<div class="col-md-1">State: </div>
	<div class="col-md-6">
		<select class="form-control st_values" id="" onchange="getcitys(this)" name="state">
 			    <option value='0'>Select State</option>
 		</select>
	</div>
</div>
<br>
<div class="row">
	<div class="col-md-1">City: </div>
	<div class="col-md-6">
		<select class="form-control ct_values"  name="city">
 			    <option value='0'>Select City</option>
 </select>
	</div>
</div>
<br>
<div class="row">
	<div class="col-md-1">Name: </div>
	<div class="col-md-6"><input type="text" name="name" placeholder="Image Name" class="form-control"></div>
</div>
<br>
<div class="row">
	<div class="col-md-1">Choose Image: </div>
	<div class="col-md-6"><input type="file" name="uploadimage[]" multiple class="form-control"></div>
</div>
<br>
<div class="row">
	<div class="col-md-1"></div>
	<div class="col-md-6"><button class="btn btn-success">Save</button></div>
</div>

</form>
                                       
</div>
</div>
</div>
</div>

<a class="btn btn-success" data-toggle="collapse" href="#UploadPhotos" aria-expanded="false" aria-controls="UploadPhotos">
<i class="fa fa-photo"></i> Add Photos From System
</a>
<a href="{{URL::to('package_image_location/'.Request::segment(2))}}"><button class="btn btn-success">Add Photos From Gallery</button></a>
<div class="clearfix"></div>
<table class="table table-striped table-hover">
<thead>
<tr>
	<th>ID</th>
<th class="" style="width: 100px">
Image
</th>
<th class=" text-center">Country</th>
                                  
<th class=" text-center">State</th>
<th class=" text-center">City</th>
<th class=" text-center">Name</th>
<th class= text-center">Action</th>
</tr>
</thead>
<tbody>
<input id="hotelid" value="52" type="hidden">

 <?php
 $coun="1"
 ?>                             
@foreach($packageUpload  as $image) 

<tr id="tr_{{$image->id}}">
	<td>{{$coun++}}</td>
<td>
<a href="#" rel=""> 
@if(CustomHelpers::get_image_gallery($image->gallery_id,'thum_small')!="0")
<img src="{{CustomHelpers::get_image_gallery($image->gallery_id,'thum_small')}}" href="#" class="img-responsive">
@endif
</a>
</td>
<td style="padding:35px">
	@if(CustomHelpers::get_imgpath_gallery($image->gallery_id,'country')!="0")
<span class="" id="">
  {{CustomHelpers::get_imgpath_gallery($image->gallery_id,'country')}}
 </span>
 @endif	
</td>
                              
<td style="padding:35px">
@if(CustomHelpers::get_imgpath_gallery($image->gallery_id,'state')!="0")
<span class="" id="">
  {{CustomHelpers::get_imgpath_gallery($image->gallery_id,'state')}}
 </span>
 @endif	
</td>
<td style="padding:35px">
@if(CustomHelpers::get_imgpath_gallery($image->gallery_id,'city')!="0")
<span class="" id="">
  {{CustomHelpers::get_imgpath_gallery($image->gallery_id,'city')}}
 </span>
 @endif	
</td>
<td style="padding:35px">
@if(CustomHelpers::get_imgpath_gallery($image->gallery_id,'name')!="0")
<span class="" id="">
  {{CustomHelpers::get_imgpath_gallery($image->gallery_id,'name')}}
 </span>
 @endif	
</td>
<td style="padding:35px">
<!--<a href="{{URL::to('/edit_package_image/'.$image->id.'/'.$image->package_id)}}"><button class="btn btn-success " > Edit </button></a>-->
<a href="{{URL::to('/edit_package_gallery_image/'.$image->gallery_id.'/'.$image->package_id.'/'.$image->id)}}"><button class=" btn-success " > Edit </button></a>
<form style="display: inline;" action="{{URL::to('/packagefiledelete/'.$image->id.'/'.$image->package_id)}}" onsubmit="return confirm('Do you really want to delete this.?');" method="POST">
                                     {{csrf_field()}}

<button type="submit" class=" btn-danger  btn-md deleteImg" id="{{$image->id}}" name=""> Delete </button>

</form>
</td>
</tr>

@endforeach




</tbody>
</table>
</div>
</div>
</div>
</div>
</section>
<!-- /.content -->

</div>

<!-- /.content-wrapper -->
@endsection