@extends('layouts.master')
@section('content')
<style type="text/css">
.custom_sor .dt-buttons {
	display: none;
	}
td img {
	width: 125px;
    height: 70px !important;
    border-radius: 3px;
	}
tr th {
	padding-right: 10px !important;
	}
.tableFullWidth {
	width: 100% !important;
	}
.dSearchTourPanel {
    padding: 20px;
    background: #e9e9e9;
    margin-bottom: 10px;
    border-radius: 5px;
    }
.dTourPkgName {
	font-size: 13px;
    line-height: 15px;
    font-weight: 500;
    /*color: #269abc;*/
    color: #000001;
    display: flex;
    flex-wrap: wrap;
    }
.dBtnUp {
	font-size: 13px;
	line-height: 13px;
	font-weight: 500;
	color: #4a4a4a;
	background: #fff;
	padding: 5px 10px;
	}
</style>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<!-- Content Header (Page header) -->
<!-- Main content -->
<section class="content">
	<div class="row">
		<div class="col-md-12">
			<!--Search Package-->
			<div class="card dSearchTourPanel">
				<div class="row">
					<div class="col-md-3">
							<select id="country" class="form-control addcountry" name="choosecountry">
								<option value=''>Select Country</option>
								@foreach($pac_countries as $row=>$col)
								<option value="{{$col}}">{{ $col }}</option>
								@endforeach
							</select>
					</div>
					<div class="col-md-3">
						<select id="state" class="form-control addstate" name="choosestate">
							<option value=''>Choose State</option>
						</select>
					</div>
					<div class="col-md-3">
						<select id="city" class="form-control addcity" name="choosecity">
							<option value=''>Choose City</option>
						</select>
					</div>
					<div class="col-md-2">
						<button class="btn btn-success btn-block find">Search Package</button>
					</div>
				</div>
			</div>
			<!--Search Package Ends-->
			<div class="box">
				<div class="box-header">
					<h3 class="box-title">Tour Package List</h3>
				</div>
				<!-- /.box-header -->
				<div class="box-body custom_sor">
					<div class="alert alert-success success-contaier-parent-hotel" id="success-contaier-parent-hotel" style="display:none">
						<p>Package Deleted Successfully</p>
					</div>
					<div class="alert alert-danger error-contaier-parent-hotel" id="error-contaier-parent-hotel" style="display:none">
						<ul class="error-contaier-hotel" id="error-contaier-hotel"> </ul>
					</div>
					<table id="example2" class="table table-bordered table-striped example2 tableFullWidth">
						<div class="row">
							<div class="col-md-8">
							@if(Sentinel::check())
							@if(Sentinel::getUser()->inRole('administrator') || Sentinel::getUser()->inRole('supervisor') || Sentinel::getUser()->inRole('super_admin'))
								<div class="add">
									<a href="{{ URL::to('/add-package') }}" class="btn btn-success"><i class="glyphicon glyphicon-plus-sign"></i> Add New Package</a>
								</div>
							@endif
							@endif
							</div>
							<div class="col-md-4">
								<!-- <input type="text" id="packages_searchs" class="form-control" name="" placeholder="Search... By Package Name or Country"> -->
							</div>
						</div>
						
						<thead>
							<tr>
								<th>S. No.</th>
								<th width= "125">Image</th>
								<th style="min-width: 225px">Package Name</th>
								<th style="min-width: 75px">No of Days</th>
								<th style="min-width: 75px">Price</th>
								<th>Destination</th>
								@if(Sentinel::check())
								@if(Sentinel::getUser()->inRole('administrator') || Sentinel::getUser()->inRole('supervisor') || Sentinel::getUser()->inRole('super_admin'))
								<th>Supplier Name </th>
								<th width= "65px">Image Upload</th>
								@endif
								@endif
								@if(Sentinel::check())
								@if(Sentinel::getUser()->inRole('administrator') || Sentinel::getUser()->inRole('super_admin'))
								<th style="min-width: 100px;padding-right: 0">Second Page Package Status</th>
								<th style="min-width: 100px;padding-right: 0">First Page Package Status</th>
								@endif
								@endif
								<th style="min-width: 180px">Actions</th>
							</tr>
						</thead>
						<tbody></tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
@endsection
@section("custom_js_code")



<script type="text/javascript">
$(document).on("click",".deletePackage",function(e) {
	e.preventDefault()
	var user_choice = window.confirm('Are you sure, you want to remove this package? Package once removed cannot be recovered.');
	var delete_id=$(this).attr("id")
	if(user_choice==true) {
		document.getElementById(delete_id).submit()
		}
	else {
		return false;
		}
	})
//
// 	$(document).on("click",".package_list_paginate .pagination a",function(e){
// e.preventDefault()
// var page=$(this).attr('href').split('page=')[1];
// fetch_datas(page);
// })
//
//
// $(document).on("click",".details",function(){
//    $(this).siblings("form").attr('target', '_blank')
//      $(this).siblings("form").submit()
// })
//
$(document).on("change",".addcountry",function() {
	var addcountry=$(this).val();
	$.ajax({
		type:'get',
		url: APP_URL+'/addcountry',
		// dataType: 'json',
		data: {addcountry:addcountry},
		success:function(data){
			$(".addstate").html('').html(data)
			$(".addcity").html('')
			},
		error: function (data) {
			//console.log('Error : '+data);
			}
		});
	})
$(document).on("change",".addstate",function() {
	var addcountry=$(".addcountry").val();
	var addstate=$(this).val();
	$.ajax({
		type:'get',
		url: APP_URL+'/addstate',
		// dataType: 'json',
		data: {addcountry:addcountry,addstate:addstate},
		success:function(data) {
			$(".addcity").html('').html(data)
			// $(".addcity").html('')
			},
		error: function (data) {
			//console.log('Error : '+data);
			}
		});
	})
	//
$(document).on("click",".up",function() {
	var pak_id=$(this).val();
	$.ajax({
		type:'get',
		url: APP_URL+'/up_package',
		// dataType: 'json',
		data: {pak_id:pak_id},
		success:function(data) {
			fetch_datas('nochange')
			},
		error: function (data) {
			//console.log('Error : '+data);
			}
		});
	})
$(document).ready(function() {
	fetch_datas('change')
	})
$(document).on("click",".find",function() {
	var country=$("#country").val()
	if(country=='') {
		alert('Kindly Select Country')
		}
	else {
		fetch_datas('change')
		}
	})
function fetch_datas($statesave) {
	var country=$("#country").val()
	if(country=='') {
		var country='NA';
		}
	var state=$("#state").val()
	if(state=='') {
		var state='NA';
		}
	var city=$("#city").val()
	if(city=='') {
		var city='NA';
		}
	if ($.fn.DataTable.isDataTable('#example2')) {
		$('#example2').DataTable().destroy()
		}
	var table = $('#example2').DataTable({
		processing: true,
		serverSide: true,
		stateSave: $statesave,
		ajax: {
			url: "{{ route('package_lists') }}",
			data: {country:country,city:city,state:state},
			},
		columns: [
				{data: 'DT_Row_Index', name: 'DT_Row_Index',orderable: false, },
				{data: 'image', name: 'image'},
				{data: 'package_name', name: 'title'},
				{data: 'no_of_days', name: 'duration'},
				{data: 'price', name: 'price'},
				{data: 'destination', name: 'country'},
				{data: 'supply_name', name: 'supply_name'},
				{data: 'image_upload', name: 'image_upload'},
				{data: 'package_status', name: 'package_status'},
				{data: 'front_show', name: 'front_show'}, {
					data: 'action',
					name: 'action',
					orderable: true,
					searchable: true
					},
				],
		});
	}
</script>
@endsection