@extends('layouts.master')
@section('content')
  <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!-- Main content -->
<section class="content">
<div class="row">
<div class="col-md-12">
<div class="box">
<div class="box-header">
<h3 class="box-title">Destination Management</h3>
</div>
<!-- /.box-header -->
<div class="box-body">
@if(Session::has('success'))
<div class="alert alert-warning alert-dismissible" role="alert">
<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
{{Session::get('success')}}
</div>
@endif
<table  class="table table-bordered table-striped ">
	<div class="row">
	<div class="col-md-8">
     @if(Sentinel::check())
 @if(Sentinel::getUser()->inRole('administrator') || Sentinel::getUser()->inRole('supervisor') || Sentinel::getUser()->inRole('super_admin'))
	<div class="add">
<a href="{{URL::to('/package-locations-create')}}" class="btn btn-success"><i class="glyphicon glyphicon-plus-sign"></i> Add New Destination</a>
</div>
@endif
@endif
</div>
<div class="col-md-4">
	<input type="text" id="location_searchs" class="form-control" name="" placeholder="Search... By City or Country">
</div>
	
</div>


<thead>
<tr>
<th>S.No.</th>
<!-- <th>#</th> -->
<th>Country</th>
<th>State</th>
<th>City</th>

<th>Currency</th>
<th>Status</th>
<th>Actions</th>
</tr>
</thead>
<?php
 $count="1";
 ?>
<tbody id="location_dynamic_data">
                
@foreach($locations as $key=>$loc) 
<tr>
<td>{{$count++}}</td>
<td>{{$loc->country}}</td>
<td>{{$loc->state}}</td>               
<td>{{$loc->location}}</td>

<td>{{$loc->currency}}</td>
<td>
 @if($loc->status == 1)
<button type="button" class=" btn-success location_btn_enable" value="{{$loc->id}}">Disable</button>
@else
<button type="button" class=" btn-danger location_btn_enable" value="{{$loc->id}}">Enable</button>
@endif


</td>
<td>
   @if(Sentinel::check())
 @if(Sentinel::getUser()->inRole('administrator')  || Sentinel::getUser()->inRole('super_admin'))
<form action="{{URL::to('/location-delete')}}" id="packagedel{{$loc->id}}" method="POST">
	{{csrf_field()}}
	<input type="hidden" name="id" value="{{$loc->id}}"/>
</form>
@endif
@endif
<span class="btn-group">


<button class="btn btn-warning"><a href="{{ URL::to('/package-locations-edit/'.$loc->id) }}" style="color: white">Edit</a></button>
	


@if(Sentinel::check())
 @if(Sentinel::getUser()->inRole('administrator')  || Sentinel::getUser()->inRole('super_admin'))
<button id="packagedel{{$loc->id}}" class="btn btn-danger deletePackage" >Delete</button>
@endif
@endif
</span>

</td>
</tr>
@endforeach
<tr>
  <td colspan="7">
    <div class="location_list_paginate" style="text-align: center;">
  {{ $locations->links() }}

</div>

  </td>
</tr>
</tbody>
</table>
</div>
<!-- /.box-body -->
</div>
</div>
</div>
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
@endsection


@section("custom_js_code")
<script type="text/javascript">

	$(document).on("click",".deletePackage",function(e){
		e.preventDefault()
var user_choice = window.confirm('Would you like to continue?');
var delete_id=$(this).attr("id")
if(user_choice==true) {


document.getElementById(delete_id).submit()


} else {


return false;


}
		

	})
	//
	$(document).on("click",".location_list_paginate .pagination a",function(e){
e.preventDefault()

var page=$(this).attr('href').split('page=')[1];
fetch_datas(page);
})
	//
	
 function fetch_datas(page)
{
  $("#location_dynamic_data").html("").html('<div class="loading" style="" ></div>')
       
       var APP_URL = $('#baseurl').val();    
       var key=$("#location_searchs").val();
     
        $.ajax({
        type:'get',
        url: APP_URL+"/location_list_filter_data?page="+page,
        data: {key:key},
        cache: false,          
        success:function(data)
        {
        $("#location_dynamic_data").html("").html(data)
      
       },
       error:function()
       {

       }
       })
       
}
//
$(document).on("keyup","#location_searchs",function(){

    fetch_data();
    
})

//
 function fetch_data()
{
  $("#location_dynamic_data").html("").html('<div class="loading" style="" ></div>')
       
       var APP_URL = $('#baseurl').val();    
       var key=$("#location_searchs").val();
      
        $.ajax({
        type:'get',
        url: APP_URL+"/location_list_filter_data",
        data: {key:key},
        cache: false,       
        success:function(data)
        {
        $("#location_dynamic_data").html("").html(data)
      
       },
       error:function()
       {

       }
       })
       
}
</script>
@endsection