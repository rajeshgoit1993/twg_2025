@extends('layouts.master')
@section('content')
<style>

.dayItinerary{
border-bottom: 1px solid darkgray;
margin-bottom: 14px;
border-radius: 23px;
}
span.select2.select2-container {
width: 100% !important;
}
</style>
<div class="content-wrapper">

<section class="content">
<div class="row">
<div class="col-md-12">

<div class="panel panel-default">
<div class="panel-body">
<div class="modal-body_main">
<a href="{{URL::to('/tours')}}" class="btn btn-success"><i class="glyphicon glyphicon-arrow-left"> </i> Back</a>

<!--<button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bs-example-modal-lg">Add in Bulk</button>-->
<div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
<div class="modal-dialog modal-lg">
<div class="modal-content">

<div class="modal-body">
<h4>Choose a file to upload</h4>
<h3>Instructions</h3>
<div class="control-group" style="width: 24%;margin: 0 auto;">
<div class="controls">
<input id="filebutton" name="filebutton" class="input-file" type="file">
</div>
</div>
<br>
<div class="control-group">
<div class="controls">
<button id="singlebutton" name="singlebutton" class="btn btn-info">Upload</button>
</div>
</div>
<br>

<ol>
<li>To see format & possible values while uploading your deals, please <b><a href="#"> download format sheet</a></b> </li>
<li>Fill the details of your deals in excel sheet & save the excel sheet.</li>
<li>Click on <b>Browse</b> button & select the excel file.</li>
<li>Click on <b>Submit</b> to post your deals.</li>
</ol>
</div>
</div>
</div>
</div>
</div>
<br><br>
<div id="content">
<ul id="tabs" class="nav nav-tabs" data-tabs="tabs">
<li class="active">
<a href="#red" data-toggle="tab">Customized Holidays</a>
</li>

<!--  <li>
<a href="#orange" data-toggle="tab">Hotel Package
</a>
</li>
<li>
<a href="#yellow" data-toggle="tab">Group Tour / Shared Tour
</a>
</li> -->
</ul>
<div id="my-tab-content" class="tab-content">
<div class="tab-pane active" id="red">
@if($packagesData->type_of_package != 'Hotel Package')
<input type="hidden" id="package_country" value="{{implode(',',$packagesData->country)}}">

@endif  
@if ($errors->any())
<div class="alert alert-warning">
<ul>
@foreach ($errors->all() as $error)
<li>{{ $error }}</li>
@endforeach
</ul>
</div>
@endif
<!--New Edit Template-->
<div class="col-md-12">
<form action="{{URL::to('/store-package')}}" method="post" >
<input type="hidden" name="type" value="{{$packagesData->type_of_package}}"/>
<input type="hidden" name="id" value="{{$packagesData->id}}"/>
{{csrf_field()}}
<br>
<!---->
<ul class="nav nav-tabs">
<li class="active"><a data-toggle="tab" href="#Info"><span class="glyphicon glyphicon-file">
</span> Package Info</a></li>
<li><a data-toggle="tab" href="#Description"><span class="glyphicon glyphicon-th-list">
</span> Description</a></li>
<li><a data-toggle="tab" href="#Overview"><span class="glyphicon glyphicon-th-list">
</span> Overview</a></li>
<li><a data-toggle="tab" href="#accommodation"><i class="fa fa-calendar-check-o" aria-hidden="true"></i> Accommodation</a></li>
<li><a data-toggle="tab" href="#Itinerary"><i class="fa fa-calendar-check-o" aria-hidden="true"></i> Tour Itinerary</a></li>
<li><a data-toggle="tab" href="#Pricing"><i class="fa fa-inr" aria-hidden="true"></i> Pricing</a></li>
<li><a data-toggle="tab" href="#Supplier"><i class="fa fa-suitcase" aria-hidden="true"></i> Supplier </a></li>
@if(Sentinel::check())
 @if(Sentinel::getUser()->inRole('super_admin'))
<li><a data-toggle="tab" href="#META"><i class="fa fa-database" aria-hidden="true"></i> SEO </a></li>
@endif
@endif
<li><a data-toggle="tab" href="#Additional"><span class="glyphicon glyphicon-th-list">
</span> Additional </a></li>

</ul>

<div class="tab-content">
<div id="Info" class="tab-pane fade in active">
<div class="row">
<div class="col-md-12">

<div class="col-md-4 form-group">
<label for="duration">Duration</label>
<select name="duration" id="package_durations" class="form-control val">
@for($i=1;$i<=30;$i++)
@if($i==$packagesData->duration)
<option value="{{ $packagesData->duration }}" selected="selected" >
{{ $packagesData->duration }} Night/{{ ($packagesData->duration)+1 }} Days 
</option>     
@else
<option value="{{$i}}">{{ $i }} Night / {{$i+1}} Days</option>               
@endif;



@endfor;



</select>
</div>

<div class="col-md-4 form-group">
<label for="package_name">Title</label>
<input type="text" placeholder="Title" value="{{$packagesData->title}}" name="package_name" class="form-control">
</div>
<div class="col-md-4 form-group">
<label for="package_name">Tour Type</label>
<select name="tour_type" id="tour_type" class="form-control">

<option value="Customized Tour" @if($packagesData->tour_type=='Customized Tour') selected @endif>Customized Tour</option>
<option value="Group Tour" @if($packagesData->tour_type=='Group Tour') selected @endif>Group Tour</option>


</select>
</div>

<div class="col-md-6 form-group">
<label for="package_category">Theme</label>

<select name="package_category[]" placeholder="Theme" id="package_category" class="select2 form-control" multiple>

@foreach($types as $typ)
@if(empty($packagesData->package_category))
<option value="{{$typ->name}}">{{$typ->name}}
</option>
@else
<option value="{{$typ->name}}" @if(in_array($typ->name,$packagesData->package_category) ) selected="selected" @endif >{{$typ->name}}
</option>
@endif

@endforeach                         

</select>                                     



</div>


<div class="col-md-6 form-group">
<label for="package_location">Services</label>
<div class="input-group" style="margin-bottom:5px;">
<span class="input-group-addon">
<i class="fa fa-map-marker"></i>
</span>                                     

<select name="package_service[]" id="package_service" class="form-control select2" multiple>
@if(count($icons)>0)

@if($packagesData->package_service!="")
@foreach($icons as $icon)
<option value="{{$icon->icon_title}}" @if(in_array($icon->icon_title,$packagesData->package_service) ) selected="selected" @endif>{{$icon->icon_title}}  </option>
@endforeach  
@else
@foreach($icons as $icon)
<option value="{{$icon->icon_title}}">{{$icon->icon_title}}  </option>
@endforeach  

@endif  
@else
<option value="No Result Found">No Result Found</option>

@endif

</select>

</div>

</div>



<?php
$count=count($packagesData->country);
//dd($packagesData->continent[0]);
use App\State;
use App\City;


?>

<div class="" id="dynamic_field_package">
@for($i=1;$i<=$count;$i++)
<?php
$a=($i-1);

$continent=$packagesData->continent[$a];
$country=$packagesData->country[$a];
$state=$packagesData->state[$a];
$city=$packagesData->city[$a];
$days=$packagesData->days[$a];
$days_duration=$packagesData->duration;
$states=State::where('name',$state)->get();
$country_id="";
foreach ($states as $stat) 
{
$country_id=$stat->country_id;
}
$states1=State::where('country_id',$country_id)->get();

$city1=City::where('name',$city)->get();


$state_id="";
foreach ($city1 as $cit) 
{
$state_id=$cit->state_id;
}
$city2=City::where('state_id',$state_id)->get();

?>
<div class="row remove">
<div class="col-md-12">

<div class="col-md-2 form-group">
<label for="continent">Continent</label>
<select name="continent[{{$a}}]"  id="continent" class="form-control">
<option value="Asia" @if($continent=='Asia') selected="selected" @endif>Asia</option>
<option value="Africa" @if($continent=='Africa') selected="selected" @endif>Africa</option>  
<option value="Antarctica"  @if($continent=='Antarctica') selected="selected" @endif>Antarctica</option>
<option value="Australia"  @if($continent=='Australia') selected="selected" @endif >Australia</option>
<option value="Europe"  @if($continent=='Europe') selected="selected" @endif>Europe</option>
<option value="North America"  @if($continent=='North America') selected="selected" @endif>North America</option>
<option value="South America"  @if($continent=='South America') selected="selected" @endif>South America</option>           

</select>
</div>
<div class="col-md-2 form-group">
<label for="country">Country</label>
<select name="country[{{$a}}]" id="package_dest_countries{{$a}}" class="form-control package_dest_country" onchange="myFunction(this)" >
<option value=''>Select Country</option>
@foreach($countries as $cont)
@if($cont->name==$country)
<option value="{{ $cont->name }}" selected="selected" c_id="{{ $cont->id }}">{{ $cont->name }} </option>
@else
<option value="{{ $cont->name }}" c_id="{{ $cont->id }}">{{ $cont->name }} </option>
@endif
@endforeach                   
</select>
</div>
<div class="col-md-2 form-group">
<label for="state">State</label>
<select name="state[{{$a}}]" id="package_dest_state{{$a}}" class="form-control package_dest_countries{{$a}}" onchange="sateFunction(this)">
<option value=''>Select State</option>
@foreach($states1 as $state_name)
@if($state_name->name==$state)
<option value="{{ $state_name->name }}" selected="selected" s_id="{{ $state_name->id }}">{{ $state_name->name }} </option>
@else
<option value="{{ $state_name->name }}" s_id="{{ $state_name->id }}">{{ $state_name->name }} </option>
@endif
@endforeach  



</select>

</div>
<div class="col-md-2 form-group">
<label for="city">City</label>
<select name="city[{{$a}}]" id="package_dest_city" class="form-control package_dest_state{{$a}} city_package_dest_countries{{$a}} min-select" onchange="cityFunction(this)">
<option value=''>Select City</option>
@foreach($city2 as $city_name)
@if($city_name->name==$city)
<option value="{{ $city_name->name }}" selected="selected">{{ $city_name->name }} </option>
@else
<option value="{{ $city_name->name }}">{{ $city_name->name }} </option>
@endif
@endforeach  

</select>

</div>
<div class="col-md-2 form-group">
<label for="city">No. Of Days/Nights</label>
<select name="days[{{$a}}]" id="package_dest_days" class="form-control package_dest_days ">
@for($day_value=1;$day_value<=$days_duration;$day_value++)
@if($day_value==$days)
<option value="{{ $day_value }}" selected="selected" >
{{ $day_value }} Night/{{ ($day_value)+1 }} Days 
</option>     
@else
<option value="{{ $day_value }}"> {{ $day_value }} Night/{{ ($day_value)+1 }} Days </option>               
@endif;

@endfor
</select>                         
</div> 
@if($i!=1)                                 
<div class='col-md-2 form-group'><button type='button' name='add-continent' id='remove-continent-row' class='btn btn-danger remove-continent-row' style='margin:18px 10px 0px 0px'>Remove</button></div>

@endif  





</div>
</div>

@endfor

</div> 
<button type="button" name="add-continent" id="add-continent-row" class="btn btn-success"
style="margin-left:15px">Add More </button>                          

</div>
</div>
</div>
<!---->
<div id="Description" class="tab-pane fade">
<div class="row">

<div class="col-md-12">
<div class="form-group">
<label for="">Package Description</label>
<textarea class="form-control ckeditor" placeholder="Package Description..." name="description" id="" cols="30" rows="5" >{{$packagesData->description}}</textarea>
</div>
<div class="form-group">
<label for="">Tour Highlights</label>
<textarea class="form-control ckeditor"  
name="highlights" id="" cols="30" rows="5" >{{$packagesData->highlights}}</textarea>
</div>


<br>
</div>  




</div>
</div>
<div id="Overview" class="tab-pane fade">
<div class="row">

<div class="col-md-12">


<div class="form-group">
<label for="">Transport</label>
<select name="transport" id="transport" class="form-control">
<option value="0">--Choose Transport--</option>
@foreach($transport as $trans) 
@if($trans->name==$packagesData->transport)
<option value="{{ $trans->name }}" selected="selected">{{$trans->name}}</option>
@else
<option value="{{ $trans->name }}">{{$trans->name}}</option>        
@endif
@endforeach   
</select> 

</div>

@if($packagesData->transport=="Flight")

<div class="oflight" style="display: none;">
<textarea class="form-control" placeholder="Package Transport Description..." name="transport_description" id="" cols="30" rows="5">{{ old('transport_description') }}</textarea>

<br>

</div>


<div class="flight">
<div class="col-md-12"><h4>UP</h4></div>
<div class="col-md-4">
<label>Flight Name</label>
<input type="text" name="flight[name]" class="form-control" @if($packagesData->flight['name']!="") value="{{$packagesData->flight['name']}}" @endif>
</div>
<div class="col-md-4">
<label>Flight No.</label>
<input type="text" name="flight[no]" class="form-control" @if($packagesData->flight['no']!="") value="{{$packagesData->flight['no']}}" @endif>
</div>
<div class="col-md-4">
<label>No. Of Stop</label>
<input type="text" name="flight[numberstop]" class="form-control" @if($packagesData->flight['numberstop']!="") value="{{$packagesData->flight['numberstop']}}" @endif>
<br>
</div>

<div class="col-md-3">
<label>Flight Origin</label>
<input type="text" name="flight[Origin]" class="form-control" @if($packagesData->flight['Origin']!="") value="{{$packagesData->flight['Origin']}}" @endif> 
</div>
<div class="col-md-3">
<label>Departure Time</label>
<input type="text" name="flight[dtime]" class="form-control" @if($packagesData->flight['dtime']!="") value="{{$packagesData->flight['dtime']}}" @endif>
</div>
<div class="col-md-3">
<label>Destination</label>
<input type="text" name="flight[dest]" class="form-control" @if($packagesData->flight['dest']!="") value="{{$packagesData->flight['dest']}}" @endif>
</div>
<div class="col-md-3">
<label>Arrival Time</label>
<input type="text" name="flight[atime]" class="form-control" @if($packagesData->flight['atime']!="") value="{{$packagesData->flight['atime']}}" @endif>
<br>
</div>

<!---->
<div class="col-md-12"><h4>Down</h4></div>
<div class="col-md-4">
<label>Flight Name</label>
<input type="text" name="flight[dname]" class="form-control" @if(array_key_exists("dname",$packagesData->flight) && $packagesData->flight['dname']!="") value="{{$packagesData->flight['dname']}}" @endif>
</div>
<div class="col-md-4">
<label>Flight No.</label>
<input type="text" name="flight[dno]" class="form-control"  @if(array_key_exists("dno",$packagesData->flight) && $packagesData->flight['dno']!="") value="{{$packagesData->flight['dno']}}" @endif>
</div>
<div class="col-md-4">
<label>No. Of Stop</label>
<input type="text" name="flight[dnumberstop]" class="form-control"  @if(array_key_exists("dnumberstop",$packagesData->flight) && $packagesData->flight['dnumberstop']!="") value="{{$packagesData->flight['dnumberstop']}}" @endif>
<br>
</div>

<div class="col-md-3">
<label>Flight Origin</label>
<input type="text" name="flight[dOrigin]" class="form-control"  @if(array_key_exists("dOrigin",$packagesData->flight) && $packagesData->flight['dOrigin']!="") value="{{$packagesData->flight['dOrigin']}}" @endif> 
</div>
<div class="col-md-3">
<label>Departure Time</label>
<input type="text" name="flight[ddtime]" class="form-control"  @if(array_key_exists("ddtime",$packagesData->flight) && $packagesData->flight['ddtime']!="") value="{{$packagesData->flight['ddtime']}}" @endif>
</div>
<div class="col-md-3">
<label>Destination</label>
<input type="text" name="flight[ddest]" class="form-control"  @if(array_key_exists("ddest",$packagesData->flight) && $packagesData->flight['ddest']!="") value="{{$packagesData->flight['ddest']}}" @endif>
</div>
<div class="col-md-3">
<label>Arrival Time</label>
<input type="text" name="flight[datime]" class="form-control"  @if(array_key_exists("datime",$packagesData->flight) && $packagesData->flight['datime']!="") value="{{$packagesData->flight['datime']}}" @endif>
<br>
</div>

</div>




@else
<div class="oflight">
<textarea class="form-control" placeholder="Package Transport Description..." name="transport_description" id="" cols="30" rows="5">{{$packagesData->transport_description}}</textarea>
<br>

</div>

<!---->
<div class="flight" style="display: none;">
<div class="col-md-12"><h4>UP</h4></div>
<div class="col-md-4">
<label>Flight Name</label>
<input type="text" name="flight[name]" class="form-control">
</div>
<div class="col-md-4">
<label>Flight No.</label>
<input type="text" name="flight[no]" class="form-control">
</div>
<div class="col-md-4">
<label>No. Of Stop</label>
<input type="text" name="flight[numberstop]" class="form-control">
<br>
</div>

<div class="col-md-3">
<label>Flight Origin</label>
<input type="text" name="flight[Origin]" class="form-control"> 
</div>
<div class="col-md-3">
<label>Departure Time</label>
<input type="text" name="flight[dtime]" class="form-control">
</div>
<div class="col-md-3">
<label>Destination</label>
<input type="text" name="flight[dest]" class="form-control">
</div>
<div class="col-md-3">
<label>Arrival Time</label>
<input type="text" name="flight[atime]" class="form-control">
<br>
</div>
<!---->
<div class="col-md-12"><h4>Down</h4></div>
<div class="col-md-4">
<label>Flight Name</label>
<input type="text" name="flight[dname]" class="form-control">
</div>
<div class="col-md-4">
<label>Flight No.</label>
<input type="text" name="flight[dno]" class="form-control">
</div>
<div class="col-md-4">
<label>No. Of Stop</label>
<input type="text" name="flight[dnumberstop]" class="form-control">
<br>
</div>

<div class="col-md-3">
<label>Flight Origin</label>
<input type="text" name="flight[dOrigin]" class="form-control"> 
</div>
<div class="col-md-3">
<label>Departure Time</label>
<input type="text" name="flight[ddtime]" class="form-control">
</div>
<div class="col-md-3">
<label>Destination</label>
<input type="text" name="flight[ddest]" class="form-control">
</div>
<div class="col-md-3">
<label>Arrival Time</label>
<input type="text" name="flight[datime]" class="form-control">
<br>
</div>

</div>


@endif
</div>  
<div class="col-md-5">
<div class="form-group">
<label for="">Customer Rating</label>
<select class=' form-control' name="customer_rating">
<option value="1" @if($packagesData->customer_rating=='1') selected="selected" @endif>1 Star </option>

<option value="2" @if($packagesData->customer_rating=='2') selected="selected" @endif>2 Star </option>

<option value="3" @if($packagesData->customer_rating=='3') selected="selected" @endif>3 Star </option>

<option value="3.5" @if($packagesData->customer_rating=='3.5') selected="selected" @endif>3.5 Star </option>

<option value="4" @if($packagesData->customer_rating=='4') selected="selected" @endif>4 Star  </option>

<option value="4.5" @if($packagesData->customer_rating=='4.5') selected="selected" @endif>4.5 Star  </option>

<option value="5" @if($packagesData->customer_rating=='5') selected="selected" @endif>5 Star </option>

</select>                                      

</div>
</div>

<div class="col-md-5">
<div class="form-group select-container">                                       
<label >Tours</label>

<select class='select2 form-control' name="tours[]" multiple id="tour_add">
@foreach($PkgTours as $key=>$tour)
@if(empty($packagesData->tours))
<option value='{{$tour->id}}'>{{$tour->activity}} </option>

@else
<option value='{{$tour->id}}' @if(in_array($tour->id, $packagesData->tours)) selected="selected" @endif>{{$tour->activity}} </option>
@endif
@endforeach 





</select>                                    
</div>                                  
</div>
<div class="custom_tour_parent">
<div class="col-md-2">

<button data-toggle="modal" data-target="#packagetour_custom " class="btn-success btn-sm custom_tour" style="margin-top: 18px;margin-left: 40px">Add Tour</button>
</div>

</div>
</div>
<div class="row">

<div class="col-md-12">
<div class="form-group select-container">
<label >Inclusions</label>
<textarea class="form-control ckeditor" name="inclusions" id="" cols="30" rows="5">{{$packagesData->inclusions}}</textarea>

</div>
</div>
<div class="col-md-12">
<div class=" form-group ">
<label >Exclusions</label>
<textarea class="form-control ckeditor" name="exclusions" id="" cols="30" rows="5">{{$packagesData->exclusions}}</textarea>

</div>
</div>

</div>

</div>
<!---->
<div id="accommodation" class="tab-pane fade">
  <div class="panel-body">
<div class="row">
<div class="col-md-12">
    <label class="radio-inline"><input type="radio" name="acc_type"  class="extra_acc" @if($Packages->acc_type=="normal_acc") checked  @endif value="normal_acc">Listed Accommodation</label>
<label class="radio-inline" ><input type="radio" name="acc_type" class="extra_acc" value="extra_acc" @if($Packages->acc_type=="extra_acc") checked  @endif>Unlisted Accommodation</label>


</div>
<?php
$option2_accommodation=unserialize($Packages->accommodation);
if(is_bool($option2_accommodation)):
$option2_accommodation_count="1";
else:
$option2_accommodation_count=count($option2_accommodation);

endif;
?>
<div class="col-md-12">
    <br>
<div class="accommodation_main" @if($Packages->acc_type=="normal_acc") style="display: block;" @else style="display: none;"  @endif >

    <?php
$days=$Packages->duration+1;
$days=(int)filter_var($days, FILTER_SANITIZE_NUMBER_INT);


?>

    <div class="dynamic_acc">
  <input type="hidden" name="" value="{{$days}}">
  @for($j=0;$j<$option2_accommodation_count;$j++)

  @if($j>0)
 <hr>
 @endif
<div class="field{{$j}}" id="{{$j}}">
<div class="row">
<div class="col-md-4">

<label>Select Days</label>

<select class="form-control select_day select2" multiple name="accommodation[{{$j}}][day][]">
@for($i=1;$i<=$days;$i++)
<option value="Day {{$i}}" @if($option2_accommodation!="" && array_key_exists("day",$option2_accommodation[$j]) && in_array("Day $i",$option2_accommodation[$j]["day"])) selected @endif>  Day {{$i}}</option>  
@endfor

</select>


</div>  
<div class="col-md-4">

<label>city</label>

<input type="text" name="accommodation[{{$j}}][city]" class="form-control query_city" placeholder="City" value="{{$option2_accommodation[$j]["city"]}}">

</div>  
<div class="col-md-4">

<label>Choose Hotel Manually or from TripAdvisor</label>

<select class="form-control" name="accommodation[{{$j}}][trip]">
<option value='0'  disabled='disabled'>--Select--</option>
<option value="Manually" @if($option2_accommodation[$j]["trip"]=="Manually") selected @endif>Manually</option>  
<option value="TripAdvisor" @if($option2_accommodation[$j]["trip"]=="TripAdvisor") selected @endif>TripAdvisor</option>  
</select>


</div>  
<div class="col-md-4">

<label>Choose Hotel</label>

<?php
$query_data_option2=CustomHelpers::get_quotation_hotel($option2_accommodation[$j]["city"]);
?>
<select class="form-control quo_hotel" name="accommodation[{{$j}}][hotel]">
 <option value='0' selected='true' disabled='disabled'>--Choose Hotel--</option>
 @foreach($query_data_option2 as $single)
 <option value='{{$single->id}}' @if($option2_accommodation!="" && array_key_exists("hotel",$option2_accommodation[$j]) && $single->id==$option2_accommodation[$j]["hotel"])  selected @endif>{{$single->hotelname}} </option>
 @endforeach                  
<option value="other" @if($option2_accommodation!="" && array_key_exists("hotel",$option2_accommodation[$j]) && $option2_accommodation[$j]["hotel"]=="other")  selected @endif>Other</option>
</select>


</div> 

@if($option2_accommodation!="" && array_key_exists("hotel",$option2_accommodation[$j]) && $option2_accommodation[$j]["hotel"]=="other")
<div class="col-md-4 other_hotel" style="display: block;">
<label>Enter Hotel</label>
  

  <input type="text" class="form-control" name="accommodation[{{$j}}][other_hotel]" placeholder="Hotel Name" value="{{$option2_accommodation[$j]["other_hotel"]}}">
</div>

@else
<div class="col-md-4 other_hotel" style="display: none;">
<label>Enter Hotel</label>
  

  <input type="text" class="form-control" name="accommodation[{{$j}}][other_hotel]" placeholder="Hotel Name">
</div>

@endif
<div class="col-md-4 add_star">

<label>Choose Star Rating</label>

<select class="form-control quo_star" name="accommodation[{{$j}}][star]">
<option selected='true' disabled='disabled'>--Select--</option>

@if($option2_accommodation!="" && array_key_exists("star",$option2_accommodation[$j]) && $option2_accommodation[$j]["star"]!="" && $option2_accommodation[$j]["star"]!="other")
<option value="{{$option2_accommodation[$j]["star"]}}" selected>{{$option2_accommodation[$j]["star"]}}</option>
@elseif($option2_accommodation!="" && array_key_exists("star",$option2_accommodation[$j]) && $option2_accommodation[$j]["star"]!="" && $option2_accommodation[$j]["star"]=="other")
<option value="other" selected>Other</option>
@endif
</select>


</div> 
@if($option2_accommodation!="" && array_key_exists("star",$option2_accommodation[$j]) && $option2_accommodation[$j]["star"]=="other")
<div class="col-md-4 other_star" style="display: block;">
<label>Enter Star Rating</label>
  

  <input type="text" class="form-control" name="accommodation[{{$j}}][star_other]" placeholder="Hotel Star Rating" value="{{$option2_accommodation[$j]["star_other"]}}">
</div>
@else
<div class="col-md-4 other_star" style="display: none;">
<label>Enter Star Rating</label>
  

  <input type="text" class="form-control" name="accommodation[{{$j}}][star_other]" value="{{$option2_accommodation[$j]["star_other"]}}" placeholder="Hotel Star Rating">
</div>

@endif
<div class="col-md-4">
<label>Room Category</label>
<input type="text" class="form-control" name="accommodation[{{$j}}][category]" placeholder="Room Category" value="{{$option2_accommodation[$j]["category"]}}">


</div>
<div class="col-md-4">
  <label>Hotel Website Link</label>
  <input type="text" class="form-control" name="accommodation[{{$j}}][hotel_link]" placeholder="Hotel Website Link" @if($option2_accommodation!="" && array_key_exists("hotel_link",$option2_accommodation[$j])) 

 value="{{$option2_accommodation[$j]["hotel_link"]}}"  @endif>

</div>
@if($j>0)
 
<div class="col-md-2"><button type="button" name="add" id="{{$j}}" class="remove_acco btn btn-danger" style="margin-top:23px">x Remove</button> </div>

@endif

</div>
</div>
  @endfor
</div>
<br>
<div class="row">
<div class="col-md-12">
<button type="button" name="add" id="add_acco_tours" days="{{$days}}" class="btn btn-success">Add More
</button> 
</div>
</div>

</div>

<div class="accommodation_extra" @if($Packages->acc_type=="extra_acc") style="display: block;" @else style="display: none;"  @endif >
<label for="">Extra Accommodation</label>
<textarea class="form-control ckeditor" rows="3" name="accommodation_extra" >{!! $Packages->accommodation_extra !!}</textarea>  


</div>

</div>  




</div>

</div>
</div>
<!---->
<div id="Itinerary" class="tab-pane fade">
<div class="panel-body c_body">
<div class="row">
<div class="col-md-12">
<div class="table-responsive">

<?php
$day_count=count($packagesData->day_itinerary);
//$ss=$packagesData->day_itinerary['day1'];
//dd($ss)
?>                                 
@for($i=1 ; $i<= $day_count ; $i++)
<div class="col-md-12 dayItinerary day1" >

<div class="row">
<label class="col-md-12">Day {{$i}} :
<input type="text" name="dayItinerary[day{{$i}}][title]" 
value="{{$packagesData->day_itinerary["day$i"]["title"]}}" style="height: 35px;width: 93%;margin-left: 1%;margin-bottom: 10px;padding: 0 10px;">

</label>

</div>

                                
<div class="row">
<div class="col-md-6"></div>
<div class="col-md-6"></div>

</div>
<div class="col-md-6">
<div class="form-group">
<label >Meal Plan</label>
<select name="dayItinerary[day{{$i}}][meal_plan]" class="form-control">
<option value="N" @if($packagesData->day_itinerary["day$i"]["meal_plan"]=="N") selected='selected' @endif>Select</option>
<option value="EP" @if($packagesData->day_itinerary["day$i"]["meal_plan"]=="EP") selected='selected' @endif>Room Only</option>

<option value="CP" @if($packagesData->day_itinerary["day$i"]["meal_plan"]=="CP") selected='selected' @endif > Breakfast </option>

<option value="lu" @if($packagesData->day_itinerary["day$i"]["meal_plan"]=="lu") selected='selected' @endif > Lunch </option>

<option value="di" @if($packagesData->day_itinerary["day$i"]["meal_plan"]=="di") selected='selected' @endif > Dinner </option>

<option value="bd" @if($packagesData->day_itinerary["day$i"]["meal_plan"]=="bd") selected='selected' @endif > Breakfast & Dinner </option>

<option value="bl" @if($packagesData->day_itinerary["day$i"]["meal_plan"]=="bl") selected='selected' @endif > Breakfast & Lunch </option>

<option value="ld" @if($packagesData->day_itinerary["day$i"]["meal_plan"]=="ld") selected='selected' @endif > Lunch & Dinner </option>

<option value="bld" @if($packagesData->day_itinerary["day$i"]["meal_plan"]=="bld") selected='selected' @endif > Breakfast & Lunch/Dinner  </option>

<option value="bldall" @if($packagesData->day_itinerary["day$i"]["meal_plan"]=="bldall") selected='selected' @endif > Breakfast, Lunch & Dinner </option>                                          

<option value="MAP" @if($packagesData->day_itinerary["day$i"]["meal_plan"]=="MAP") selected='selected' @endif> All Inclusive </option>

</select>                                       

</div>
</div>

<div class="col-md-6">
<div class=" form-group ">
<label >Included Tours</label>
<select class='select2 form-control dayItinerarytour custom_days' name="dayItinerary[day{{$i}}][tours][]" multiple>

@foreach($PkgTours as $key=>$tour)

@if(array_key_exists("tours",$packagesData->day_itinerary["day$i"]))
<option value="{{$tour->id}}" @if(in_array($tour->id , 
$packagesData->day_itinerary["day$i"]["tours"])) selected='selected' @endif>{{$tour->activity}}</option>
@else
<option value="{{$tour->id}}">{{$tour->activity}}</option>
@endif







@endforeach    



</select>
</div>
</div>  
<div class="col-md-12">
<div class="form-group">
<label for="">Description</label>
<textarea class="form-control ckeditor" rows="3" name="dayItinerary[day{{$i}}][desc]">
{{$packagesData->day_itinerary["day$i"]["desc"]}}
</textarea>
</div>
</div>


</div>
@endfor


</div>
</div>                   
</div>
</div>

</div>
<div id="Pricing" class="tab-pane fade">
<?php
$ss=$packagesData->pricing["0"];

//dd($ss)
?>
<div id="Pricing" >
<div class="panel-body">
<div class="row">
<div class="col-md-12">
<div class="form-group">
<label for="">Is On Request?</label>
<input type="checkbox"  @if($packagesData->onrequest == 1) checked  @endif value="1" name="onrequest" id="onrequest" />


<label for="" style="margin-left: 25px">Upcoming Package?</label>
<input type="checkbox"  @if($packagesData->upcoming == 1) checked  @endif value="1" name="upcoming" id="upcoming" />
</div>
<div class="form-group pricelistpackage"  @if($packagesData->onrequest == 1) style="display:none;"  @endif>

<div class="table-responsive">
<table class="table table-bordered" id="dynamic_field">
<tr>
<th>Price title</th>
<th><input name="Price_title" placeholder="Title.." class="form-control" type="text" value="{{$packagesData->Price_title}}"></th>

<th>Price type</th>
<th>

<select name="Price_type" class="form-control">
<option value="0">Select Type </option>
<option value="Per Person" @if($packagesData->Price_type=="Per Person") selected="selected" @endif >Per Person </option>
<option value="Per Group" @if($packagesData->Price_type=="Per Group") selected="selected" @endif>Per Group</option>

</select>
</th>
<th></th>
</tr>

<tr>
<th>Package Rating</th>
<th>Price from</th>
<th>Price to</th>
<th>Cut Off Point</th>
</tr>

<?php

$price_count=count($packagesData->pricing);
$priceing=$packagesData->pricing;
$pri=[];

foreach($priceing as $prices):
$pri[]=$prices;
endforeach;

$packagesData->pricing=$pri;   


?>
@for($i=1;$i<=$price_count;$i++)
<?php
$j=($i-1);
?>
<tr id="row{{$i}}">
<td>

<select name="Price[{{$j}}][package_rating]" id="rating" class="form-control" style="width: 90px">

@foreach($ratingType as $rtyp)

<?php
if(array_key_exists("package_rating",$packagesData->pricing["$j"])):
$rating_array=explode(" ",$packagesData->pricing["$j"]["package_rating"]);

endif;

?>               
<option value='{{$rtyp->id}}' @if(in_array($rtyp->id , $rating_array )) selected="selected" @endif >{{$rtyp->name}} </option>
@endforeach                      


</select>

</td>
<td>
<div class="input-group date">
<div class="input-group-addon">
<i class="fa fa-calendar"></i>
</div>
<input name="Price[{{$j}}][datefrom]" class="form-control pull-right datepicker"  type="text" value="{{ $packagesData->pricing["$j"]["datefrom"] }}">
</div>

</td>
<td>
<div class="input-group date">
<div class="input-group-addon">
<i class="fa fa-calendar"></i>
</div>
<input  name="Price[{{$j}}][dateto]" class="form-control pull-right datepicker" type="text" value="{{ $packagesData->pricing["$j"]["dateto"] }}">
</div>
</td>
<td>
<input type="number" name="Price[{{$j}}][cuttoffpoint]" class="form-control" placeholder="Cutt Off Days" @if(array_key_exists("cuttoffpoint",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["cuttoffpoint"] }}" @endif>
</td>                                             
<td>
<div class="c_price{{$j}}" id="c_price{{$j}}">

<input type="hidden" name="Price[{{$j}}][airfare_adult]" @if(array_key_exists("airfare_adult",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["airfare_adult"] }}" @endif class="air_fare_adult">


<input type="hidden" name="Price[{{$j}}][airfare_exadult]" @if(array_key_exists("airfare_exadult",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["airfare_exadult"] }}" @endif class="air_fare_exadult">
<input type="hidden" name="Price[{{$j}}][airfare_childbed]" @if(array_key_exists("airfare_childbed",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["airfare_childbed"] }}" @endif class="air_fare_childbed">
<input type="hidden" name="Price[{{$j}}][airfare_childwbed]" @if(array_key_exists("airfare_childwbed",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["airfare_childwbed"] }}" @endif class="air_fare_childwbed">
<input type="hidden" name="Price[{{$j}}][airfare_infant]" @if(array_key_exists("airfare_infant",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["airfare_infant"] }}" @endif class="air_fare_infant">
<input type="hidden" name="Price[{{$j}}][airfare_single]" @if(array_key_exists("airfare_single",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["airfare_single"] }}" @endif class="air_fare_single">
<input type="hidden" name="Price[{{$j}}][aircurrency]" @if(array_key_exists("aircurrency",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["aircurrency"] }}" @endif class="air_currency">
<!---->
<input type="hidden" name="Price[{{$j}}][hotelfare_adult]" @if(array_key_exists("hotelfare_adult",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["hotelfare_adult"] }}" @endif class="hotel_fare_adult">
<input type="hidden" name="Price[{{$j}}][hotelfare_exadult]" @if(array_key_exists("hotelfare_exadult",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["hotelfare_exadult"] }}" @endif class="hotel_fare_exadult">
<input type="hidden" name="Price[{{$j}}][hotelfare_childbed]" @if(array_key_exists("hotelfare_childbed",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["hotelfare_childbed"] }}" @endif class="hotel_fare_childbed">
<input type="hidden" name="Price[{{$j}}][hotelfare_childwbed]" @if(array_key_exists("hotelfare_childwbed",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["hotelfare_childwbed"] }}" @endif class="hotel_fare_childwbed">
<input type="hidden" name="Price[{{$j}}][hotelfare_infant]" @if(array_key_exists("hotelfare_infant",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["hotelfare_infant"] }}" @endif class="hotel_fare_infant">
<input type="hidden" name="Price[{{$j}}][hotelfare_single]" @if(array_key_exists("hotelfare_single",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["hotelfare_single"] }}" @endif class="hotel_fare_single">
<input type="hidden" name="Price[{{$j}}][hotelcurrency]" @if(array_key_exists("hotelcurrency",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["hotelcurrency"] }}" @endif class="hotel_currency">
<!----> 
<input type="hidden" name="Price[{{$j}}][tourfare_adult]" @if(array_key_exists("tourfare_adult",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["tourfare_adult"] }}" @endif class="tour_fare_adult">
<input type="hidden" name="Price[{{$j}}][tourfare_exadult]" @if(array_key_exists("tourfare_exadult",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["tourfare_exadult"] }}" @endif class="tour_fare_exadult">
<input type="hidden" name="Price[{{$j}}][tourfare_childbed]" @if(array_key_exists("tourfare_childbed",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["tourfare_childbed"] }}" @endif class="tour_fare_childbed">
<input type="hidden" name="Price[{{$j}}][tourfare_childwbed]" @if(array_key_exists("tourfare_childwbed",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["tourfare_childwbed"] }}" @endif class="tour_fare_childwbed">
<input type="hidden" name="Price[{{$j}}][tourfare_infant]" @if(array_key_exists("tourfare_infant",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["tourfare_infant"] }}" @endif class="tour_fare_infant">
<input type="hidden" name="Price[{{$j}}][tourfare_single]" @if(array_key_exists("tourfare_single",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["tourfare_single"] }}" @endif class="tour_fare_single">
<input type="hidden" name="Price[{{$j}}][tourcurrency]" @if(array_key_exists("tourcurrency",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["tourcurrency"] }}" @endif class="tour_currency">
<!---->  
<input type="hidden" name="Price[{{$j}}][transferfare_adult]" @if(array_key_exists("transferfare_adult",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["transferfare_adult"] }}" @endif class="transfer_fare_adult">
<input type="hidden" name="Price[{{$j}}][transferfare_exadult]" @if(array_key_exists("transferfare_exadult",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["transferfare_exadult"] }}" @endif class="transfer_fare_exadult">
<input type="hidden" name="Price[{{$j}}][transferfare_childbed]" @if(array_key_exists("transferfare_childbed",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["transferfare_childbed"] }}" @endif class="transfer_fare_childbed">
<input type="hidden" name="Price[{{$j}}][transferfare_childwbed]" @if(array_key_exists("transferfare_childwbed",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["transferfare_childwbed"] }}" @endif class="transfer_fare_childwbed">
<input type="hidden" name="Price[{{$j}}][transferfare_infant]" @if(array_key_exists("transferfare_infant",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["transferfare_infant"] }}" @endif class="transfer_fare_infant">
<input type="hidden" name="Price[{{$j}}][transferfare_single]" @if(array_key_exists("transferfare_single",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["transferfare_single"] }}" @endif class="transfer_fare_single">
<input type="hidden" name="Price[{{$j}}][transfercurrency]" @if(array_key_exists("transfercurrency",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["transfercurrency"] }}" @endif class="transfer_currency">
<!---->
<input type="hidden" name="Price[{{$j}}][visafare_adult]" @if(array_key_exists("visafare_adult",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["visafare_adult"] }}" @endif class="visa_fare_adult">
<input type="hidden" name="Price[{{$j}}][visafare_exadult]" @if(array_key_exists("visafare_exadult",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["visafare_exadult"] }}" @endif class="visa_fare_exadult">
<input type="hidden" name="Price[{{$j}}][visafare_childbed]" @if(array_key_exists("visafare_childbed",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["visafare_childbed"] }}" @endif class="visa_fare_childbed">
<input type="hidden" name="Price[{{$j}}][visafare_childwbed]" @if(array_key_exists("visafare_childwbed",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["visafare_childwbed"] }}" @endif class="visa_fare_childwbed">
<input type="hidden" name="Price[{{$j}}][visafare_infant]" @if(array_key_exists("visafare_infant",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["visafare_infant"] }}" @endif class="visa_fare_infant">
<input type="hidden" name="Price[{{$j}}][visafare_single]" @if(array_key_exists("visafare_single",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["visafare_single"] }}" @endif class="visa_fare_single">
<input type="hidden" name="Price[{{$j}}][visacurrency]" @if(array_key_exists("visacurrency",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["visacurrency"] }}" @endif class="visa_currency">
<!---->
<input type="hidden" name="Price[{{$j}}][adult_fare_total]" @if(array_key_exists("adult_fare_total",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["adult_fare_total"] }}" @endif class="adult_fare_total">
<input type="hidden" name="Price[{{$j}}][exadult_fare_total]" @if(array_key_exists("exadult_fare_total",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["exadult_fare_total"] }}" @endif class="exadult_fare_total">
<input type="hidden" name="Price[{{$j}}][childwithbed_fare_total]" @if(array_key_exists("childwithbed_fare_total",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["childwithbed_fare_total"] }}" @endif class="childwithbed_fare_total">
<input type="hidden" name="Price[{{$j}}][childwithoutbed_fare_total]" @if(array_key_exists("childwithoutbed_fare_total",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["childwithoutbed_fare_total"] }}" @endif class="childwithoutbed_fare_total">
<input type="hidden" name="Price[{{$j}}][infant_fare_total]" @if(array_key_exists("infant_fare_total",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["infant_fare_total"] }}" @endif class="infant_fare_total">
<input type="hidden" name="Price[{{$j}}][single_fare_total]" @if(array_key_exists("single_fare_total",$packagesData->pricing["$j"])) value="{{ $packagesData->pricing["$j"]["single_fare_total"] }}" @endif class="single_fare_total">

</div>








<button type="button" class="btn btn-info btn-lg price_add" data-toggle="modal" data-id="c_price{{$j}}">Add Price</button>
</td>
<td>

@if($i>"1")
<button type="button" name="remove" id="{{$i}}" class="btn btn-danger btn_remove">X</button>

@endif
</td>
</tr>
@endfor
</table>

<button type="button" name="add" id="add-price-row" class="btn btn-success" style="margin-left: 10px">Add More
</button>

</div>

</div>
<!--upcoming start-->
<div class="form-group pricelistpackage_upcoming"  @if($packagesData->upcoming == 1) style="display:none;"  @endif>

<div class="table-responsive">
<table class="table table-bordered" id="dynamic_field_upcoming">
<tr>
<th>Price title</th>
<th><input name="Price_title_upcoming" placeholder="Title.." class="form-control" type="text" value="{{$packagesData->upcoming_title}}"></th>

<th>Price type</th>
<th>

<select name="Price_type_upcoming" class="form-control">
<option value="0">Select Type </option>
<option value="Per Person" @if($packagesData->upcoming_type=="Per Person") selected="selected" @endif >Per Person </option>
<option value="Per Group" @if($packagesData->upcoming_type=="Per Group") selected="selected" @endif>Per Group</option>

</select>
</th>
<th></th>

</tr>

<tr>
<th>Package Rating</th>
<th>Price from</th>
<th>Price to</th>
<th>Cut Off Point</th>
</tr>

<?php
$price_up_count=count($packagesData->upcoming_pricing);
$priceingup=$packagesData->upcoming_pricing;
$priup=[];

foreach($priceingup as $prices):
$priup[]=$prices;
endforeach;

$packagesData->priceingup=$priup;   
?>
@for($i=1;$i<=$price_up_count;$i++)
<?php
$j=($i-1);
?>
<tr id="up_row{{$i}}">
<td>

<select name="Price_upcoming[{{$j}}][package_rating]" id="rating_upcoming" class="form-control" style="width: 90px">
@foreach($ratingType as $rtyp)
<?php
$rating_up_array=explode(" ",$packagesData->upcoming_pricing["$j"]["package_rating"]);
?>               
<option value='{{$rtyp->id}}' @if(in_array($rtyp->id , $rating_up_array )) selected="selected" @endif >{{$rtyp->name}} </option>
@endforeach                      


</select>

</td>
<td>
<div class="input-group date">
<div class="input-group-addon">
<i class="fa fa-calendar"></i>
</div>
<input name="Price_upcoming[{{$j}}][datefrom]" class="form-control pull-right datepicker"  type="text" value="{{ $packagesData->upcoming_pricing["$j"]["datefrom"] }}">
</div>

</td>
<td>
<div class="input-group date">
<div class="input-group-addon">
<i class="fa fa-calendar"></i>
</div>
<input  name="Price_upcoming[{{$j}}][dateto]" class="form-control pull-right datepicker" type="text" value="{{ $packagesData->upcoming_pricing["$j"]["dateto"] }}">
</div>
</td>
<td>

<input type="number" name="Price_upcoming[{{$j}}][cuttoffpoint]" class="form-control" placeholder="Cutt Off Days"
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("cuttoffpoint",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["cuttoffpoint"] }}" @endif
@endif
>
</td>                                             
<td>
<div class="cup_price{{$j}}" id="cup_price{{$j}}">

<input type="hidden" name="Price_upcoming[{{$j}}][airfare_adult]"
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("airfare_adult",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["airfare_adult"] }}" @endif 
@endif

class="air_fare_adult">


<input type="hidden" name="Price_upcoming[{{$j}}][airfare_exadult]"
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("airfare_exadult",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["airfare_exadult"] }}" @endif 
@endif
class="air_fare_exadult">

<input type="hidden" name="Price_upcoming[{{$j}}][airfare_childbed]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("airfare_childbed",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["airfare_childbed"] }}" @endif 
@endif

class="air_fare_childbed">
<input type="hidden" name="Price_upcoming[{{$j}}][airfare_childwbed]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("airfare_childwbed",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["airfare_childwbed"] }}" @endif 
@endif
class="air_fare_childwbed">
<input type="hidden" name="Price_upcoming[{{$j}}][airfare_infant]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("airfare_infant",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["airfare_infant"] }}" @endif 
@endif
class="air_fare_infant">
<input type="hidden" name="Price_upcoming[{{$j}}][airfare_single]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("airfare_single",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["airfare_single"] }}" @endif 
@endif
class="air_fare_single">
<input type="hidden" name="Price_upcoming[{{$j}}][aircurrency]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("aircurrency",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["aircurrency"] }}" @endif 
@endif
class="air_currency">
<!---->
<input type="hidden" name="Price_upcoming[{{$j}}][hotelfare_adult]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("hotelfare_adult",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["hotelfare_adult"] }}" @endif 
@endif
class="hotel_fare_adult">
<input type="hidden" name="Price_upcoming[{{$j}}][hotelfare_exadult]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("hotelfare_exadult",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["hotelfare_exadult"] }}" @endif 
@endif
class="hotel_fare_exadult">
<input type="hidden" name="Price_upcoming[{{$j}}][hotelfare_childbed]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("hotelfare_childbed",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["hotelfare_childbed"] }}" @endif 
@endif
class="hotel_fare_childbed">
<input type="hidden" name="Price_upcoming[{{$j}}][hotelfare_childwbed]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("hotelfare_childwbed",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["hotelfare_childwbed"] }}" @endif 
@endif
class="hotel_fare_childwbed">
<input type="hidden" name="Price_upcoming[{{$j}}][hotelfare_infant]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("hotelfare_infant",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["hotelfare_infant"] }}" @endif 
@endif
class="hotel_fare_infant">
<input type="hidden" name="Price_upcoming[{{$j}}][hotelfare_single]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("hotelfare_single",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["hotelfare_single"] }}" @endif 
@endif
class="hotel_fare_single">
<input type="hidden" name="Price_upcoming[{{$j}}][hotelcurrency]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("hotelcurrency",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["hotelcurrency"] }}" @endif 
@endif
class="hotel_currency">
<!----> 
<input type="hidden" name="Price_upcoming[{{$j}}][tourfare_adult]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("tourfare_adult",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["tourfare_adult"] }}" @endif 
@endif
class="tour_fare_adult">
<input type="hidden" name="Price_upcoming[{{$j}}][tourfare_exadult]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("tourfare_exadult",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["tourfare_exadult"] }}" @endif 
@endif
class="tour_fare_exadult">
<input type="hidden" name="Price_upcoming[{{$j}}][tourfare_childbed]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("tourfare_childbed",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["tourfare_childbed"] }}" @endif 
@endif
class="tour_fare_childbed">
<input type="hidden" name="Price_upcoming[{{$j}}][tourfare_childwbed]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("tourfare_childwbed",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["tourfare_childwbed"] }}" @endif 
@endif
class="tour_fare_childwbed">
<input type="hidden" name="Price_upcoming[{{$j}}][tourfare_infant]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("tourfare_infant",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["tourfare_infant"] }}" @endif 
@endif
class="tour_fare_infant">
<input type="hidden" name="Price_upcoming[{{$j}}][tourfare_single]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("tourfare_single",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["tourfare_single"] }}" @endif 
@endif
class="tour_fare_single">
<input type="hidden" name="Price_upcoming[{{$j}}][tourcurrency]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("tourcurrency",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["tourcurrency"] }}" @endif 
@endif
class="tour_currency">
<!---->  
<input type="hidden" name="Price_upcoming[{{$j}}][transferfare_adult]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("transferfare_adult",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["transferfare_adult"] }}" @endif 
@endif
class="transfer_fare_adult">
<input type="hidden" name="Price_upcoming[{{$j}}][transferfare_exadult]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("transferfare_exadult",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["transferfare_exadult"] }}" @endif
@endif
class="transfer_fare_exadult">
<input type="hidden" name="Price_upcoming[{{$j}}][transferfare_childbed]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("transferfare_childbed",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["transferfare_childbed"] }}" @endif 
@endif
class="transfer_fare_childbed">
<input type="hidden" name="Price_upcoming[{{$j}}][transferfare_childwbed]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("transferfare_childwbed",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["transferfare_childwbed"] }}" @endif 
@endif
class="transfer_fare_childwbed">
<input type="hidden" name="Price_upcoming[{{$j}}][transferfare_infant]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("transferfare_infant",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["transferfare_infant"] }}" @endif 
@endif
class="transfer_fare_infant">
<input type="hidden" name="Price_upcoming[{{$j}}][transferfare_single]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("transferfare_single",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["transferfare_single"] }}" @endif 
@endif
class="transfer_fare_single">
<input type="hidden" name="Price_upcoming[{{$j}}][transfercurrency]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("transfercurrency",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["transfercurrency"] }}" @endif 
@endif
class="transfer_currency">
<!---->
<input type="hidden" name="Price_upcoming[{{$j}}][visafare_adult]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("visafare_adult",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["visafare_adult"] }}" @endif 
@endif
class="visa_fare_adult">
<input type="hidden" name="Price_upcoming[{{$j}}][visafare_exadult]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("visafare_exadult",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["visafare_exadult"] }}" @endif 
@endif
class="visa_fare_exadult">
<input type="hidden" name="Price_upcoming[{{$j}}][visafare_childbed]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("visafare_childbed",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["visafare_childbed"] }}" @endif 
@endif
class="visa_fare_childbed">
<input type="hidden" name="Price_upcoming[{{$j}}][visafare_childwbed]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("visafare_childwbed",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["visafare_childwbed"] }}" @endif 
@endif
class="visa_fare_childwbed">
<input type="hidden" name="Price_upcoming[{{$j}}][visafare_infant]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("visafare_infant",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["visafare_infant"] }}" @endif 
@endif
class="visa_fare_infant">
<input type="hidden" name="Price_upcoming[{{$j}}][visafare_single]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("visafare_single",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["visafare_single"] }}" @endif 
@endif
class="visa_fare_single">
<input type="hidden" name="Price_upcoming[{{$j}}][visacurrency]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("visacurrency",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["visacurrency"] }}" @endif 
@endif
class="visa_currency">
<!---->
<input type="hidden" name="Price_upcoming[{{$j}}][adult_fare_total]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("adult_fare_total",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["adult_fare_total"] }}" @endif 
@endif
class="adult_fare_total">
<input type="hidden" name="Price_upcoming[{{$j}}][exadult_fare_total]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("exadult_fare_total",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["exadult_fare_total"] }}" @endif 
@endif
class="exadult_fare_total">
<input type="hidden" name="Price_upcoming[{{$j}}][childwithbed_fare_total]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("childwithbed_fare_total",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["childwithbed_fare_total"] }}" @endif
@endif
class="childwithbed_fare_total">
<input type="hidden" name="Price_upcoming[{{$j}}][childwithoutbed_fare_total]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("childwithoutbed_fare_total",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["childwithoutbed_fare_total"] }}" @endif
@endif
class="childwithoutbed_fare_total">
<input type="hidden" name="Price_upcoming[{{$j}}][infant_fare_total]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("infant_fare_total",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["infant_fare_total"] }}" @endif 
@endif
class="infant_fare_total">
<input type="hidden" name="Price_upcoming[{{$j}}][single_fare_total]" 
@if($packagesData->upcoming_pricing!="")
@if(array_key_exists("single_fare_total",$packagesData->upcoming_pricing["$j"])) value="{{ $packagesData->upcoming_pricing["$j"]["single_fare_total"] }}" @endif 
@endif
class="single_fare_total">

</div>








<button type="button" class="btn btn-info btn-lg price_add" data-toggle="modal" data-id="cup_price{{$j}}">Add Price</button>
</td>
<td>

@if($i>"1")
<button type="button" name="remove" id="{{$i}}" class="btn btn-danger btn_remove_up">X</button>

@endif
</td>

</tr>
@endfor

</table>

<button type="button" name="add" id="add_upcoming_price_row" class="btn btn-success" style="margin-left: 10px">Add More
</button>

</div>

</div>


<!--upcoming end-->
</div>
</div>

</div>
</div>
<div id="price_add" class="modal fade" role="dialog">
<div class="modal-dialog">

<!-- Modal content-->
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<h4 class="modal-title">Add Price</h4>
</div>
<div class="modal-body">
<input type="hidden" name="" value="" class="price_class">
<div class="table-responsive">          
<table class="table">
<thead>
<th></th>
<th>Currency</th>
<th>Adult <br> (Twin Sharing)</th>
<th>Extra Adult</th>
<th>Child <br> (With Bed)</th>
<th>Child <br> (Without Bed)</th>
<th>Infant </th>
<th>Single <br> Supplement</th>
</thead>
<tbody>
<tr>
<td style="padding-top: 16px;"><strong>Air Fare</strong></td>

<td>
<select class="form-control a_curr">


</select>
</td>
<td>
<input class="form-control airfare_adult" placeholder="Airfare" value="">
</td>
<td>
<input class="form-control airfare_exadult" placeholder="Airfare" value="">
</td>
<td>
<input class="form-control airfare_childbed" placeholder="Airfare" value="">
</td>
<td>
<input class="form-control airfare_childwbed" placeholder="Airfare" value="">
</td>
<td>
<input class="form-control airfare_infant" placeholder="Airfare" value="">
</td>
<td>
<input class="form-control airfare_single" placeholder="Airfare" value="">
</td>
</tr>
<!--seperate-->

<tr>
<td style="padding-top: 16px;"><strong>Hotel</strong></td>

<td>
<select class="form-control h_curr">

</select>
</td>
<td>
<input class="form-control hotelfare_adult" placeholder="Hotel Fare" value="">
</td>
<td>
<input class="form-control hotelfare_exadult" placeholder="Hotel Fare" value="">
</td>
<td>
<input class="form-control hotelfare_childbed" placeholder="Hotel Fare" value="">
</td>
<td>
<input class="form-control hotelfare_childwbed" placeholder="Hotel Fare" value="">
</td>
<td>
<input class="form-control hotelfare_infant" placeholder="Hotel Fare" value="">
</td>
<td>
<input class="form-control hotelfare_single" placeholder="Hotel Fare" value="">
</td>
</tr>
<!--seperate-->
<tr>
<td style="padding-top: 16px;"><strong>Tours</strong></td>

<td>
<select class="form-control t_curr">

</select>
</td>
<td>
<input class="form-control tourfare_adult" placeholder="Tour Fare" value="">
</td>
<td>
<input class="form-control tourfare_exadult" placeholder="Tour Fare" value="">
</td>
<td>
<input class="form-control tourfare_childbed" placeholder="Tour Fare" value="">
</td>
<td>
<input class="form-control tourfare_childwbed" placeholder="Tour Fare" value="">
</td>
<td>
<input class="form-control tourfare_infant" placeholder="Tour Fare" value="">
</td>
<td>
<input class="form-control tourfare_single" placeholder="Tour Fare" value="">
</td>
</tr>
<!--seperate-->
<tr>
<td style="padding-top: 16px;"><strong>Transfers</strong></td>

<td>
<select class="form-control to_curr">

</select>
</td>
<td>
<input class="form-control transferfare_adult" placeholder="Transfer Fare" value="">
</td>
<td>
<input class="form-control transferfare_exadult" placeholder="Transfer Fare" value="">
</td>
<td>
<input class="form-control transferfare_childbed" placeholder="Transfer Fare" value="">
</td>
<td>
<input class="form-control transferfare_childwbed" placeholder="Transfer Fare" value="">
</td>
<td>
<input class="form-control transferfare_infant" placeholder="Transfer Fare" value="">
</td>
<td>
<input class="form-control transferfare_single" placeholder="Transfer Fare" value="">
</td>
</tr>
<!--seperate-->
<tr>
<td style="padding-top: 16px;"><strong>Visa</strong></td>

<td>
<select class="form-control v_curr">

</select>
</td>
<td>
<input class="form-control visafare_adult" placeholder="Visa Fare" value="">
</td>
<td>
<input class="form-control visafare_exadult" placeholder="Visa Fare" value="">
</td>
<td>
<input class="form-control visafare_childbed" placeholder="Visa Fare" value="">
</td>
<td>
<input class="form-control visafare_childwbed" placeholder="Visa Fare" value="">
</td>
<td>
<input class="form-control visafare_infant" placeholder="Visa Fare" value="">
</td>
<td>
<input class="form-control visafare_single" placeholder="Visa Fare" value="">
</td>
</tr>
<!--seperate-->
<tr>
<td style="padding-top: 16px;"><strong>Total</strong></td>

<td><select class="form-control">
<option selected="disabled">INR</option>           
</select></td>
<td>
<input class="form-control adult_total"  value="" readonly>
</td>
<td>
<input class="form-control extraadult_total"  value="" readonly>
</td>
<td>
<input class="form-control childwithbed_total"  value="" readonly>
</td>
<td>
<input class="form-control childwithoutbed_total "  value="" readonly>
</td>
<td>
<input class="form-control infant_total"  value="" readonly>
</td>
<td>
<input class="form-control single_total"  value="" readonly>
</td>
</tr>

<!--seperate-->



</tbody>
</table>
</div>
</div>
<div class="modal-footer">

<button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
<button type="button" class="btn btn-success" id="submit_price" data-dismiss="modal">Submit</button>
</div>
</div>

</div>
</div>
</div>

<div id="Supplier" class="tab-pane fade">
<div class="panel-body">

<div class="row">
<div class="col-md-12">

<div class="form-group">
<input type="text" class="form-control" @if($packageSupplier!="")  value="{{$packageSupplier->supplier_name}}" @endif name="supplier_name" placeholder="Name"  />
</div>
<div class="form-group">
<input type="text" class="form-control" @if($packageSupplier!="") value="{{$packageSupplier->contact_no}}" @endif name="supplier_contact_no" placeholder="Contact No"  />
</div>
<div class="form-group">
<input type="text" class="form-control" @if($packageSupplier!="") value="{{$packageSupplier->email_id}}" @endif name="supplier_emailId" placeholder="Email Id"  />
</div>
<div class="form-group">
<input type="text" class="form-control" @if($packageSupplier!="") value="{{$packageSupplier->supplier_price}}" @endif name="supplier_price" placeholder="Price"  />
</div>

<div class="form-group">
<textarea class="form-control"  name="supplier_address" placeholder="Address" required>  @if($packageSupplier!=""){{$packageSupplier->address}} @endif</textarea>
</div>
</div>
</div>

</div>
</div>
@if(Sentinel::check())
 @if(Sentinel::getUser()->inRole('super_admin'))


<div id="META" class="tab-pane fade">
<div class="panel-body">
<div class="row">
<div class="col-md-12">
    <h4>The Worldgateway SEO</h4>
<div class="form-group">
<input type="text" class="form-control" value="{{$packagesData->meta_title}}" name="meta_title" placeholder="Title"  />
</div>
<div class="form-group">
<input type="text" class="form-control" value="{{$packagesData->meta_desc}}" name="meta_desc" placeholder="Description"  />
</div>
<div class="form-group">
<textarea class="form-control"  name="meta_keyword" placeholder="Keywords" >{{$packagesData->meta_keyword}}</textarea>
</div>
</div>
</div>
<!---->
<div class="row">
<div class="col-md-12">
    <h4>Rapidex Travels SEO</h4>

<div class="form-group">
<input type="text" class="form-control" name="rapidex_meta_title" placeholder="Title" value="{{$packagesData->rapidex_meta_title}}" />
</div>
<div class="form-group">
<input type="text" class="form-control" name="rapidex_meta_desc" placeholder="Description" value="{{$packagesData->rapidex_meta_desc}}" />
</div>
<div class="form-group">
<textarea class="form-control" name="rapidex_meta_keyword" placeholder="Keywords">
{{$packagesData->rapidex_meta_keyword}}</textarea>
</div>
</div>
</div>
<!---->
</div>
</div>
@endif
@endif
<div id="Additional" class="tab-pane fade">
<div id="Additional" >
<div class="panel-body">
<div class="row">
<div class="col-md-12">
<h4>Terms & Conditions
</h4>

<div class="form-group">
<label for="">Is Visa Required?</label>
<input type="checkbox" @if($packagesData->visa == 1) checked  @endif name="visa" value="1" id="customize_onrequestvisa" />
</div>
<div class="costomize_tour_visa" @if($packagesData->visa == 1) style="display:block" @else style="display:none" @endif>
    <h5>Visa Terms & Policies</h5>

<table class="table table-bordered" id="dynamic_field">
<tbody>
<tr>
<td style="width: 60%;">
<div>






<select name="package_visa[]"  class="select2 form-control" multiple>
@foreach($visaPolicy as $pol)
@if(empty($packagesData->visa_p))
<option value="{{$pol->id}}">{{$pol->policy}}
</option>
@else
<option value="{{$pol->id}}" @if(in_array($pol->id,$packagesData->visa_p) ) selected="selected" @endif >{{$pol->policy}}
</option>
@endif

@endforeach  
</select>



</div>
</td>
</tr>
<tr>                                              
<td>
<textarea   name="visa_policies" placeholder="Please state your Extra visa Policies..." rows="6" class="form-control">{{$packagesData->visa_policy}}
</textarea>
<!--<input type="hidden" name="visa_policies" id="visa_policies_input" value=""/>-->
</td>
</tr>
</tbody>
</table>
</div>
<h5>Payment Terms & Methods
</h5>
<table class="table table-bordered" id="dynamic_field">
<tbody>
<tr>
<td style="width: 60%;">
<div>
<select name="package_payment[]"  class="select2 form-control" multiple>
@foreach($paymentPolicy as $pol)
@if(empty($packagesData->payment_p))
<option value="{{$pol->id}}">{{$pol->policy}}
</option>
@else
<option value="{{$pol->id}}" @if(in_array($pol->id,$packagesData->payment_p) ) selected="selected" @endif >{{$pol->policy}}
</option>
@endif

@endforeach  
<select>





</div>
</td>
</tr>
<tr>                                              
<td>
<textarea   name="payment_policies" placeholder="Please state your Payment Terms and Methods..." rows="6" class="form-control">{{$packagesData->payment_policy}}
</textarea>
<!--<input type="hidden" name="payment_policies" id="payment_policies_input" value=""/>-->
</td>
</tr>
</tbody>
</table>
<h5>Cancellation & Refund Policy
</h5>
<table class="table table-bordered" id="dynamic_field">
<tbody>
<tr>
<td style="width: 60%;">
<div>
<select name="package_can[]"  class="select2 form-control" multiple>
@foreach($cancelPolicy as $pol)
@if(empty($packagesData->can_p))
<option value="{{$pol->id}}">{{$pol->policy}}
</option>
@else
<option value="{{$pol->id}}" @if(in_array($pol->id,$packagesData->can_p) ) selected="selected" @endif >{{$pol->policy}}
</option>
@endif

@endforeach  
<select>





</div>
</td>
</tr>
<tr> 
<td>
<textarea   name="cancellation" placeholder="Please state your Cancellation Terms & Refund Policy..." rows="6" class="form-control">{{$packagesData->cancel_policy}}
</textarea>

<!--<input type="hidden" name="cancellation" id="cancellation_input_field" value=""/>-->
</td>
</tr>
</tbody>
</table>
<!---->  
<h5>Important Notes
</h5>
<table class="table table-bordered" >
<tbody>
<tr>
<td style="width: 60%;">
<div>
<select name="package_impnotes[]"  class="select2 form-control" multiple>
@foreach($imp_notes as $pol)
@if(empty($packagesData->importantnotes))
<option value="{{$pol->id}}">{{$pol->policy}}
</option>
@else
<option value="{{$pol->id}}" @if(in_array($pol->id,$packagesData->importantnotes) ) selected="selected" @endif >{{$pol->policy}}
</option>
@endif

@endforeach  
<select>





</div>
</td>
</tr>
<tr> 
<td>
<textarea   name="extra_imp" placeholder="Please state your Important Notes..." rows="6" class="form-control">{{$packagesData->extranotes}}
</textarea>

<!--<input type="hidden" name="cancellation" id="cancellation_input_field" value=""/>-->
</td>
</tr>
</tbody>
</table>                                
</div>
</div>

</div>
</div>
</div>



</div>
<!---->



<!-- end-->


<div style="text-align: center;">

<button type="submit" name="add" id="remove" class="btn btn-danger btn-lg location_add">Save 
<i class="fa  fa-arrow-right">
</i>
</button>
</div>
</form>
<!-- TAB-1 INNAR HTML END -->

</div>    
<!-- END New Edit Template-->
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<!-- /.content -->
</div>


<!---->
<div class="modal fade" id="packagetour_custom" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
<h3 class="modal-title" id="lineModalLabel">Add Package Tour</h3>
</div>
<div class="modal-body">
<!-- content goes here -->
<form>
<input type="hidden" name="type" value="Private Tour"/>

<br>
<div class="alert alert-success"
id="success-add" style="display:none">
<p>Tour Added Successfully.</p>
</div>
<div class="alert alert-danger" id="error-contaier-parent" style="display:none">
<ul id="error-contaier"> 
</ul>
</div>
<div class="row form-group">
<label class="col-md-3 control-label text-left">Tour Name</label>
<div class="col-md-8">
<input name="name" class="form-control name" placeholder="Name" value="" type="text" id="tour_name">
</div>
</div>
<div class="row form-group">
<label class="col-md-3 control-label text-left">Tour Description</label>
<div class="col-md-8">
<input name="description" class="form-control description" placeholder="description.." value="" type="text" 
id="tour_description">
</div>
</div>
<div class="row form-group">
<label class="col-md-3 control-label text-left">Tour Locations</label>
<div class="col-md-8">
<input name="location" class="form-control location" placeholder="location" value="" type="text" 
id="tour_location">
</div>
</div>

<div class="row form-group">
<label class="col-md-3 control-label text-left">Status</label>
<div class="col-md-8">
<select name="status" class="form-control status" id="tour_status">
<option value="1">Enable</option>
<option value="0">Disable</option>
</select>
</div>
</div>

</div>
<div class="modal-footer">
<div class="btn-group tn-group-justified" role="group" aria-label="group button">
<div class="btn-group" role="group">
<button type="button" class="btn btn-default" data-dismiss="modal"  role="button">Close</button>
</div>
<div class="btn-group" role="group">
<input type="submit"  class="btn btn-primary" 
value="Add" id="add-tour" >
</div>
</div>
</div>
</form>
</div>
</div>
</div>
<!---->
<div class="modal fade" id="pk_aadhotel" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
<h3 class="modal-title" id="lineModalLabel">Add Package Hotel</h3>
</div>
<div class="modal-body">
<!-- content goes here -->
<form>
<input type="hidden" name="type" value="Private Tour"/>

<br>
<div class="alert alert-success"
id="success-add_pkhotel" style="display:none">
<p>Package Hotel Added Successfully.</p>
</div>
<div class="alert alert-danger" id="error-add_pkhotel" style="display:none">
<ul id="error-contaier">
<p>Enter Valid Input</p> 
</ul>
</div>
<div class="row form-group">
<label class="col-md-3 control-label text-left">Hotel Name</label>
<div class="col-md-8">
<input name="hotelname" class="form-control" placeholder="Hotel Name"  type="text" id="hotelname">
</div>
</div>

<div class="row form-group">
<label class="col-md-3 control-label text-left">Locations</label>
<div class="col-md-8">
<input name="location" class="form-control" placeholder="Location" value="" type="text" 
id="location">
</div>
</div>


<div class="row form-group">
<label class="col-md-3 control-label text-left">Star Rating</label>
<div class="col-md-8">
<select name="star_rating" class="form-control" id="star_rating">
<option value="5">5 Star</option>
<option value="4.5">4.5 Star</option>
<option value="4">4 Star</option>
<option value="3.5">3.5 Star</option>
<option value="3">3 Star</option>
<option value="2">2 Star</option>
<option value="1">1 Star</option>
</select>
</div>
</div>


</div>
<div class="modal-footer">
<div class="btn-group tn-group-justified" role="group" aria-label="group button">
<div class="btn-group" role="group">
<button type="button" class="btn btn-default" data-dismiss="modal"  role="button">Close</button>
</div>
<div class="btn-group" role="group">
<input type="submit"  class="btn btn-primary" value="Add" id="add_package_hotel" >

</div>
</div>
</div>
</form>
</div>
</div>
</div>

<!---->  
@endsection

@section("custom_js_code")
<script>
  //customize_onrequestvisa
 $(document).on("click","#customize_onrequestvisa",function(){
    if($(this).is(":checked"))
    {
    $(this).parent().siblings(".costomize_tour_visa").show()
    }
    else
    {
   $(this).parent().siblings(".costomize_tour_visa").hide()
    }
})
</script>
@endsection