@extends('layouts.master')
@section('content')

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<!-- Content Header (Page header) -->
<!-- Main content -->
<section class="content">
<div class="row">
<div class="col-md-12">
<div class="box">
<div class="box-header">
</div>
<!-- /.box-header -->
<div class="box-body">
  <a href="{{URL::to('/package_image_location/'.Request::segment(3))}}" class="btn btn-success"><i class="glyphicon glyphicon-arrow-left"> </i> Back</a>
 
<h3 class="box-title">Add Photos From Gallery <span style="font-size: 14px">( {{$country_name}} &rarr; {{$city_name}} &rarr; {{CustomHelpers::get_package_title(Request::segment(3))}})</span></h3>


<form action="{{URL::to('/packages_image_save/'.Request::segment(2).'/'.Request::segment(3).'/'.Request::segment(4))}}" method="post" >

{{csrf_field()}}
<br>
<div class="row">
@foreach($data as $datavalue) 
<div class="col-md-4" style="margin-bottom: 20px">
 @if($datavalue->thum_medium!="")
 <img src="{{URL::to('/').'/public/uploads/packages/thum_medium/'.$datavalue->thum_medium }}" style="max-width: 100%;height: 200px"><br>
 @else
<img src="{{URL::to('/').'/public/'.$datavalue->image_path }}" style="max-width: 100%;height: 200px"><br>
 @endif

 <input type="radio" name="image_from_gallery" value="{{$datavalue->id}}" @if(CustomHelpers::get_data_conditions($datavalue->id)==Request::segment(2)) checked  @endif> 
 

 
 <span class="pull-right" style="font-size: 12px;font-weight: bold;">{{$datavalue->name}}</span>
</div>

@endforeach                
</div> 
<button type="submit" class="btn btn-success">Submit</button>                
</form>

</div>
<!-- /.box-body -->
</div>
</div>
</div>
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
@endsection