@extends('layouts.master')
@section('content')
<style>
#dGalleryTopBarCont {
	position: fixed;
	z-index: 1;
	top: 75px;
	margin-bottom: 20px;
	background: #f2f2f2;
	width: 97%;
	display: block;
	transition: top 0.3s;
	padding: 15px;
	border-radius: 5px;
	}
#dGalleryTopBarCont h3 {
	font-size: 24px;
	line-height: 26px;
	color: #000001;
	font-weight: 500;
	text-align: left;
	margin: 0 0 0 10px;
	}
.dImgCard {
	border: 1px solid #e7e7e7;
	border-radius: 5px;
	overflow: hidden;
	margin-top: 60px;
	position: relative;
	}
.dImgCard img {
	width: 100%;
	height: 275px;
	}
.dImgCard label {
	position: absolute;
	bottom: 0;
	margin: 0;
	padding: 10px 0;
	background: #00000160;
	width: 100%;
	font-size: 16px;
	line-height: 16px;
	color: #fff;
    font-weight: 500;
    display: flex;
    justify-content: center;
    align-items: center;
	}
.dImgCard input[type=checkbox] {
	margin: 0 5px;
    height: 15px;
    width: 15px;
	}
.dGalleryBtmBarCont {
	position: fixed;
	bottom: 0;
	background: #fff;
	padding: 15px 0;
	width: 97%;
	display: flex;
	justify-content: center;
	}
.dBtnSubmitImg {
	display: inline-block;
    padding: 4px 12px;
    margin-bottom: 2px;
    font-size: 16px;
    line-height: 20px;
    color: #fff;
	font-weight: 600;
    text-align: center;
    vertical-align: middle;
    cursor: pointer;
    background: #5cb85c;
	border: 1px solid #4cae4c;
	width: 200px;
	height: 40px;
	margin: 0;
	}
.dBtnSubmitImg:hover {
	color: #fff;
	background: #5cb85c;
	border: 1px solid #4cae4c;
	}
.font14 {
	font-size: 14px;
	line-height: 14px;
	}
.makeflex {
	display: flex;
	}
</style>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<!-- Content Header (Page header) -->
<!-- Main content -->
<section class="content">
	<div class="row">
		<div class="col-md-12">
			<div class="box">
				<div class="box-body">
					<div id="dGalleryTopBarCont">
						<div class="makeflex">
						<div>
							<a href="{{URL::to('/package_image_location/'.Request::segment(2))}}" class="btn btn-success"><i class="glyphicon glyphicon-arrow-left"> </i> Back</a>
						</div>
						<div>
							<h3>Add Images from gallery <span class="font14">
								(@if($country!="" && $country!="0" && $state=="0" && ($city=="Select City" ||  $city=="0"))
									{{$country}} &rarr;
								@elseif($country!="" && $country!="0" && $state!="0" && ($city=="Select City" ||  $city=="0"))
									{{$country}} &rarr; {{$state}} &rarr;
								@elseif($country!="" && $country!="0" && $state!="0" && $city!="Select City" && $city!="0")
									{{$country}} &rarr; {{$state}} &rarr;  {{$city}} &rarr;
								@endif
								{{CustomHelpers::get_package_title(Request::segment(2))}})</span>
							</h3>
						</div>
						</div>
					</div>
					<form action="{{URL::to('/package_image_save/'.Request::segment(2))}}" method="post" >
						{{csrf_field()}}
						<br>
						<div class="row">
						@foreach($data as $datavalue)
							<div class="col-md-3">
							<div class="dImgCard">
							@if($datavalue->thum_medium!="")
								<img src="{{URL::to('/').'/public/uploads/packages/thum_medium/'.$datavalue->thum_medium }}">
							@else
								<img src="{{URL::to('/').'/public/'.$datavalue->image_path }}">
							@endif
							<label class="labelgallery">
							<input type="checkbox" name="image_from_gallery[]" value="{{$datavalue->id}}" @if(CustomHelpers::get_data_condition1($datavalue->id,Request::segment(2))=="1") checked  @endif>
								<span class="pull-right" style="">{{$datavalue->name}}</span>
							Select</label>
							</div>
							</div>
						@endforeach
						</div>
						<div class="dGalleryBtmBarCont">
							<button type="submit" class="btn dBtnSubmitImg">Submit</button>
						</div>
					</form>
				</div>
				<!-- /.box-body -->
			</div>
		</div>
	</div>
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
<script>
// When the user scrolls down 20px from the top of the document, slide down the navbar
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    document.getElementById("dGalleryTopBarCont").style.top = "0";
  } else {
    document.getElementById("dGalleryTopBarCont").style.top = "75px";
  }
}
</script>
@endsection