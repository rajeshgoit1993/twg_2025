@extends('layouts.master')
@section('content')
<style>

.panel-default>.panel-heading {
  color: #333;
  background-color: #fff;
  border-color: #e4e5e7;
  padding: 0;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

.panel-default>.panel-heading a {
  display: block;
  padding: 10px 15px;
}

.panel-default>.panel-heading a:after {
  content: "";
  position: relative;
  top: 1px;
  display: inline-block;
  font-family: 'Glyphicons Halflings';
  font-style: normal;
  font-weight: 400;
  line-height: 1;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  float: right;
  transition: transform .25s linear;
  -webkit-transition: -webkit-transform .25s linear;
}

.panel-default>.panel-heading a[aria-expanded="true"] {
  background-color: #eee;
}

.panel-default>.panel-heading a[aria-expanded="true"]:after {
  content: "\2212";
  -webkit-transform: rotate(180deg);
  transform: rotate(180deg);
}

.panel-default>.panel-heading a[aria-expanded="false"]:after {
  content: "\002b";
  -webkit-transform: rotate(90deg);
  transform: rotate(90deg);
}
  .accordion-option {
  width: 100%;
  float: left;
  clear: both;
  margin: 15px 0;
}

.accordion-option .title {
  font-size: 20px;
  font-weight: bold;
  float: left;
  padding: 0;
  margin: 0;
}

.accordion-option .toggle-accordion {
  float: right;
  font-size: 16px;
  color: #6a6c6f;
}
 .dayItinerary{
        border-bottom: 1px solid darkgray;
    margin-bottom: 14px;
    border-radius: 23px;
  }
  span.select2.select2-container {
    width: 100% !important;
}
</style>
<div class="content-wrapper">
       
<section class="content">
<div class="row">
<div class="col-md-12">
              
<div class="panel panel-primary">
<div class="panel-heading">Destination -> Edit Destination</div>
<div class="panel-body">
<div class="modal-body_main">
@if ($errors->any())
<div class="alert alert-danger">
<ul>
@foreach ($errors->all() as $error)
<li>{{ $error }}</li>
@endforeach
</ul>
</div>
@endif
                    
 <form action="{{URL::to('/location-store')}}" method="POST">
  {{csrf_field()}}
 <input type="hidden" name="id" value="{{$locData->id}}"/>
<div class="row">
  <div class="col-md-12">
  <a href="{{URL::to('/package-locations')}}" class="btn btn-success" style="margin-bottom: 10px"><i class="glyphicon glyphicon-arrow-left"> </i> Back</a>

</div>
<div class="col-md-6">
<div class="form-group">
<label for="package">Continent</label>
<select class="form-control " name="continent" id="">
<option value=" ">Select Continent</option>
@foreach($continent as $cont)
<option value="{{$cont->continent}}" @if($locData->continent == $cont->continent) selected="selected" @endif>{{$cont->continent_name}}</option>
@endforeach
</select>
</div>
</div>


<div class="col-md-6">
 <div class="form-group">
<label for="package">Country</label>
<select class="form-control "  onchange="get_states(this)" name="country" id="">
                                        
      <option value='0'>Select Country</option>
                @foreach($country as $cont)
    <option value="{{ $cont->name }}" @if($locData->country==$cont->name) selected="selected" @endif c_id="{{ $cont->id }}" >{{ $cont->name }} 
    </option>
                @endforeach                                       
                                       
                                        

</select>
</div>
</div>

<div class="col-md-6">
 <div class="form-group">
<label for="package">State</label>

<select class="form-control st_values" id="" onchange="getcitys(this)" name="state">
    <option value='0'>Select State</option>
                 @foreach($state as $cont)
          <option value="{{ $cont->name }}" @if($cont->name==$locData->state) selected="selected" @endif s_id="{{ $cont->id }}" >{{ $cont->name }} </option>
                 @endforeach   
          
  </select>
</div>

</div>
<div class="col-md-6">
<div class="form-group">
<label for="package">City</label>
 <select class="form-control ct_values"  name="location">
          <option value='0'>Select City</option>
          @foreach($city as $cont)
                <option value="{{ $cont->name }} " @if($cont->name==$locData->location) selected="selected" @endif>{{ $cont->name }} </option>
          @endforeach   
          
 </select>                                  

</div>
</div>

<div class="col-md-6">
 <div class="form-group">
<label for="package">Currency</label>
<input type="text" class="form-control " name="currency" value="{{$locData->currency}}">

</div> 
</div>
<div class="col-md-12">
<div class="form-group">
<label for="package">Overview</label>
<textarea name="overview" class="form-control ckeditor" cols="30" rows="5">{{$locData->overview}}</textarea>
</div>  

</div>
<div class="col-md-12">
<div class="form-group">
 
<label for="package">Best Time To Visit</label>
<select class="form-control select2" name="best_time_to_visit[]" id="" multiple>
<option value=" ">Select Month</option>
<option value="1" @if($locData->best_time_to_visit !="0" && $locData->best_time_to_visit !="" && in_array(1,$locData->best_time_to_visit)) selected="selected" @endif>January</option>
<option value="2" @if($locData->best_time_to_visit !="0" && $locData->best_time_to_visit !="" && in_array(2,$locData->best_time_to_visit)) selected="selected" @endif >February</option>
<option value="3" @if($locData->best_time_to_visit !="0" && $locData->best_time_to_visit !="" && in_array(3,$locData->best_time_to_visit)) selected="selected" @endif>March</option>
<option value="4" @if($locData->best_time_to_visit !="0" && $locData->best_time_to_visit !="" && in_array(4,$locData->best_time_to_visit)) selected="selected" @endif >April</option>
<option value="5" @if($locData->best_time_to_visit !="0" && $locData->best_time_to_visit !="" && in_array(5,$locData->best_time_to_visit)) selected="selected" @endif>May</option>
<option value="6" @if($locData->best_time_to_visit !="0" && $locData->best_time_to_visit !="" && in_array(6,$locData->best_time_to_visit)) selected="selected" @endif>June</option>
<option value="7" @if($locData->best_time_to_visit !="0" && $locData->best_time_to_visit !="" && in_array(7,$locData->best_time_to_visit)) selected="selected" @endif>July</option>
<option value="8" @if($locData->best_time_to_visit !="0" && $locData->best_time_to_visit !="" && in_array(8,$locData->best_time_to_visit)) selected="selected" @endif >August</option>
<option value="9" @if($locData->best_time_to_visit !="0" && $locData->best_time_to_visit !="" && in_array(9,$locData->best_time_to_visit)) selected="selected" @endif>September</option>
<option value="10" @if($locData->best_time_to_visit !="0" && $locData->best_time_to_visit !="" && in_array(10,$locData->best_time_to_visit)) selected="selected" @endif >Octuber</option>
<option value="11" @if($locData->best_time_to_visit !="0" && $locData->best_time_to_visit !="" && in_array(11,$locData->best_time_to_visit)) selected="selected" @endif >November</option>
<option value="12" @if($locData->best_time_to_visit !="0" && $locData->best_time_to_visit !="" && in_array(12,$locData->best_time_to_visit)) selected="selected" @endif>December</option>
</select>
</div>

</div>
<div class="col-md-12">
 <div class="form-group">
<label for="package">Best Time Desc.</label>
<textarea name="best_time_desc" class="form-control ckeditor" cols="30" rows="5">{{$locData->best_time_desc}}</textarea>
</div> 
</div>





<div class="col-md-12">
<div class="form-group">
<label for="package">Status</label>
<select class="form-control " name="status" id="">
<option value="1" @if($locData->status == 1) selected="selected" @endif>Enable</option>
<option value="0" @if($locData->status == 0) selected="selected" @endif>Disable</option>
</select>
</div>
</div>







<div class="col-md-12" style="text-align: center;">
  



                                
                               
<div class="form-group">
                                    
<input type="submit" value="Update" class="btn btn-success"/>
</div>
</div>
                            
</div>
</form>
              
</div>
                
</div>
</div>
</div>
</div>
</section>
 <!-- /.content -->
      </div>
@endsection