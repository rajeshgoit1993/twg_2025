@extends('layouts.master')
@section('content')
<style>

.panel-default>.panel-heading {
color: #333;
background-color: #fff;
border-color: #e4e5e7;
padding: 0;
-webkit-user-select: none;
-moz-user-select: none;
-ms-user-select: none;
user-select: none;
}

.panel-default>.panel-heading a {
display: block;
padding: 10px 15px;
}

.panel-default>.panel-heading a:after {
content: "";
position: relative;
top: 1px;
display: inline-block;
font-family: 'Glyphicons Halflings';
font-style: normal;
font-weight: 400;
line-height: 1;
-webkit-font-smoothing: antialiased;
-moz-osx-font-smoothing: grayscale;
float: right;
transition: transform .25s linear;
-webkit-transition: -webkit-transform .25s linear;
}

.panel-default>.panel-heading a[aria-expanded="true"] {
background-color: #eee;
}

.panel-default>.panel-heading a[aria-expanded="true"]:after {
content: "\2212";
-webkit-transform: rotate(180deg);
transform: rotate(180deg);
}

.panel-default>.panel-heading a[aria-expanded="false"]:after {
content: "\002b";
-webkit-transform: rotate(90deg);
transform: rotate(90deg);
}
.accordion-option {
width: 100%;
float: left;
clear: both;
margin: 15px 0;
}

.accordion-option .title {
font-size: 20px;
font-weight: bold;
float: left;
padding: 0;
margin: 0;
}

.accordion-option .toggle-accordion {
float: right;
font-size: 16px;
color: #6a6c6f;
}
.dayItinerary{
border-bottom: 1px solid darkgray;
margin-bottom: 14px;
border-radius: 23px;
}
span.select2.select2-container {
width: 100% !important;
}
.flight
{
display: none;
}
</style>
<div class="content-wrapper">

<section class="content">
<div class="row">
<div class="col-md-12">

<div class="panel panel-default">
<div class="panel-body">
<div class="modal-body_main">
<a href="{{URL::to('/tours')}}" class="btn btn-success"><i class="glyphicon glyphicon-arrow-left"> </i> Back</a>

<!--<button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bs-example-modal-lg">Add in Bulk</button>-->
<div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
<div class="modal-dialog modal-lg">
<div class="modal-content">

<div class="modal-body">
<h4>Choose a file to upload</h4>
<h3>Instructions</h3>
<div class="control-group" style="width: 24%;margin: 0 auto;">
<div class="controls">
<input id="filebutton" name="filebutton" class="input-file" type="file">
</div>
</div>
<br>
<div class="control-group">
<div class="controls">
<button id="singlebutton" name="singlebutton" class="btn btn-info">Upload</button>
</div>
</div>
<br>

<ol>
<li>To see format & possible values while uploading your deals, please <b><a href="#"> download format sheet</a></b> </li>
<li>Fill the details of your deals in excel sheet & save the excel sheet.</li>
<li>Click on <b>Browse</b> button & select the excel file.</li>
<li>Click on <b>Submit</b> to post your deals.</li>
</ol>
</div>
</div>
</div>
</div>
</div>
<br>
<br>



<div id="content">
<ul id="tabs" class="nav nav-tabs" data-tabs="tabs">
<li class="active">
<a href="#red" data-toggle="tab">Customized Holidays
</a>
</li>
<!--<li>
<a href="#orange" data-toggle="tab">Hotel Package </a>

</li>-->
<!-- <li>
<a href="#yellow" data-toggle="tab">Group Tour / Shared Tour
</a>
</li> -->
</ul>
<div id="my-tab-content" class="tab-content">
<div class="tab-pane active" id="red">
@if ($errors->any())
<div class="alert alert-warning">
<ul>
@foreach ($errors->all() as $error)
<li>{{ $error }}</li>
@endforeach
</ul>
</div>
@endif
<!-- TAB-1 INNAR HTML START -->


<!--accordion -->
<div class="col-md-12">
<form action="{{URL::to('/store-package')}}" method="post" >
<input type="hidden" name="type" value="Private Tour"/>
{{csrf_field()}}
<br>
<ul class="nav nav-tabs">
<li class="active"><a data-toggle="tab" href="#Info"><span class="glyphicon glyphicon-file">
</span> Package Info</a></li>
<li><a data-toggle="tab" href="#Description"><span class="glyphicon glyphicon-th-list">
</span>  Description</a></li>
<li><a data-toggle="tab" href="#Overview"><span class="glyphicon glyphicon-th-list">
</span> Overview</a></li>
<li><a data-toggle="tab" href="#accommodation"><i class="fa fa-calendar-check-o" aria-hidden="true"></i>Accommodation</a></li>
<li><a data-toggle="tab" href="#Itinerary"><i class="fa fa-calendar-check-o" aria-hidden="true"></i>Tour Itinerary</a></li>
<li><a data-toggle="tab" href="#Pricing"><i class="fa fa-inr" aria-hidden="true"></i> Pricing</a></li>
<li><a data-toggle="tab" href="#Supplier"><i class="fa fa-suitcase" aria-hidden="true"></i> Supplier </a></li>
 @if(Sentinel::check())
 @if(Sentinel::getUser()->inRole('super_admin'))
<li><a data-toggle="tab" href="#META"><i class="fa fa-database" aria-hidden="true"></i> SEO </a></li>
@endif
@endif
<li><a data-toggle="tab" href="#Additional"><span class="glyphicon glyphicon-th-list">
</span> Additional </a></li>

</ul>
<div class="tab-content">
<div id="Info" class="tab-pane fade in active">
<div class="panel-body">
<div class="row">


<div class="col-md-12">

<div class="col-md-4 form-group">
<label for="duration">Duration</label>
<select name="duration" id="package_durations" class="form-control val">
@for($i=1;$i<=30;$i++)
<option value="{{$i}}">{{ $i }} Night / {{$i+1}} Days</option>

@endfor;


</select>
</div>

<div class="col-md-4 form-group">
<label for="package_name">Title</label>
<input type="text" placeholder="Title" value="{{ old('package_name') }}" name="package_name" class="form-control" >
</div>

<div class="col-md-4 form-group">
<label for="package_name">Tour Type</label>
<select name="tour_type" id="tour_type" class="form-control">

<option value="Customized Tour">Customized Tour</option>
<option value="Group Tour">Group Tour</option>


</select>
</div>

<div class="col-md-6 form-group">
<label for="package_category">Theme</label>
<select name="package_category[]" placeholder="Theme" id="package_category" class="select2 form-control" multiple>

@foreach($types as $typ)
<option value="{{$typ->name}}">{{$typ->name}}  </option>
@endforeach                          

</select>                                     



</div>

<div class="col-md-6 form-group">
<label for="package_location">Services</label>
<div class="input-group" style="margin-bottom:5px;">
<span class="input-group-addon">
<i class="fa fa-map-marker"></i>
</span>                                     

<select name="package_service[]" id="package_service" class="form-control select2" multiple>
@if(count($icons)>0)

@foreach($icons as $icon)
<option value="{{$icon->icon_title}}">{{$icon->icon_title}}  </option>
@endforeach  

@else
<option value="No Result Found">No Result Found</option>

@endif

</select>

</div>

</div>
<div class="" id="dynamic_field_package">
<div class="row remove">
<div class="col-md-12">

<div class="col-md-2 form-group">
<label for="continent">Continent</label>
<select name="continent[0]" id="continent" class="form-control" >
<script>


</script>

<option value="Asia">Asia</option>
<option value="Africa">Africa</option>  
<option value="Antarctica">Antarctica</option>
<option value="Australia">Australia</option>
<option value="Europe">Europe</option>
<option value="North America">North America</option>
<option value="South America">South America</option>           

</select>
</div>
<div class="col-md-2 form-group">
<label for="country">Country</label>
<select name="country[0]" id="package_dest_countries" class="form-control package_dest_country" onchange="myFunction(this)" >
<option value='0'>Select Country</option>
@foreach($countries as $cont)
<option value="{{  $cont->name }}" c_id="{{ $cont->id }}" >{{ $cont->name }} 
</option>
@endforeach          
</select>
</div>
<div class="col-md-2 form-group">
<label for="state">State</label>
<select name="state[0]" id="package_dest_state" class="form-control package_dest_countries" onchange="sateFunction(this)"></select>

</div>
<div class="col-md-2 form-group">
<label for="city">City</label>
<select  name="city[0]" id="package_dest_city" class="form-control package_dest_state city_package_dest_countries min-select" onchange="cityFunction(this)"></select>

</div>
<div class="col-md-2 form-group">
<label for="city">No. Of Days/Nights</label>
<select name="days[0]" id="package_dest_days" class="form-control package_dest_days ">
</select>                         
</div>                                  
<div class="col-md-2 form-group">                                 
</div>

</div>
</div>


</div>                          
<button type="button" name="add-continent" id="add-continent-row" class="btn btn-success"
style="margin-left:15px">Add More </button>   
</div>


</div>                                 

<!--Multi location schedule table-->
<!--<h5>Multi Location Schedule</h5>
<div class="col-md-12" id="dayscheduleDiv">


</div>-->                               

</div>
</div>
<div id="Description" class="tab-pane fade">
  <div class="panel-body">
<div class="row">

<div class="col-md-12">
<div class="form-group">
<label for="">Package Description</label>
<textarea class="form-control ckeditor"  
name="description" id="" cols="30" rows="5" >{{ old('description') }}</textarea>
</div>
<div class="form-group">
<label for="">Tour Highlights</label>
<textarea class="form-control ckeditor"  
name="highlights" id="" cols="30" rows="5" >{{ old('highlights') }}</textarea>
</div>


<br>
</div>  




</div>

</div>
</div>
<div id="Overview" class="tab-pane fade ">
  <div class="panel-body">
<div class="row">

<div class="col-md-12">


<div class="form-group">
<label for="">Transport</label>
<select name="transport" id="transport" class="form-control">
<option value="0">--Choose Transport--</option>
@foreach($transport as $trans)  
<option value="{{ $trans->name }}">{{$trans->name}}</option>
@endforeach   
</select> 

</div>
<div class="oflight">
<textarea class="form-control" placeholder="Package Transport Description..." name="transport_description" id="" cols="30" rows="5">
{{ old('transport_description') }}</textarea>
<br>

</div>
</div>  
<div class="flight">
<div class="col-md-12"><h4>UP</h4></div>
<div class="col-md-4">
<label>Flight Name</label>
<input type="text" name="flight[name]" class="form-control">
</div>
<div class="col-md-4">
<label>Flight No.</label>
<input type="text" name="flight[no]" class="form-control">
</div>
<div class="col-md-4">
<label>No. Of Stop</label>
<input type="text" name="flight[numberstop]" class="form-control">
<br>
</div>

<div class="col-md-3">
<label>Flight Origin</label>
<input type="text" name="flight[Origin]" class="form-control"> 
</div>
<div class="col-md-3">
<label>Departure Time</label>
<input type="text" name="flight[dtime]" class="form-control">
</div>
<div class="col-md-3">
<label>Destination</label>
<input type="text" name="flight[dest]" class="form-control">
</div>
<div class="col-md-3">
<label>Arrival Time</label>
<input type="text" name="flight[atime]" class="form-control">
<br>
</div>
<!---->
<div class="col-md-12"><h4>Down</h4></div>
<div class="col-md-4">
<label>Flight Name</label>
<input type="text" name="flight[dname]" class="form-control">
</div>
<div class="col-md-4">
<label>Flight No.</label>
<input type="text" name="flight[dno]" class="form-control">
</div>
<div class="col-md-4">
<label>No. Of Stop</label>
<input type="text" name="flight[dnumberstop]" class="form-control">
<br>
</div>

<div class="col-md-3">
<label>Flight Origin</label>
<input type="text" name="flight[dOrigin]" class="form-control"> 
</div>
<div class="col-md-3">
<label>Departure Time</label>
<input type="text" name="flight[ddtime]" class="form-control">
</div>
<div class="col-md-3">
<label>Destination</label>
<input type="text" name="flight[ddest]" class="form-control">
</div>
<div class="col-md-3">
<label>Arrival Time</label>
<input type="text" name="flight[datime]" class="form-control">
<br>
</div>
</div>

<div class="col-md-5">
<div class="form-group">

<label for="">Customer Rating</label>
<select class=' form-control' name="customer_rating">
<option value="1">1 Star </option>

<option value="2">2 Star </option>

<option value="3">3 Star </option>

<option value="3.5">3.5 Star </option>

<option value="4">4 Star  </option>

<option value="4.5">4.5 Star  </option>

<option value="5">5 Star </option>

</select>                                      

</div>
</div>

<div class="col-md-5">
<div class="form-group select-container">                                       
<label >Tours</label>

<select class='select2 form-control' name="tours[]" multiple id="tour_add">
@foreach($PkgTours as $key=>$tour)
<option value='{{$tour->id}}'>{{$tour->activity}} </option>

@endforeach 

</select>                                    
</div>                                  
</div>
<div class="custom_tour_parent">
<div class="col-md-2">

<button data-toggle="modal" data-target="#packagetour_custom" class="btn-success btn-sm custom_tour" style="margin-top: 18px;margin-left: 40px">Add Tour</button>
</div>

</div>
</div>
<div class="row">

<div class="col-md-12">
<div class="form-group select-container">
<label >Inclusions</label>
<textarea class="form-control ckeditor"  name="inclusions" id="" cols="30" rows="5">
{{ old('inclusions') }}</textarea>

</div>
</div>
<div class="col-md-12">
<div class=" form-group ">
<label >Exclusions</label>
<textarea class="form-control ckeditor"  name="exclusions" id="" cols="30" rows="5">
{{ old('exclusions') }}
</textarea>

</div>
</div>

</div>
</div>
</div>
<!---->
<div id="accommodation" class="tab-pane fade">
  <div class="panel-body">
<div class="row">
<div class="col-md-12">
  <label class="radio-inline"><input type="radio" name="acc_type" checked class="extra_acc" value="normal_acc">Listed Accommodation</label>
  <label class="radio-inline" ><input type="radio" name="acc_type" class="extra_acc" value="extra_acc">Unlisted Accommodation</label>


</div>
<div class="col-md-12">
  <br>
<div class="accommodation_main">
  <div class="dynamic_acc" id="ddd">
  
  <input type="hidden" name="" value="">
<div class="field0" id="0">
<div class="row">
<div class="col-md-4">

<label>Select Days</label>

<select class="form-control select_day select2" multiple name="accommodation[0][day][]">


</select>


</div>  
<div class="col-md-4">

<label>city</label>

<input type="text" name="accommodation[0][city]" class="form-control query_city" placeholder="City">


</div>  
<div class="col-md-4">

<label>Choose Hotel Manually or from TripAdvisor</label>

<select class="form-control" name="accommodation[0][trip]">
<option>--Select--</option>
<option>Manually</option>  
<option>TripAdvisor</option>  
</select>


</div>  
<div class="col-md-4">

<label>Choose Hotel</label>

<select class="form-control quo_hotel" name="accommodation[0][hotel]">
 <option value='0' selected='true' disabled='disabled'>--Choose Hotel--</option>
                   
    <option value="other">Other</option>
</select>


</div> 

<div class="col-md-4 other_hotel" style="display: none;">
<label>Enter Hotel</label>
  

  <input type="text" class="form-control" name="accommodation[0][other_hotel]" placeholder="Hotel Name">
</div>
<div class="col-md-4 add_star">

<label>Choose Star Rating</label>

<select class="form-control quo_star" name="accommodation[0][star]">
<option>--Select--</option>
<option value="other">Other</option>
</select>


</div> 
<div class="col-md-4 other_star" style="display: none;">
<label>Enter Star Rating</label>
  

  <input type="text" class="form-control" name="accommodation[0][star_other]" placeholder="Hotel Star Rating">
</div>
<div class="col-md-4">

<label>Room Category</label>
<input type="text" class="form-control" name="accommodation[0][category]" placeholder="Room Category">


</div> 
<div class="col-md-4">

<label>Hotel Website Link</label>
<input type="text" class="form-control" name="accommodation[0][hotel_link]" placeholder="Hotel Website Link">


</div>
</div>
</div>
  
</div>
<br>
<div class="row">
<div class="col-md-12">
<button type="button" name="add" id="add_acco_tours" days="" class="btn btn-success">Add More
</button> 
</div>
</div>

</div>

<div class="accommodation_extra" style="display: none;">
<label for="">Extra Accommodation</label>
<textarea class="form-control ckeditor" rows="3" name="accommodation_extra" >

</textarea> 
</div>

</div>  




</div>

</div>
</div>
<!---->
<div id="Itinerary" class="tab-pane fade">
 <div class="panel-body c_body">
<div class="row">
<div class="col-md-12">
<div class="table-responsive">


<div class="col-md-12 dayItinerary day1" >

<div class="row">
<label class="col-md-12">Day 1 : 
<input type="text" name="dayItinerary[day1][title]"  placeholder="Day Title" style="height: 35px;width: 93%;margin-left: 1%;margin-bottom: 10px;padding: 0 10px;">  </label>                             
</div>

<!--<div class="col-md-4">
<div class="form-group">
<label for="">City</label>
<select class='select2 form-control dayItineraryCity' name="dayItinerary[day1][city][]" multiple >


</select>
</div>


</div>                                 
<div class="col-md-3">
<div class="form-group">
<label for="">Hotel Name</label>
<select class='form-control dayItineraryhotel package_hot_add' name="dayItinerary[day1][hotelname]" >
<option value='0' selected='true' disabled='disabled'>--Choose Hotel--</option>
@foreach($package_hotel as $pk_hotel)
<option value='{{$pk_hotel->id}}'>{{$pk_hotel->hotelname}} </option>
@endforeach                        

</select>

</div>

</div>



<div class="col-md-2">

<button data-toggle="modal" data-target="#pk_aadhotel" class="btn-success btn-sm customn_package_hotel" style="margin-top: 22px;">Add Hotel</button>
</div>






<div class="col-md-3 h_star">
<div class="form-group">
<label for="">Hotel Star Rating</label>
<input type="text" name="dayItinerary[day1][star]" class="form-control add_star" readonly="">
                                
</div>


</div> -->
<div class="col-md-6">
<div class="form-group">
<label >Meal Plan</label>
<select name="dayItinerary[day1][meal_plan]" class="form-control">
<option value="N">NO Select</option>
<option value="EP">Room Only</option>

<option value="CP">Breakfast</option>
<option value="lu">Lunch</option>
<option value="di">Dinner</option>
<option value="bd">Breakfast & Dinner </option>
<option value="bl">Breakfast & Lunch </option>
<option value="ld">Lunch & Dinner</option>
<option value="bld">Breakfast & Lunch/Dinner </option>
<option value="bldall">Breakfast, Lunch & Dinner </option>                                          
<option value="MAP"> All Inclusive </option>

</select>                                       

</div>

</div>
<div class="col-md-6">
<div class=" form-group ">
<label >Included Tours</label>
<select class='select2 form-control dayItinerarytour custom_days' name="dayItinerary[day1][tours][]" multiple>
<!--@foreach($PkgTours as $key=>$tour)
<option value='{{$tour->id}}'>{{$tour->activity}} </option>
@endforeach -->                             


</select>
</div>
</div> 



<div class="col-md-12">
<div class="form-group">
<label for="">Description</label>
<textarea class="form-control ckeditor" rows="3" name="dayItinerary[day1][desc]" >

</textarea>
</div>
</div>                                

</div>
</div>
</div>                   
</div>
</div> 
</div>
<div id="Pricing" class="tab-pane fade">
  <div class="panel-body">
<div class="row">
<div class="col-md-12">
<div class="form-group">
<label for="">Is On Request?</label>
<input type="checkbox" value="1" name="onrequest" id="onrequest" checked/>

<!---->

<label for="" style="margin-left: 25px">Upcoming Package?</label>
<input type="checkbox" value="1" name="upcoming" id="upcoming" checked/>
</div>
<!---->
<div class="form-group pricelistpackage" style="display:none;">

<div class="table-responsive">
<table class="table table-bordered" id="dynamic_field">
<tr>
<th>Price title</th>
<th><input name="Price_title" placeholder="Title.." class="form-control" type="text" value="{{ old('Price_title') }}"></th>
<th>Price type</th>
<th>
<select name="Price_type" class="form-control">
<option value="0">Select Type </option>
<option value="Per Person">Per Person </option>
<option value="Per Group">Per Group</option>

</select>
</th>
<th></th>
</tr>
<tr>
<th>Package Rating</th>
<th>Price from</th>
<th>Price to</th>
<th>Cut Off Point</th>
<!--<th>Airfare </th>
<th>Hotel </th>
<th>Tours & Transfers </th>
<th>Total </th>-->
</tr>
<tr id="row1">
<td>
<select name="Price[0][package_rating]" id="rating" class="form-control" style="width: 90px">
@foreach($ratingType as $rtyp)
<option value='{{$rtyp->id}}'>{{$rtyp->name}} </option>
@endforeach                      


</select>

</td>
<td>
<div class="input-group date">
<div class="input-group-addon">
<i class="fa fa-calendar"></i>
</div>
<input name="Price[0][datefrom]" class="form-control pull-right datepicker"  type="text">
</div>

</td>
<td>
<div class="input-group date">
<div class="input-group-addon">
<i class="fa fa-calendar"></i>
</div>
<input  name="Price[0][dateto]" class="form-control pull-right datepicker" type="text">
</div>
</td>

<!--<td>
<div class="input-group" style="margin-bottom:5px;">
<span class="input-group-addon">
<select name="Price[0][currency]">
@foreach($rates as $rate)
<option value="{{ $rate-> rate}}" >{{ $rate-> currency}}</option>
@endforeach
</select>


</span>
<input name="Price[0][airfare]" class="form-control airfare" placeholder="Enter Airfare">


</div>
</td>
<td>
<div class="input-group" style="margin-bottom:5px;">

<input name="Price[0][hotel]" class="form-control hotel" placeholder="Enter Hotel Fare">


</div>
</td>
<td>
<div class="input-group" style="margin-bottom:5px;">

<input name="Price[0][tour_transfer]" class="form-control tour_transfer" placeholder="Enter Tour & Transfer Fare">


</div>
</td>
<td>
<div class="input-group total_value" style="margin-bottom:5px;">

<input name="Price[0][total]" class="form-control total" placeholder="Total Fare">


</div>
</td>-->
<td>
<input type="number" value="0" name="Price[0][cuttoffpoint]" class="form-control" placeholder="Cutt Off Days">
</td>
<td>
<div class="c_price0" id="c_price0">
<input type="hidden" name="Price[0][airfare_adult]" value="" class="air_fare_adult">
<input type="hidden" name="Price[0][airfare_exadult]" value="" class="air_fare_exadult">
<input type="hidden" name="Price[0][airfare_childbed]" value="" class="air_fare_childbed">
<input type="hidden" name="Price[0][airfare_childwbed]" value="" class="air_fare_childwbed">
<input type="hidden" name="Price[0][airfare_infant]" value="" class="air_fare_infant">
<input type="hidden" name="Price[0][airfare_single]" value="" class="air_fare_single">
<input type="hidden" name="Price[0][aircurrency]" value="" class="air_currency">
<!---->
<input type="hidden" name="Price[0][hotelfare_adult]" value="" class="hotel_fare_adult">
<input type="hidden" name="Price[0][hotelfare_exadult]" value="" class="hotel_fare_exadult">
<input type="hidden" name="Price[0][hotelfare_childbed]" value="" class="hotel_fare_childbed">
<input type="hidden" name="Price[0][hotelfare_childwbed]" value="" class="hotel_fare_childwbed">
<input type="hidden" name="Price[0][hotelfare_infant]" value="" class="hotel_fare_infant">
<input type="hidden" name="Price[0][hotelfare_single]" value="" class="hotel_fare_single">
<input type="hidden" name="Price[0][hotelcurrency]" value="" class="hotel_currency">
<!---->
<input type="hidden" name="Price[0][tourfare_adult]" value="" class="tour_fare_adult">
<input type="hidden" name="Price[0][tourfare_exadult]" value="" class="tour_fare_exadult">
<input type="hidden" name="Price[0][tourfare_childbed]" value="" class="tour_fare_childbed">
<input type="hidden" name="Price[0][tourfare_childwbed]" value="" class="tour_fare_childwbed">
<input type="hidden" name="Price[0][tourfare_infant]" value="" class="tour_fare_infant">
<input type="hidden" name="Price[0][tourfare_single]" value="" class="tour_fare_single">
<input type="hidden" name="Price[0][tourcurrency]" value="" class="tour_currency">
<!---->
<input type="hidden" name="Price[0][transferfare_adult]" value="" class="transfer_fare_adult">
<input type="hidden" name="Price[0][transferfare_exadult]" value="" class="transfer_fare_exadult">
<input type="hidden" name="Price[0][transferfare_childbed]" value="" class="transfer_fare_childbed">
<input type="hidden" name="Price[0][transferfare_childwbed]" value="" class="transfer_fare_childwbed">
<input type="hidden" name="Price[0][transferfare_infant]" value="" class="transfer_fare_infant">
<input type="hidden" name="Price[0][transferfare_single]" value="" class="transfer_fare_single">
<input type="hidden" name="Price[0][transfercurrency]" value="" class="transfer_currency">
<!---->
<input type="hidden" name="Price[0][visafare_adult]" value="" class="visa_fare_adult">
<input type="hidden" name="Price[0][visafare_exadult]" value="" class="visa_fare_exadult">
<input type="hidden" name="Price[0][visafare_childbed]" value="" class="visa_fare_childbed">
<input type="hidden" name="Price[0][visafare_childwbed]" value="" class="visa_fare_childwbed">
<input type="hidden" name="Price[0][visafare_infant]" value="" class="visa_fare_infant">
<input type="hidden" name="Price[0][visafare_single]" value="" class="visa_fare_single">
<input type="hidden" name="Price[0][visacurrency]" value="" class="visa_currency">
<!---->
<input type="hidden" name="Price[0][adult_fare_total]" value="" class="adult_fare_total">
<input type="hidden" name="Price[0][exadult_fare_total]" value="" class="exadult_fare_total">
<input type="hidden" name="Price[0][childwithbed_fare_total]" value="" class="childwithbed_fare_total">
<input type="hidden" name="Price[0][childwithoutbed_fare_total]" value="" class="childwithoutbed_fare_total">
<input type="hidden" name="Price[0][infant_fare_total]" value="" class="infant_fare_total">
<input type="hidden" name="Price[0][single_fare_total]" value="" class="single_fare_total">


</div>
<button type="button" class="btn btn-info btn-lg price_add" data-toggle="modal" data-id="c_price0">Add Price</button>
</td>

</tr>
</table>

<button type="button" name="add" id="add-price-row" class="btn btn-success" style="margin-left: 10px">Add More
</button>
</div>

</div>

<!--upcoming start-->
<div class="form-group pricelistpackage_upcoming" style="display:none;">
<div class="table-responsive">
<table class="table table-bordered" id="dynamic_field_upcoming">
<tr>
<th>Price title</th>
<th><input name="Price_title_upcoming" placeholder="Title.." class="form-control" type="text" value="{{ old('Price_title') }}"></th>
<th>Price type</th>
<th>
<select name="Price_type_upcoming" class="form-control">
<option value="0">Select Type </option>
<option value="Per Person">Per Person </option>
<option value="Per Group">Per Group</option>

</select>
</th>
<th></th>
</tr>
<tr>
<th>Package Rating</th>
<th>Price from</th>
<th>Price to</th>
<th>Cut Off Point</th>
<!--<th>Airfare </th>
<th>Hotel </th>
<th>Tours & Transfers </th>
<th>Total </th>-->
</tr>
<tr id="up_row1">
<td>
<select name="Price_upcoming[0][package_rating]" id="rating_upcoming" class="form-control" style="width: 90px">
@foreach($ratingType as $rtyp)
<option value='{{$rtyp->id}}'>{{$rtyp->name}} </option>
@endforeach                      


</select>

</td>
<td>
<div class="input-group date">
<div class="input-group-addon">
<i class="fa fa-calendar"></i>
</div>
<input name="Price_upcoming[0][datefrom]" class="form-control pull-right datepicker"  type="text">
</div>

</td>
<td>
<div class="input-group date">
<div class="input-group-addon">
<i class="fa fa-calendar"></i>
</div>
<input  name="Price_upcoming[0][dateto]" class="form-control pull-right datepicker" type="text">
</div>
</td>


<td>
<input type="number" value="0" name="Price_upcoming[0][cuttoffpoint]" class="form-control" placeholder="Cutt Off Days">
</td>
<td>
<div class="cup_price0" id="cup_price0">
<input type="hidden" name="Price_upcoming[0][airfare_adult]" value="" class="air_fare_adult">
<input type="hidden" name="Price_upcoming[0][airfare_exadult]" value="" class="air_fare_exadult">
<input type="hidden" name="Price_upcoming[0][airfare_childbed]" value="" class="air_fare_childbed">
<input type="hidden" name="Price_upcoming[0][airfare_childwbed]" value="" class="air_fare_childwbed">
<input type="hidden" name="Price_upcoming[0][airfare_infant]" value="" class="air_fare_infant">
<input type="hidden" name="Price_upcoming[0][airfare_single]" value="" class="air_fare_single">
<input type="hidden" name="Price_upcoming[0][aircurrency]" value="" class="air_currency">
<!---->
<input type="hidden" name="Price_upcoming[0][hotelfare_adult]" value="" class="hotel_fare_adult">
<input type="hidden" name="Price_upcoming[0][hotelfare_exadult]" value="" class="hotel_fare_exadult">
<input type="hidden" name="Price_upcoming[0][hotelfare_childbed]" value="" class="hotel_fare_childbed">
<input type="hidden" name="Price_upcoming[0][hotelfare_childwbed]" value="" class="hotel_fare_childwbed">
<input type="hidden" name="Price_upcoming[0][hotelfare_infant]" value="" class="hotel_fare_infant">
<input type="hidden" name="Price_upcoming[0][hotelfare_single]" value="" class="hotel_fare_single">
<input type="hidden" name="Price_upcoming[0][hotelcurrency]" value="" class="hotel_currency">
<!---->
<input type="hidden" name="Price_upcoming[0][tourfare_adult]" value="" class="tour_fare_adult">
<input type="hidden" name="Price_upcoming[0][tourfare_exadult]" value="" class="tour_fare_exadult">
<input type="hidden" name="Price_upcoming[0][tourfare_childbed]" value="" class="tour_fare_childbed">
<input type="hidden" name="Price_upcoming[0][tourfare_childwbed]" value="" class="tour_fare_childwbed">
<input type="hidden" name="Price_upcoming[0][tourfare_infant]" value="" class="tour_fare_infant">
<input type="hidden" name="Price_upcoming[0][tourfare_single]" value="" class="tour_fare_single">
<input type="hidden" name="Price_upcoming[0][tourcurrency]" value="" class="tour_currency">
<!---->
<input type="hidden" name="Price_upcoming[0][transferfare_adult]" value="" class="transfer_fare_adult">
<input type="hidden" name="Price_upcoming[0][transferfare_exadult]" value="" class="transfer_fare_exadult">
<input type="hidden" name="Price_upcoming[0][transferfare_childbed]" value="" class="transfer_fare_childbed">
<input type="hidden" name="Price_upcoming[0][transferfare_childwbed]" value="" class="transfer_fare_childwbed">
<input type="hidden" name="Price_upcoming[0][transferfare_infant]" value="" class="transfer_fare_infant">
<input type="hidden" name="Price_upcoming[0][transferfare_single]" value="" class="transfer_fare_single">
<input type="hidden" name="Price_upcoming[0][transfercurrency]" value="" class="transfer_currency">
<!---->
<input type="hidden" name="Price_upcoming[0][visafare_adult]" value="" class="visa_fare_adult">
<input type="hidden" name="Price_upcoming[0][visafare_exadult]" value="" class="visa_fare_exadult">
<input type="hidden" name="Price_upcoming[0][visafare_childbed]" value="" class="visa_fare_childbed">
<input type="hidden" name="Price_upcoming[0][visafare_childwbed]" value="" class="visa_fare_childwbed">
<input type="hidden" name="Price_upcoming[0][visafare_infant]" value="" class="visa_fare_infant">
<input type="hidden" name="Price_upcoming[0][visafare_single]" value="" class="visa_fare_single">
<input type="hidden" name="Price_upcoming[0][visacurrency]" value="" class="visa_currency">
<!---->
<input type="hidden" name="Price_upcoming[0][adult_fare_total]" value="" class="adult_fare_total">
<input type="hidden" name="Price_upcoming[0][exadult_fare_total]" value="" class="exadult_fare_total">
<input type="hidden" name="Price_upcoming[0][childwithbed_fare_total]" value="" class="childwithbed_fare_total">
<input type="hidden" name="Price_upcoming[0][childwithoutbed_fare_total]" value="" class="childwithoutbed_fare_total">
<input type="hidden" name="Price_upcoming[0][infant_fare_total]" value="" class="infant_fare_total">
<input type="hidden" name="Price_upcoming[0][single_fare_total]" value="" class="single_fare_total">


</div>
<button type="button" class="btn btn-info btn-lg price_add" data-toggle="modal" data-id="cup_price0">Add Price</button>
</td>

</tr>
</table>

<button type="button" name="add" id="add_upcoming_price_row" class="btn btn-success" style="margin-left: 10px">Add More
</button>
</div>
</div>

<!--upcoming end-->
</div>
</div>

</div>
<!---->
<div id="price_add" class="modal fade" role="dialog">
<div class="modal-dialog">

<!-- Modal content-->
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<h4 class="modal-title">Add Price</h4>
</div>
<div class="modal-body">
<input type="hidden" name="" value="" class="price_class">
<div class="table-responsive">          
<table class="table">
<thead>
<th></th>
<th>Currency</th>
<th>Adult <br> (Twin Sharing)</th>
<th>Extra Adult</th>
<th>Child <br> (With Bed)</th>
<th>Child <br> (Without Bed)</th>
<th>Infant </th>
<th>Single <br> Supplement</th>
</thead>
<tbody>
<tr>
<td style="padding-top: 16px;"><strong>Air Fare</strong></td>

<td>
<select class="form-control a_curr">


</select>
</td>
<td>
<input class="form-control airfare_adult" placeholder="Airfare" value="">
</td>
<td>
<input class="form-control airfare_exadult" placeholder="Airfare" value="">
</td>
<td>
<input class="form-control airfare_childbed" placeholder="Airfare" value="">
</td>
<td>
<input class="form-control airfare_childwbed" placeholder="Airfare" value="">
</td>
<td>
<input class="form-control airfare_infant" placeholder="Airfare" value="">
</td>
<td>
<input class="form-control airfare_single" placeholder="Airfare" value="">
</td>
</tr>
<!--seperate-->

<tr>
<td style="padding-top: 16px;"><strong>Hotel</strong></td>

<td>
<select class="form-control h_curr">

</select>
</td>
<td>
<input class="form-control hotelfare_adult" placeholder="Hotel Fare" value="">
</td>
<td>
<input class="form-control hotelfare_exadult" placeholder="Hotel Fare" value="">
</td>
<td>
<input class="form-control hotelfare_childbed" placeholder="Hotel Fare" value="">
</td>
<td>
<input class="form-control hotelfare_childwbed" placeholder="Hotel Fare" value="">
</td>
<td>
<input class="form-control hotelfare_infant" placeholder="Hotel Fare" value="">
</td>
<td>
<input class="form-control hotelfare_single" placeholder="Hotel Fare" value="">
</td>
</tr>
<!--seperate-->
<tr>
<td style="padding-top: 16px;"><strong>Tours</strong></td>

<td>
<select class="form-control t_curr">

</select>
</td>
<td>
<input class="form-control tourfare_adult" placeholder="Tour Fare" value="">
</td>
<td>
<input class="form-control tourfare_exadult" placeholder="Tour Fare" value="">
</td>
<td>
<input class="form-control tourfare_childbed" placeholder="Tour Fare" value="">
</td>
<td>
<input class="form-control tourfare_childwbed" placeholder="Tour Fare" value="">
</td>
<td>
<input class="form-control tourfare_infant" placeholder="Tour Fare" value="">
</td>
<td>
<input class="form-control tourfare_single" placeholder="Tour Fare" value="">
</td>
</tr>
<!--seperate-->
<tr>
<td style="padding-top: 16px;"><strong>Transfers</strong></td>

<td>
<select class="form-control to_curr">

</select>
</td>
<td>
<input class="form-control transferfare_adult" placeholder="Transfer Fare" value="">
</td>
<td>
<input class="form-control transferfare_exadult" placeholder="Transfer Fare" value="">
</td>
<td>
<input class="form-control transferfare_childbed" placeholder="Transfer Fare" value="">
</td>
<td>
<input class="form-control transferfare_childwbed" placeholder="Transfer Fare" value="">
</td>
<td>
<input class="form-control transferfare_infant" placeholder="Transfer Fare" value="">
</td>
<td>
<input class="form-control transferfare_single" placeholder="Transfer Fare" value="">
</td>
</tr>
<!--seperate-->
<tr>
<td style="padding-top: 16px;"><strong>Visa</strong></td>

<td>
<select class="form-control v_curr">

</select>
</td>
<td>
<input class="form-control visafare_adult" placeholder="Visa Fare" value="">
</td>
<td>
<input class="form-control visafare_exadult" placeholder="Visa Fare" value="">
</td>
<td>
<input class="form-control visafare_childbed" placeholder="Visa Fare" value="">
</td>
<td>
<input class="form-control visafare_childwbed" placeholder="Visa Fare" value="">
</td>
<td>
<input class="form-control visafare_infant" placeholder="Visa Fare" value="">
</td>
<td>
<input class="form-control visafare_single" placeholder="Visa Fare" value="">
</td>
</tr>
<!--seperate-->
<tr>
<td style="padding-top: 16px;"><strong>Total</strong></td>
<td><select class="form-control">
<option selected="disabled">INR</option>           
</select></td>
<td>
<input class="form-control adult_total"  value="" readonly>
</td>
<td>
<input class="form-control extraadult_total"  value="" readonly>
</td>
<td>
<input class="form-control childwithbed_total"  value="" readonly>
</td>
<td>
<input class="form-control childwithoutbed_total "  value="" readonly>
</td>
<td>
<input class="form-control infant_total"  value="" readonly>
</td>
<td>
<input class="form-control single_total"  value="" readonly>
</td>
</tr>

<!--seperate-->



</tbody>
</table>
</div>
</div>
<div class="modal-footer">

<button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
<button type="button" class="btn btn-success" id="submit_price" data-dismiss="modal">Submit</button>
</div>
</div>

</div>
</div>
</div>
<div id="Supplier" class="tab-pane fade">
 <div class="panel-body">
<div class="row">
<div class="col-md-12">
<div class="form-group">
<input type="text" class="form-control" name="supplier_name" placeholder="Name" value="" />
</div>
<div class="form-group">
<input type="text" class="form-control" name="supplier_contact_no" placeholder="Contact No"  value="" />
</div>
<div class="form-group">
<input type="text" class="form-control" name="supplier_emailId" placeholder="Email Id" 
value="" />
</div>
<div class="form-group">
<input type="text" class="form-control" name="supplier_price" placeholder="Price" 
value="0" />
</div>

<div class="form-group">
<textarea class="form-control" name="supplier_address" placeholder="Address" >
{{ old('supplier_address') }}
</textarea>
</div>
</div>
</div>

</div> 
</div>
 @if(Sentinel::check())
 @if(Sentinel::getUser()->inRole('super_admin'))
<div id="META" class="tab-pane fade">
  <div class="panel-body">
<div class="row">
<div class="col-md-12">
  <h4>The Worldgateway SEO</h4>
<div class="form-group">
<input type="text" class="form-control" name="meta_title" placeholder="Title" value="{{ old('meta_title') }}" />
</div>
<div class="form-group">
<input type="text" class="form-control" name="meta_desc" placeholder="Description" value="{{ old('meta_desc') }}" />
</div>
<div class="form-group">
<textarea class="form-control" name="meta_keyword" placeholder="Keywords">
{{ old('meta_keyword') }}</textarea>
</div>
</div>
</div>
<!---->
<div class="row">
<div class="col-md-12">
  <h4>Rapidex Travels SEO</h4>
<div class="form-group">
<input type="text" class="form-control" name="rapidex_meta_title" placeholder="Title" value="{{ old('rapidex_meta_title') }}" />
</div>
<div class="form-group">
<input type="text" class="form-control" name="rapidex_meta_desc" placeholder="Description" value="{{ old('rapidex_meta_desc') }}" />
</div>
<div class="form-group">
<textarea class="form-control" name="rapidex_meta_keyword" placeholder="Keywords">
{{ old('rapidex_meta_keyword') }}</textarea>
</div>
</div>
</div>
<!---->
</div>
</div>
@endif
@endif
<div id="Additional" class="tab-pane fade">
  <div class="panel-body">
<div class="row">
<div class="col-md-12">
<h4>Terms & Conditions   </h4>


<div class="form-group">
<label for="">Is Visa Required?</label>
<input type="checkbox" name="visa" value="1" id="customize_onrequestvisa" checked/>
</div>
<div class="costomize_tour_visa">
  <h5>Visa Terms & Policies</h5>

<table class="table table-bordered" id="dynamic_field">
<tbody>
<tr>
<td style="width: 60%;">
<div>
<select name="package_visa[]"  class="select2 form-control" multiple>

@foreach($visaPolicy as $pol)
<option value="{{$pol->id}}">{{$pol->policy}} </option>

@endforeach



</select>


</div>
</td>
</tr>
<tr>                                         
<td>
<textarea  name="visa_policies" placeholder="Please state your Extra visa Policies..." rows="6" class="form-control">
</textarea>
<!-- <input type="hidden" name="visa_policies" id="visa_policies_input" value=""/>-->
</td>
</tr>
</tbody>
</table>
</div>

<h5>Payment Terms & Methods </h5>

<table class="table table-bordered" id="dynamic_field">
<tbody>
<tr>
<td style="width: 60%;"> <div>

<select name="package_payment[]"  class="select2 form-control" multiple>
@foreach($paymentPolicy as $pol)
<option value="{{$pol->id}}">{{$pol->policy}} </option>

@endforeach
<select>



</div>
</td>
</tr>
<tr>                                           
<td>
<textarea  name="payment_policies" placeholder="Please state your Payment Terms and Methods..." rows="6" class="form-control">
</textarea>
<!-- <input type="hidden" name="payment_policies" id="payment_policies_input" value=""/>-->
</td>
</tr>
</tbody>
</table>
<h5>Cancellation & Refund Policy
</h5>
<table class="table table-bordered" id="dynamic_field">
<tbody>
<tr>
<td style="width: 60%;">
<div>

<select name="package_can[]"  class="select2 form-control" multiple>
@foreach($cancelPolicy as $pol)
<option value="{{$pol->id}}">{{$pol->policy}} </option>

@endforeach
<select>





</div>
</td>
</tr>
<tr> 
<td>
<textarea  name="cancellation" placeholder="Please state your Cancellation Terms & Refund Policy..." rows="6" class="form-control">
</textarea>                                             

<!--<input type="hidden" name="cancellation" id="cancellation_input_field" value=""/>-->
</td>
</tr>
</tbody>
</table>

<!---->
<h5>Important Notes
</h5>
<table class="table table-bordered" >
<tbody>
<tr>
<td style="width: 60%;">
<div>

<select name="package_impnotes[]"  class="select2 form-control" multiple>
@foreach($imp_notes as $pol)
<option value="{{$pol->id}}">{{$pol->policy}} </option>

@endforeach
<select>





</div>
</td>
</tr>
<tr> 
<td>
<textarea  name="extra_imp" placeholder="Please state your Important Notes..." rows="6" class="form-control">
</textarea>                                             

<!--<input type="hidden" name="cancellation" id="cancellation_input_field" value=""/>-->
</td>
</tr>
</tbody>
</table>

</div>
</div>

</div>
</div>
</div>





<!-- end-->


<div style="text-align: center;">

<button type="submit" name="add" id="remove" class="btn btn-danger btn-lg location_add">Save 
<i class="fa  fa-arrow-right"></i>

</button>
</div>
</form>
<!-- TAB-1 INNAR HTML END -->

</div>
</div>
<div class="tab-pane" id="orange">
@if ($errors->any())
<div class="alert alert-warning">
<ul>
@foreach ($errors->all() as $error)
<li>{{ $error }}</li>
@endforeach
</ul>
</div>
@endif
<!-- TAB-1 INNAR HTML START -->


<!--accordion -->
<div class="col-md-12">
<form action="{{URL::to('/store-package')}}" method="post" >
<input type="hidden" name="type" value="Hotel Package"/>
{{csrf_field()}}
<br>
<div class="panel-group" id="accordion">
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title">
<a data-toggle="collapse" data-parent="#accordion" href="#InfoHotel"><span class="glyphicon glyphicon-file">
</span> Package Info</a>
</h4>
</div>
<div id="InfoHotel" class="panel-collapse collapse in">
<div class="panel-body">
<div class="row">
<div class="col-md-12">
<div class="col-md-4 form-group">
<select name="category" id="categoryHotel" class="form-control">
<option value="domestic">Domestic
</option>
<option value="international">International
</option>

</select>
</div>

<div class="col-md-8 form-group">
<div class="input-group" style="margin-bottom:5px;">
<span class="input-group-addon">
<i class="fa fa-map-marker">
</i>
</span>
<select name="package_hotel" id="package_dest_hotel" class="form-control select2">
<option value="0">*Select Hotel</option>
@foreach($hotel as $hot)
<option value='{{$hot->id}}'>{{$hot->name}}
</option>
@endforeach 
</select>

</div>

</div>

</div>
</div>
<div class="row">
<div class="col-md-12">
<div class="col-md-4 form-group">
<input type="text" placeholder="Title" value="" name="package_name" class="form-control">
</div>
<div class="col-md-4 form-group">
<select name="package_category[]" placeholder="Theme" id="package_category" class="select2 form-control" multiple>

@foreach($types as $typ)
<option value="{{$typ->name}}">{{$typ->name}}
</option>
@endforeach



</select>
</div>


<div class="col-md-4 form-group">
<select name="duration" id="package_durations" class="form-control">
<option value="1">1 Night/2 Days
</option>
<option value="2">2 Night/3 Days
</option>
<option value="3">3 Night/4 Days
</option>
<option value="4">4 Night/5 Days
</option>
<option value="5">5 Night/6 Days
</option>
</select>
</div>

</div>
</div>

</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title">
<a data-toggle="collapse" data-parent="#accordion" href="#OverviewHotel"><span class="glyphicon glyphicon-th-list">
</span> Package Overview</a>
</h4>
</div>
<div id="OverviewHotel" class="panel-collapse collapse">
<div class="panel-body">
<div class="row">
<div class="col-md-12">
<div class="col-md-6">
<div class="form-group">
<textarea class="form-control" placeholder="Package Description..." name="description" id="" cols="30" rows="5"></textarea>
</div>
<div class="form-group">
<label for="">Package Rating</label>
<select name="package_rating" id="rating" class="form-control">
@foreach($ratingType as $rtyp)
<option value='{{$rtyp->id}}'>{{$rtyp->name}}
</option>
@endforeach 

</select>
</div>
</div>
<div class="col-md-6">
<div class="form-group">
<label for="">Transport</label>
<select name="transport" id="transport" class="form-control">
<option value="Flights">Flights
</option>
<option value="Trains">Trains
</option>

</select>
</div>


<div class="form-group select-container">
<label for="">Accommodation</label>
<select name="accommodation[]" id="accommodation" class="select2 form-control" multiple>
@foreach($hotel as $hot)
<option value='{{$hot->id}}'>{{$hot->name}}
</option>
@endforeach 

</select>
</div>
<div class="form-group select-container">
<label >Tours</label>
<select class='select2 form-control' name="tours[]" multiple>
@foreach($PkgTours as $key=>$tour)
<option value='{{$tour->id}}'>{{$tour->activity}}
</option>
@endforeach 

</select>
</div>
</div>
</div>
</div>
<div class="row">
<div class="col-md-12">
<div class="col-md-6">
<div class="form-group select-container">
<label >Inclusions</label>
<select class='select2 form-control' name="inclusions[]" multiple>
@foreach($inclusions as $key=>$inc)
<option value='{{$inc->name}}'>{{$inc->name}}
</option>
@endforeach 

</select>
</div>
</div>
<div class="col-md-6">
<div class=" form-group ">
<label >Exclusions</label>
<select class='select2 form-control' name="exclusions[]" multiple>
@foreach($exclusions as $key=>$exc)
<option value='{{$exc->name}}'>{{$exc->name}}
</option>
@endforeach 

</select>
</div>
</div>
</div>
</div>
</div>
</div>
</div>



<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title">
<a data-toggle="collapse" data-parent="#accordion" href="#METAHotel"><i class="fa fa-database" aria-hidden="true"></i> SEO Data</a>
</h4>
</div>
<div id="METAHotel" class="panel-collapse collapse">
<div class="panel-body">
<div class="row">
<div class="col-md-12">
<div class="form-group">
<input type="text" class="form-control" name="meta_title" placeholder="Title" required />
</div>
<div class="form-group">
<input type="text" class="form-control" name="meta_desc" placeholder="Description" required />
</div>
<div class="form-group">
<textarea class="form-control" name="meta_keyword" placeholder="Keywords" required></textarea>
</div>
</div>
</div>
<!---->
<div class="row">
<div class="col-md-12">
<div class="form-group">
<input type="text" class="form-control" name="meta_title" placeholder="Title" required />
</div>
<div class="form-group">
<input type="text" class="form-control" name="meta_desc" placeholder="Description" required />
</div>
<div class="form-group">
<textarea class="form-control" name="meta_keyword" placeholder="Keywords" required></textarea>
</div>
</div>
</div>

<!---->
</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title">
<a data-toggle="collapse" data-parent="#accordion" href="#SupplierHotel"><i class="fa fa-suitcase" aria-hidden="true"></i> Supplier Information</a>
</h4>
</div>
<div id="SupplierHotel" class="panel-collapse collapse">
<div class="panel-body">
<div class="row">
<div class="col-md-12">
<div class="form-group">
<input type="text" class="form-control" name="supplier_name" placeholder="Name" required />
</div>
<div class="form-group">
<input type="text" class="form-control" name="supplier_contact_no" placeholder="Contact No" required />
</div>
<div class="form-group">
<input type="text" class="form-control" name="supplier_emailId" placeholder="Email Id" required />
</div>
<div class="form-group">
<input type="text" class="form-control" name="supplier_price" placeholder="Price" required />
</div>

<div class="form-group">
<textarea class="form-control" name="supplier_address" placeholder="Address" required></textarea>
</div>
</div>
</div>

</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title">
<a data-toggle="collapse" data-parent="#accordion" href="#PricingHotel"><i class="fa fa-inr" aria-hidden="true"></i> Pricing</a>
</h4>
</div>
<div id="PricingHotel" class="panel-collapse collapse">
<div class="panel-body">
<div class="row">
<div class="col-md-12">
<div class="form-group">
<label for="">Is On Request?</label>
<input type="checkbox" value="1" name="onrequest" id="onrequest" checked/>
</div>
<div class="form-group pricelistpackage" style="display:none;">

<div class="table-responsive">
<table class="table table-bordered" id="dynamic_field">
<tr>
<th>Price title</th>
<th>Price from</th>
<th>Price to</th>
<th>Price type</th>
<th>Price</th>
</tr>
<tr>
<td>
<input name="Price[0][desc]" placeholder="Title.." class="form-control" type="text">

</td>
<td>
<div class="input-group date">
<div class="input-group-addon">
<i class="fa fa-calendar"></i>
</div>
<input name="Price[0][datefrom]" class="form-control pull-right datepicker"  type="text">
</div>

</td>
<td>
<div class="input-group date">
<div class="input-group-addon">
<i class="fa fa-calendar"></i>
</div>
<input  name="Price[0][dateto]" class="form-control pull-right datepicker" type="text">
</div>
</td>
<td>
<select name="Price[0][for]" class="form-control">
<option value="0">Select Type </option>
<option value="1">Per Person </option>
<option value="2">Per Night </option>
<option value="2">Per Price </option>
</select>
</td>
<td>
<div class="input-group" style="margin-bottom:5px;">
<span class="input-group-addon">INR
</span>
<input name="Price[0][cost]" class="form-control" placeholder="Price">
</div>
</td>
<td>
<button type="button" name="add" id="add-price-row" class="btn btn-success">Add More
</button>
</td>
</tr>
</table>
</div>

</div>
</div>
</div>

</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title">
<a data-toggle="collapse" data-parent="#accordion" href="#AdditionalHotel"><span class="glyphicon glyphicon-th-list">
</span> Additional Information</a>
</h4>
</div>
<div id="AdditionalHotel" class="panel-collapse collapse">
<div class="panel-body">
<div class="row">
<div class="col-md-12">
<h4>Terms & Conditions
</h4>

<div class="form-group">
<label for="">Is Visa Required?</label>
<input type="checkbox" name="visa" value="1" id="onrequestvisa" checked/>
</div>
<h5>Visa Terms & Policies
</h5>
<table class="table table-bordered" id="dynamic_field">
<tbody>
<tr>
<td style="width: 60%;">
<div>
@foreach($visaPolicy as $pol)
<div class="checkbox">
<label>
<input class="visaMethods" value="{{$pol->policy}}" lang="{{$pol->id}}" type="checkbox">{{$pol->policy}}
</label>
</div>
@endforeach

</div>
</td>

<td>
<textarea  id="visa_policies" placeholder="Please state your Payment Terms and Methods..." rows="3" class="form-control">
</textarea>
<input type="hidden" name="visa_policies" id="visa_policies_input" value=""/>
</td>
</tr>
</tbody>
</table>

<h5>Payment Terms & Methods
</h5>
<table class="table table-bordered" id="dynamic_field">
<tbody>
<tr>
<td style="width: 60%;">
<div>
@foreach($paymentPolicy as $pol)
<div class="checkbox">
<label>
<input class="paymentMethods" value="{{$pol->policy}}" lang="{{$pol->id}}" type="checkbox">{{$pol->policy}}
</label>
</div>
@endforeach

</div>
</td>

<td>
<textarea  id="payment_policies" placeholder="Please state your Payment Terms and Methods..." rows="3" class="form-control">
</textarea>
<input type="hidden" name="payment_policies" id="payment_policies_input" value=""/>
</td>
</tr>
</tbody>
</table>
<h5>Cancellation & Refund Policy
</h5>
<table class="table table-bordered" id="dynamic_field">
<tbody>
<tr>
<td style="width: 60%;">
<div>
@foreach($cancelPolicy as $can)
<div class="checkbox">
<label>
<input class="cancellation" id="cancellation_input" value="{{$can->policy}}" lang="{{$can->id}}"  type="checkbox">{{$can->policy}}
</label>
</div>
@endforeach

</div>
</td>
<td>
<textarea  id="cancle_policy" placeholder="Please state your Payment Terms and Methods..." rows="3" class="form-control">
</textarea>

<input type="hidden" name="cancellation" id="cancellation_input_field" value=""/>
</td>
</tr>
</tbody>
</table>

</div>
</div>

</div>
</div>
</div>

</div>
<!-- end-->


<div style="text-align: center;">

<button type="submit" name="add" id="remove" class="btn btn-danger btn-lg">Save 
<i class="fa  fa-arrow-right">
</i>
</button>
</div>
</form>
<!-- TAB-1 INNAR HTML END -->
<!-- TAB-2 INNAR HTML END -->
</div>
</div>
<div class="tab-pane" id="yellow">
<!-- TAB-3 INNAR HTML START -->
@if ($errors->any())
<div class="alert alert-warning">
<ul>
@foreach ($errors->all() as $error)
<li>{{ $error }}</li>
@endforeach
</ul>
</div>
@endif
<!-- TAB-1 INNAR HTML START -->


<!--accordion -->
<div class="col-md-12">
<form action="{{URL::to('/store-package')}}" method="post" >
<input type="hidden" name="type" value="Group Package"/>
{{csrf_field()}}
<br>
<div class="panel-group" id="accordion">
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title">
<a data-toggle="collapse" data-parent="#accordion" href="#InfoHotel"><span class="glyphicon glyphicon-file">
</span> Package Info</a>
</h4>
</div>
<div id="InfoHotel" class="panel-collapse collapse in">
<div class="panel-body">
<div class="row">
<div class="col-md-12">
<div class="col-md-4 form-group">
<select name="category" id="category" class="form-control">
<option value="domestic">Domestic
</option>
<option value="international">International
</option>

</select>
</div>
<div class="col-md-4 form-group">
<select name="country" id="package_dest_country" class="form-control">
<option value="0">*Select Destination Country</option>
@foreach($country as $count)
<option value="{{$count->city_state}}">{{$count->city_state}}
</option>
@endforeach
</select>
</div>
<div class="col-md-4 form-group">
<div class="input-group" style="margin-bottom:5px;">
<span class="input-group-addon">
<i class="fa fa-map-marker">
</i>
</span>
<select name="package_destination" id="package_dest_city" class="form-control">
<option value="0">*Select Destination City</option>

</select>

</div>

</div>

</div>
</div>
<div class="row">
<div class="col-md-12">
<div class="col-md-4 form-group">
<input type="text" placeholder="Title" value="" name="package_name" class="form-control">
</div>
<div class="col-md-4 form-group">
<select name="package_category[]" placeholder="Theme" id="package_category" class="select2 form-control" multiple>

@foreach($types as $typ)
<option value="{{$typ->name}}">{{$typ->name}}
</option>
@endforeach



</select>
</div>


<div class="col-md-4 form-group">
<select name="duration" id="package_durations" class="form-control">
<option value="1">1 Night/2 Days
</option>
<option value="2">2 Night/3 Days
</option>
<option value="3">3 Night/4 Days
</option>
<option value="4">4 Night/5 Days
</option>
<option value="5">5 Night/6 Days
</option>
</select>
</div>

</div>
</div>

</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title">
<a data-toggle="collapse" data-parent="#accordion" href="#OverviewHotel"><span class="glyphicon glyphicon-th-list">
</span> Package Overview</a>
</h4>
</div>
<div id="OverviewHotel" class="panel-collapse collapse">
<div class="panel-body">
<div class="row">
<div class="col-md-12">
<div class="col-md-6">
<div class="form-group">
<textarea class="form-control" placeholder="Package Description..." name="description" id="" cols="30" rows="5"></textarea>
</div>
<div class="form-group">
<label for="">Package Rating</label>
<select name="package_rating" id="rating" class="form-control">
@foreach($ratingType as $rtyp)
<option value='{{$rtyp->id}}'>{{$rtyp->name}}
</option>
@endforeach 

</select>
</div>
</div>
<div class="col-md-6">
<div class="form-group">
<label for="">Transport</label>
<select name="transport" id="transport" class="form-control">
<option value="Flights">Flights
</option>
<option value="Trains">Trains
</option>

</select>
</div>


<div class="form-group select-container">
<label for="">Accommodation</label>
<select name="accommodation[]" id="accommodation" class="select2 form-control" multiple>
@foreach($hotel as $hot)
<option value='{{$hot->id}}'>{{$hot->name}}
</option>
@endforeach 

</select>
</div>
<div class="form-group select-container">
<label >Tours</label>
<select class='select2 form-control' name="tours[]" multiple>
@foreach($PkgTours as $key=>$tour)
<option value='{{$tour->id}}'>{{$tour->activity}}
</option>
@endforeach 

</select>
</div>
</div>
</div>
</div>
<div class="row">
<div class="col-md-12">
<div class="col-md-6">
<div class="form-group select-container">
<label >Inclusions</label>
<select class='select2 form-control' name="inclusions[]" multiple>
@foreach($inclusions as $key=>$inc)
<option value='{{$inc->name}}'>{{$inc->name}}
</option>
@endforeach 

</select>
</div>
</div>
<div class="col-md-6">
<div class=" form-group ">
<label >Exclusions</label>
<select class='select2 form-control' name="exclusions[]" multiple>
@foreach($exclusions as $key=>$exc)
<option value='{{$exc->name}}'>{{$exc->name}}
</option>
@endforeach 

</select>
</div>
</div>
</div>
</div>
</div>
</div>
</div>



<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title">
<a data-toggle="collapse" data-parent="#accordion" href="#METAHotel"><i class="fa fa-database" aria-hidden="true"></i> SEO Data</a>
</h4>
</div>
<div id="METAHotel" class="panel-collapse collapse">
<div class="panel-body">
<div class="row">
<div class="col-md-12">
<div class="form-group">
<input type="text" class="form-control" name="meta_title" placeholder="Title" required />
</div>
<div class="form-group">
<input type="text" class="form-control" name="meta_desc" placeholder="Description" required />
</div>
<div class="form-group">
<textarea class="form-control" name="meta_keyword" placeholder="Keywords" required></textarea>
</div>
</div>
</div>

</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title">
<a data-toggle="collapse" data-parent="#accordion" href="#SupplierHotel"><i class="fa fa-suitcase" aria-hidden="true"></i> Supplier Information</a>
</h4>
</div>
<div id="SupplierHotel" class="panel-collapse collapse">
<div class="panel-body">
<div class="row">
<div class="col-md-12">
<div class="form-group">
<input type="text" class="form-control" name="supplier_name" placeholder="Name" required />
</div>
<div class="form-group">
<input type="text" class="form-control" name="supplier_contact_no" placeholder="Contact No" required />
</div>
<div class="form-group">
<input type="text" class="form-control" name="supplier_emailId" placeholder="Email Id" required />
</div>
<div class="form-group">
<input type="text" class="form-control" name="supplier_price" placeholder="Price" required />
</div>

<div class="form-group">
<textarea class="form-control" name="supplier_address" placeholder="Address" required></textarea>
</div>
</div>
</div>

</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title">
<a data-toggle="collapse" data-parent="#accordion" href="#PricingHotel"><i class="fa fa-inr" aria-hidden="true"></i> Pricing</a>
</h4>
</div>
<div id="PricingHotel" class="panel-collapse collapse">
<div class="panel-body">
<div class="row">
<div class="col-md-12">
<div class="form-group">
<label for="">Is On Request?</label>
<input type="checkbox" value="1" name="onrequest" id="onrequest" checked/>
</div>
<div class="form-group pricelistpackage" style="display:none;">

<div class="table-responsive">
<table class="table table-bordered" id="dynamic_field">
<tr>
<th>Price title</th>
<th>Price from</th>
<th>Price to</th>
<th>Price type</th>
<th>Price</th>
</tr>
<tr>
<td>
<input name="Price[0][desc]" placeholder="Title.." class="form-control" type="text">

</td>
<td>
<div class="input-group date">
<div class="input-group-addon">
<i class="fa fa-calendar"></i>
</div>
<input name="Price[0][datefrom]" class="form-control pull-right datepicker"  type="text">
</div>

</td>
<td>
<div class="input-group date">
<div class="input-group-addon">
<i class="fa fa-calendar"></i>
</div>
<input  name="Price[0][dateto]" class="form-control pull-right datepicker" type="text">
</div>
</td>
<td>
<select name="Price[0][for]" class="form-control">
<option value="0">Select Type </option>
<option value="1">Per Person </option>
<option value="2">Per Night </option>
<option value="2">Per Price </option>
</select>
</td>
<td>
<div class="input-group" style="margin-bottom:5px;">
<span class="input-group-addon">INR
</span>
<input name="Price[0][cost]" class="form-control" placeholder="Price">
</div>
</td>
<td>
<button type="button" name="add" id="add-price-row" class="btn btn-success">Add More
</button>
</td>
</tr>
</table>
</div>

</div>
</div>
</div>

</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h4 class="panel-title">
<a data-toggle="collapse" data-parent="#accordion" href="#AdditionalHotel"><span class="glyphicon glyphicon-th-list">
</span> Additional Information</a>
</h4>
</div>
<div id="AdditionalHotel" class="panel-collapse collapse">
<div class="panel-body">
<div class="row">
<div class="col-md-12">
<h4>Terms & Conditions
</h4>

<div class="form-group">
<label for="">Is Visa Required?</label>
<input type="checkbox" name="visa" value="1" id="onrequestvisa" checked/>
</div>
<h5>Visa Terms & Policies
</h5>
<table class="table table-bordered" id="dynamic_field">
<tbody>
<tr>
<td style="width: 60%;">
<div>
@foreach($visaPolicy as $pol)
<div class="checkbox">
<label>
<input class="visaMethods" value="{{$pol->policy}}" lang="{{$pol->id}}" type="checkbox">{{$pol->policy}}
</label>
</div>
@endforeach

</div>
</td>

<td>
<textarea  id="visa_policies" placeholder="Please state your Payment Terms and Methods..." rows="3" class="form-control">
</textarea>
<input type="hidden" name="visa_policies" id="visa_policies_input" value=""/>
</td>
</tr>
</tbody>
</table>

<h5>Payment Terms & Methods
</h5>
<table class="table table-bordered" id="dynamic_field">
<tbody>
<tr>
<td style="width: 60%;">
<div>
@foreach($paymentPolicy as $pol)
<div class="checkbox">
<label>
<input class="paymentMethods" value="{{$pol->policy}}" lang="{{$pol->id}}" type="checkbox">{{$pol->policy}}
</label>
</div>
@endforeach

</div>
</td>

<td>
<textarea  id="payment_policies" placeholder="Please state your Payment Terms and Methods..." rows="3" class="form-control">
</textarea>
<input type="hidden" name="payment_policies" id="payment_policies_input" value=""/>
</td>
</tr>
</tbody>
</table>
<h5>Cancellation & Refund Policy
</h5>
<table class="table table-bordered" id="dynamic_field">
<tbody>
<tr>
<td style="width: 60%;">
<div>
@foreach($cancelPolicy as $can)
<div class="checkbox">
<label>
<input class="cancellation" id="cancellation_input" value="{{$can->policy}}" lang="{{$can->id}}"  type="checkbox">{{$can->policy}}
</label>
</div>
@endforeach

</div>
</td>
<td>
<textarea  id="cancle_policy" placeholder="Please state your Payment Terms and Methods..." rows="3" class="form-control">
</textarea>

<input type="hidden" name="cancellation" id="cancellation_input_field" value=""/>
</td>
</tr>
</tbody>
</table>

</div>
</div>

</div>
</div>
</div>

</div>
<!-- end-->


<div style="text-align: center;">

<button type="submit" name="add" id="remove" class="btn btn-danger btn-lg">Save 
<i class="fa  fa-arrow-right">
</i>
</button>
</div>
</form>
<!-- TAB-1 INNAR HTML END -->
<!-- TAB-2 INNAR HTML END -->
</div>
<!-- TAB-3 INNAR HTML END -->
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
<!-- /.content -->
</div>

<!---->
<div class="modal fade" id="packagetour_custom" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
<h3 class="modal-title" id="lineModalLabel">Add Package Tour</h3>
</div>
<div class="modal-body">
<!-- content goes here -->
<form>
<input type="hidden" name="type" value="Private Tour"/>

<br>
<div class="alert alert-success"
id="success-add" style="display:none">
<p>Tour Added Successfully.</p>
</div>
<div class="alert alert-danger" id="error-contaier-parent" style="display:none">
<ul id="error-contaier"> 
</ul>
</div>
<div class="row form-group">
<label class="col-md-3 control-label text-left">Tour Name</label>
<div class="col-md-8">
<input name="name" class="form-control name" placeholder="Name" value="" type="text" id="tour_name">
</div>
</div>
<div class="row form-group">
<label class="col-md-3 control-label text-left">Tour Description</label>
<div class="col-md-8">
<input name="description" class="form-control description" placeholder="description.." value="" type="text" 
id="tour_description">
</div>
</div>
<div class="row form-group">
<label class="col-md-3 control-label text-left">Tour Locations</label>
<div class="col-md-8">
<input name="location" class="form-control location" placeholder="location" value="" type="text" 
id="tour_location">
</div>
</div>

<div class="row form-group">
<label class="col-md-3 control-label text-left">Status</label>
<div class="col-md-8">
<select name="status" class="form-control status" id="tour_status">
<option value="1">Enable</option>
<option value="0">Disable</option>
</select>
</div>
</div>

</div>
<div class="modal-footer">
<div class="btn-group tn-group-justified" role="group" aria-label="group button">
<div class="btn-group" role="group">
<button type="button" class="btn btn-default" data-dismiss="modal"  role="button">Close</button>
</div>
<div class="btn-group" role="group">
<input type="submit"  class="btn btn-primary" 
value="Add" id="add-tour" >
</div>
</div>
</div>
</form>
</div>
</div>
</div>
<!---->

<div class="modal fade" id="pk_aadhotel" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
<h3 class="modal-title" id="lineModalLabel">Add Package Hotel</h3>
</div>
<div class="modal-body">
<!-- content goes here -->
<form>
<input type="hidden" name="type" value="Private Tour"/>

<br>
<div class="alert alert-success"
id="success-add_pkhotel" style="display:none">
<p>Package Hotel Added Successfully.</p>
</div>
<div class="alert alert-danger" id="error-add_pkhotel" style="display:none">
<ul id="error-contaier">
<p>Enter Valid Input</p> 
</ul>
</div>
<div class="row form-group">
<label class="col-md-3 control-label text-left">Hotel Name</label>
<div class="col-md-8">
<input name="hotelname" class="form-control" placeholder="Hotel Name"  type="text" id="hotelname">
</div>
</div>

<div class="row form-group">
<label class="col-md-3 control-label text-left">Locations</label>
<div class="col-md-8">
<input name="location" class="form-control" placeholder="Location" value="" type="text" 
id="location">
</div>
</div>


<div class="row form-group">
<label class="col-md-3 control-label text-left">Star Rating</label>
<div class="col-md-8">
<select name="star_rating" class="form-control" id="star_rating">
<option value="5">5 Star</option>
<option value="4.5">4.5 Star</option>
<option value="4">4 Star</option>
<option value="3.5">3.5 Star</option>
<option value="3">3 Star</option>
<option value="2">2 Star</option>
<option value="1">1 Star</option>
</select>
</div>
</div>


</div>
<div class="modal-footer">
<div class="btn-group tn-group-justified" role="group" aria-label="group button">
<div class="btn-group" role="group">
<button type="button" class="btn btn-default" data-dismiss="modal"  role="button">Close</button>
</div>
<div class="btn-group" role="group">
<input type="submit"  class="btn btn-primary" value="Add" id="add_package_hotel" >

</div>
</div>
</div>
</form>
</div>
</div>
</div>

@endsection

@section("custom_js_code")
<script>
  //customize_onrequestvisa
 $(document).on("click","#customize_onrequestvisa",function(){
    if($(this).is(":checked"))
    {
    $(this).parent().siblings(".costomize_tour_visa").show()
    }
    else
    {
   $(this).parent().siblings(".costomize_tour_visa").hide()
    }
})
</script>
@endsection