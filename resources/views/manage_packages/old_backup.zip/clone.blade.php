 @extends('layouts.master')
@section('content')
<style>
  
 .dayItinerary{
        border-bottom: 1px solid darkgray;
    margin-bottom: 14px;
    border-radius: 23px;
  }
  span.select2.select2-container {
    width: 100% !important;
}
</style>
<div class="content-wrapper">
       
        <section class="content">
          <div class="row">
            <div class="col-md-12">
              
              <div class="panel panel-default">
                <div class="panel-body">
                  <div class="modal-body_main">

                  
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bs-example-modal-lg">Add in Bulk</button>
                <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
                  <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                    
                      <div class="modal-body">
                      <h4>Choose a file to upload</h4>
                      <h3>Instructions</h3>
                      <div class="control-group" style="width: 24%;margin: 0 auto;">
                        <div class="controls">
                          <input id="filebutton" name="filebutton" class="input-file" type="file">
                        </div>
                      </div>
                      <br>
                      <div class="control-group">
                        <div class="controls">
                          <button id="singlebutton" name="singlebutton" class="btn btn-info">Upload</button>
                        </div>
                      </div>
                       <br>

                      <ol>
                        <li>To see format & possible values while uploading your deals, please <b><a href="#"> download format sheet</a></b> </li>
                        <li>Fill the details of your deals in excel sheet & save the excel sheet.</li>
                        <li>Click on <b>Browse</b> button & select the excel file.</li>
                        <li>Click on <b>Submit</b> to post your deals.</li>
                      </ol>
                      </div>
                    </div>
                  </div>
              </div>
              </div>
              <br><br>
                  <div id="content">
                    <ul id="tabs" class="nav nav-tabs" data-tabs="tabs">
                      <li class="active">
                        <a href="#red" data-toggle="tab">Private Tour
                        </a>
                      </li>
                     <!--  <li>
                       <a href="#orange" data-toggle="tab">Hotel Package
                       </a>
                     </li>
                     <li>
                       <a href="#yellow" data-toggle="tab">Group Tour / Shared Tour
                       </a>
                     </li> -->
                    </ul>
                    <div id="my-tab-content" class="tab-content">
                      <div class="tab-pane active" id="red">
                      @if($packagesData->type_of_package != 'Hotel Package')
                      <input type="hidden" id="package_country" value="{{implode(',',$packagesData->country)}}">
                      <input type="hidden" id="package_country_city" value="{{implode(',',$packagesData->package_location)}}">
                      @endif  
                        @if ($errors->any())
                              <div class="alert alert-warning">
                                  <ul>
                                      @foreach ($errors->all() as $error)
                                          <li>{{ $error }}</li>
                                      @endforeach
                                  </ul>
                              </div>
                          @endif
                        <!--New Edit Template-->
                        <div class="col-md-12">
                      <form action="{{URL::to('/store-package')}}" method="post" >
                      <input type="hidden" name="type" value="{{$packagesData->type_of_package}}"/>
                      
                      {{csrf_field()}}
                        <br>
                      <div class="panel-group" id="accordion">
                          <div class="panel panel-default">
                              <div class="panel-heading">
                                  <h4 class="panel-title">
                                      <a data-toggle="collapse" data-parent="#accordion" href="#Info"><span class="glyphicon glyphicon-file">
                                      </span> Package Info</a>
                                  </h4>
                              </div>
                              <div id="Info" class="panel-collapse collapse in">
                                  <div class="panel-body">
                                      <div class="row">
                                          <div class="col-md-12">
                                          <div class="col-md-4 form-group">
                                        <select name="category" id="category" class="form-control">
                                            <option value="domestic"  @if($packagesData->category == 'domestic') selected="selected" @endif>Domestic
                                            </option>
                                            <option value="international"  @if($packagesData->category == 'international') selected="selected" @endif>International
                                            </option>
                                        
                                        </select>
                                        </div>

                                        @if($packagesData->type_of_package == 'Hotel Package')
                                        <div class="col-md-8 form-group">
                                          <div class="input-group" style="margin-bottom:5px;">
                                            <span class="input-group-addon">
                                              <i class="fa fa-map-marker">
                                              </i>
                                            </span>
                                            <select name="package_hotel" id="package_dest_hotel" class="form-control select2">
                                                <option value="0">*Select Hotel</option>
                                                @foreach($hotel as $hot)
                                              <option value='{{$hot->id}}' @if($packagesData->package_hotel == $hot->id) selected="selected" @endif >{{$hot->name}}
                                              </option>
                                              @endforeach 
                                            </select>
                                        
                                          </div>
                                    
                                        </div>
                                        @else
                                        <div class="col-md-4 form-group">
                                          <label for="country">Country</label>
                                          <select name="country[]" id="package_dest_country" class="form-control select2" multiple>
                                            <option value="0">*Select Destination Country</option>
                                            @foreach($country as $count)
                                            <option value="{{$count->city_state}}" @if(in_array($count->city_state,$packagesData->country)) selected="selected" @endif>{{$count->city_state}}
                                            </option>
                                            @endforeach
                                          </select>
                                       </div>
                                      
                                        <div class="col-md-4 form-group">
                                        <label for="package_location">Location</label>
                                          <div class="input-group" style="margin-bottom:5px;">
                                            <span class="input-group-addon">
                                              <i class="fa fa-map-marker">
                                              </i>
                                            </span>
                                            <select name="package_location[]" id="package_location_city" class="form-control select2" multiple>
                                                <option value="0">*Select Location</option>
                                              
                                            </select>
                                        
                                          </div>
                                        
                                        </div>


                                        @endif

                                        
                                        
                                          </div>
                                      </div>
                                      <div class="row">
                                      <div class="col-md-12">
                                      <div class="col-md-4 form-group">
                                          <input type="text" placeholder="Title" value="{{$packagesData->title}}" name="package_name" class="form-control">
                                        </div>
                                        <div class="col-md-4 form-group">
                                          <select name="package_category[]" placeholder="Theme" id="package_category" class="select2 form-control" multiple>
                                          
                                           @foreach($types as $typ)
                                           <option value="{{$typ->name}}" @if(in_array($typ->name,$packagesData->package_category) ) selected="selected" @endif >{{$typ->name}}
                                            </option>
                                           @endforeach
                                           
                                           
                                           
                                          </select>
                                        </div>
                                      
                                   
                                    <div class="col-md-4 form-group">
                                      <select name="duration" id="package_durations" class="form-control">
                                        <option value="1" @if($packagesData->duration == '1') selected="selected" @endif>1 Night/2 Days
                                        </option>
                                        <option value="2" @if($packagesData->duration == '2') selected="selected" @endif>2 Night/3 Days
                                        </option>
                                        <option value="3" @if($packagesData->duration == '3') selected="selected" @endif>3 Night/4 Days
                                        </option>
                                        <option value="4" @if($packagesData->duration == '4') selected="selected" @endif>4 Night/5 Days
                                        </option>
                                        <option value="5" @if($packagesData->duration == '5') selected="selected" @endif>5 Night/6 Days
                                        </option>
                                      </select>
                                    </div>

                                    </div>
                                      </div>
                                    
                                  </div>
                              </div>
                          </div>
                          <div class="panel panel-default">
                              <div class="panel-heading">
                                  <h4 class="panel-title">
                                      <a data-toggle="collapse" data-parent="#accordion" href="#Overview"><span class="glyphicon glyphicon-th-list">
                                      </span> Package Overview</a>
                                  </h4>
                              </div>
                              <div id="Overview" class="panel-collapse collapse">
                                  <div class="panel-body">
                                      <div class="row">
                                          <div class="col-md-12">
                                          <div class="col-md-6">
                                          <div class="form-group">
                                          <textarea class="form-control" placeholder="Package Description..." name="description" id="" cols="30" rows="5">{{$packagesData->description}}</textarea>
                                          </div>
                                            <div class="form-group">
                                          <label for="">Package Rating</label>
                                          <select name="package_rating" id="rating" class="form-control">
                                          @foreach($ratingType as $rtyp)
                                          <option value='{{$rtyp->id}}' @if($packagesData->package_rating == $rtyp->id) selected="selected" @endif>{{$rtyp->name}}
                                          </option>
                                          @endforeach 
                                          
                                          </select>
                                        </div>
                                          </div>
                                      <div class="col-md-6">
                                        <div class="form-group">
                                        <label for="">Transport</label>
                                        <select name="transport" id="transport" class="form-control">
                                            <option value="Flights" @if($packagesData->transport == 'Flights') selected="selected" @endif>Flights
                                            </option>
                                            <option value="Trains" @if($packagesData->transport == 'Trains') selected="selected" @endif>Trains
                                            </option>
                                        
                                        </select>
                                      </div>
                                      
              
                                        <div class="form-group select-container">
                                        <label for="">Accommodation</label>
                                        <select name="accommodation[]" id="accommodation" class="select2 form-control" multiple>
                                        @foreach($hotel as $hot)
                                        <option value='{{$hot->id}}' @if(in_array($hot->id,$packagesData->accommodation)) selected="selected" @endif>{{$hot->name}}
                                        </option>
                                        @endforeach 
                                        
                                        </select>
                                      </div>
                                      <div class="form-group select-container">
                                          <label >Tours</label>
                                        <select class='select2 form-control' name="tours[]" multiple>
                                          @foreach($PkgTours as $key=>$tour)
                                          <option value='{{$tour->id}}'  @if(in_array($tour->id,$packagesData->tours)) selected="selected" @endif>{{$tour->activity}}
                                          </option>
                                        @endforeach 
                                          
                                        </select>
                                      </div>
                                      </div>
                                          </div>
                                      </div>
                                      <div class="row">
                                          <div class="col-md-12">
                                          <div class="col-md-6">
                                          <div class="form-group select-container">
                                              <label >Inclusions</label>
                                            <select class='select2 form-control' name="inclusions[]" multiple>
                                              @foreach($inclusions as $key=>$inc)
                                              <option value='{{$inc->name}}'  @if(in_array($inc->name,$packagesData->inclusions)) selected="selected" @endif>{{$inc->name}}
                                              </option>
                                              @endforeach 
                                              
                                            </select>
                                          </div>
                                          </div>
                                          <div class="col-md-6">
                                          <div class=" form-group ">
                                              <label >Exclusions</label>
                                            <select class='select2 form-control' name="exclusions[]" multiple>
                                              @foreach($exclusions as $key=>$exc)
                                              <option value='{{$exc->name}}'  @if(in_array($exc->name,$packagesData->exclusions)) selected="selected" @endif>{{$exc->name}}
                                              </option>
                                              @endforeach 
                                              
                                            </select>
                                          </div>
                                          </div>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          @if($packagesData->type_of_package != 'Hotel Package')
                          <div class="panel panel-default">
                              <div class="panel-heading">
                                  <h4 class="panel-title">
                                      <a data-toggle="collapse" data-parent="#accordion" href="#Itinerary"><i class="fa fa-calendar-check-o" aria-hidden="true"></i> Day Wise Itinerary</a>
                                  </h4>
                              </div>
                              <div id="Itinerary" class="panel-collapse collapse">
                                  <div class="panel-body">
                                      <div class="row">
                                          <div class="col-md-12">
                                            <div class="table-responsive">
                                           
                                            @foreach($packagesData->day_itinerary as $key=>$day)
                                           
                                              @if(count($day)>4)
                                                  <div class="col-md-12 dayItinerary {{$key}}" >
                                                    
                                                    <div class="row"><label class="col-md-2">Day {{$key}} :
                                                    </label></div>
                                                    <input type="hidden" name="dayItinerary[{{$key}}][title]" value=" {{$key}}">
                                                      <div class="col-md-4">
                                                        <div class="form-group">
                                                          <label for="">City</label>
                                                            <select class='select2 form-control' name="dayItinerary[{{$key}}][city]" multiple>
                                                            @foreach($hotelcity as $hoteldata)
                                                            <option value="{{$hoteldata->city}}" @if($hoteldata->city == $day['city']) selected="selected" @endif>{{$hoteldata->city}}
                                                            </option>
                                                            @endforeach 
                                                
                                                            </select>
                                                          </div>
                                                            <div class="form-group">
                                                              <label for="">Description</label>
                                                            <textarea class="form-control" rows="3" name="dayItinerary[{{$key}}][desc]" placeholder="Description ...">{{$day['desc']}}
                                                            </textarea>
                                                          </div>
                                                
                                                      </div>                                 
                                                      <div class="col-md-4">
                                                          <div class="form-group">
                                                          <label for="">Hotel Name</label>
                                                            <select class='select2 form-control' name="dayItinerary[{{$key}}][hotelname]" multiple>
                                                            @foreach($hotel as $hotelrow)
                                                            <option value='{{$hotelrow->id}}' @if($hotelrow->id == $day['hotelname']) selected="selected" @endif>{{$hotelrow->name}}
                                                            </option>
                                                            @endforeach 
                                                
                                                            </select>
                                                          </div>
                                                          <div class="form-group">
                                                            <label >Meal Plan</label>
                                                            <select name="dayItinerary[{{$key}}][meal_plan]" class="form-control">
                                                              <option value="EP" @if('EP' == $day['meal_plan']) selected="selected" @endif>EP (No meal)
                                                              </option>
                                                              <option value="CP" @if('CP' == $day['meal_plan']) selected="selected" @endif> (Room + Breakfast)
                                                              </option>
                                                              <option value="MAP" @if('MAP' == $day['meal_plan']) selected="selected" @endif> (Room + Breakfast + Lunch/Dinner)
                                                              </option>
                                                            </select>
                                                          </div>
                                                            <div class=" form-group ">
                                                                <label >Included Tours</label>
                                                              <select class='select2 form-control' name="dayItinerary[{{$key}}][tours][]" multiple>
                                                                @foreach($PkgTours as $tour)
                                                                <option value='{{$tour->id}}' @if(in_array($tour->id, $day['tours'])) selected="selected" @endif>{{$tour->activity}}
                                                                </option>
                                                                @endforeach 
                                                                
                                                              </select>
                                                            </div>
                                                
                                                      </div>                                 
                                                      <div class="col-md-4">
                                                
                                                            <div class="form-group">
                                                            <label for="">Hotel Star Rating</label>
                                                              <select name="dayItinerary[{{$key}}][star]" class="form-control">
                                                                <option value="1" @if('1' == $day['star']) selected="selected" @endif>1 Star
                                                                </option>
                                                                <option value="2" @if('2' == $day['star']) selected="selected" @endif>2 Star
                                                                </option>
                                                                <option value="3" @if('3' == $day['star']) selected="selected" @endif>3 Star
                                                                </option>
                                                                <option value="4" @if('4' == $day['star']) selected="selected" @endif>4 Star
                                                                </option>
                                                                <option value="5" @if('5' == $day['star']) selected="selected" @endif>5 Star
                                                                </option>
                                                              </select>
                                                            </div>
                                                            
                                                
                                                      </div>   
                                                                                
                                                </div> 
                                                @elseif(count($day)<=4)
                                                    <div class="col-md-12 dayItinerary {{$key}}" style="display: none;" >
                                                    
                                                      <div class="row"><label class="col-md-2">Day 1 :
                                                      </label></div>
                                                      <input type="hidden" name="dayItinerary[{{$key}}][title]" value="{{$key}} ">
                                                        <div class="col-md-4">
                                                          <div class="form-group">
                                                          <label for="">City</label>
                                                              <select class='select2 form-control' name="dayItinerary[{{$key}}][city]" multiple>
                                                              @foreach($hotelcity as $hotel1)
                                                              <option value='{{$hotel1}}'>{{$hotel1}}
                                                              </option>
                                                              @endforeach 

                                                              </select>
                                                            </div>
                                                            <div class="form-group">
                                                              <label for="">Description</label>
                                                              <textarea class="form-control" rows="3" name="dayItinerary[{{$key}}][desc]" placeholder="Description ...">
                                                              </textarea>
                                                            </div>

                                                        </div>                                 
                                                        <div class="col-md-4">
                                                          <div class="form-group">
                                                          <label for="">Hotel Name</label>
                                                              <select class='select2 form-control' name="dayItinerary[{{$key}}][hotelname]" multiple>
                                                              @foreach($hotel as $hotel1)
                                                              <option value='{{$hotel1}}'>{{$hotel1}}
                                                              </option>
                                                              @endforeach 

                                                              </select>
                                                            </div>
                                                            <div class="form-group">
                                                            <label >Meal Plan</label>
                                                              <select name="dayItinerary[{{$key}}][meal_plan]" class="form-control">
                                                                <option value="EP">EP (No meal)
                                                                </option>
                                                                <option value="CP"> (Room + Breakfast)
                                                                </option>
                                                                <option value="MAP"> (Room + Breakfast + Lunch/Dinner)
                                                                </option>
                                                              </select>
                                                            </div>
                                                            <div class=" form-group ">
                                                                <label >Included Tours</label>
                                                                <select class='select2 form-control' name="dayItinerary[{{$key}}][tours][]" multiple>
                                                                @foreach($PkgTours as $tour)
                                                                  <option value='{{$tour->id}}'>{{$tour->activity}}
                                                                  </option>
                                                                @endforeach 
                                                                
                                                                </select>
                                                              </div>

                                                        </div>                                 
                                                        <div class="col-md-4">

                                                            <div class="form-group">
                                                              <label for="">Hotel Star Rating</label>
                                                                <select name="dayItinerary[{{$key}}][star]" class="form-control">
                                                                  <option value="1">1 Star
                                                                  </option>
                                                                  <option value="2">2 Star
                                                                  </option>
                                                                  <option value="3">3 Star
                                                                  </option>
                                                                  <option value="4">4 Star
                                                                  </option>
                                                                  <option value="5">5 Star
                                                                  </option>
                                                                </select>
                                                              </div>
                                                              <div class="form-group select-container">
                                                                  <label >Inclusions</label>
                                                                <select class='select2 form-control' name="dayItinerary[{{$key}}][inclusion][]" multiple>
                                                                @foreach($inclusions as $inc)
                                                                  <option value='{{$inc->name}}'>{{$inc->name}}
                                                                  </option>
                                                                @endforeach 
                                                                
                                                                </select>
                                                              </div>
                                                              <div class=" form-group ">
                                                                <label >Exclusions</label>
                                                                <select class='select2 form-control' name="dayItinerary[{{$key}}][exclusion][]" multiple>
                                                                @foreach($exclusions as $exc)
                                                                  <option value='{{$exc->name}}'>{{$exc->name}}
                                                                  </option>
                                                                @endforeach 
                                                                
                                                                </select>
                                                              </div>

                                                        </div>   
                                                                                  
                                                  </div>

                                                @endif
                                                  @endforeach
                          
                                  
                                  
                                
                                
                                  
                                
                                
                                
                                            </div>
                                          </div>
                                      </div>
                                     
                                  </div>
                              </div>
                          </div>
                          @endif
                          <div class="panel panel-default">
                              <div class="panel-heading">
                                  <h4 class="panel-title">
                                      <a data-toggle="collapse" data-parent="#accordion" href="#META"><i class="fa fa-database" aria-hidden="true"></i> SEO Data</a>
                                  </h4>
                              </div>
                              <div id="META" class="panel-collapse collapse">
                                  <div class="panel-body">
                                      <div class="row">
                                          <div class="col-md-12">
                                              <div class="form-group">
                                                  <input type="text" class="form-control" value="{{$packagesData->meta_title}}" name="meta_title" placeholder="Title" required />
                                              </div>
                                              <div class="form-group">
                                                  <input type="text" class="form-control" value="{{$packagesData->meta_desc}}" name="meta_desc" placeholder="Description" required />
                                              </div>
                                              <div class="form-group">
                                                  <textarea class="form-control"  name="meta_keyword" placeholder="Keywords" required>{{$packagesData->meta_keyword}}</textarea>
                                              </div>
                                          </div>
                                      </div>
                                      
                                  </div>
                              </div>
                          </div>
                          <div class="panel panel-default">
                              <div class="panel-heading">
                                  <h4 class="panel-title">
                                      <a data-toggle="collapse" data-parent="#accordion" href="#Supplier"><i class="fa fa-suitcase" aria-hidden="true"></i> Supplier Information</a>
                                  </h4>
                              </div>
                              <div id="Supplier" class="panel-collapse collapse">
                                  <div class="panel-body">
                                  
                                      <div class="row">
                                          <div class="col-md-12">
                                              <div class="form-group">
                                                  <input type="text" class="form-control" value="{{$packageSupplier->supplier_name}}" name="supplier_name" placeholder="Name" required />
                                              </div>
                                              <div class="form-group">
                                                  <input type="text" class="form-control" value="{{$packageSupplier->contact_no}}" name="supplier_contact_no" placeholder="Contact No" required />
                                              </div>
                                              <div class="form-group">
                                                  <input type="text" class="form-control" value="{{$packageSupplier->email_id}}" name="supplier_emailId" placeholder="Email Id" required />
                                              </div>
                                              <div class="form-group">
                                                  <input type="text" class="form-control" value="{{$packageSupplier->supplier_price}}"  name="supplier_price" placeholder="Price" required />
                                              </div>
                                              
                                              <div class="form-group">
                                                  <textarea class="form-control" name="supplier_address" placeholder="Address" required> {{$packageSupplier->address}}</textarea>
                                              </div>
                                          </div>
                                      </div>
                                      
                                  </div>
                              </div>
                          </div>
                          <div class="panel panel-default">
                              <div class="panel-heading">
                                  <h4 class="panel-title">
                                      <a data-toggle="collapse" data-parent="#accordion" href="#Pricing"><i class="fa fa-inr" aria-hidden="true"></i> Pricing</a>
                                  </h4>
                              </div>
                              <div id="Pricing" class="panel-collapse collapse">
                                  <div class="panel-body">
                                      <div class="row">
                                          <div class="col-md-12">
                                          <div class="form-group">
                                          <label for="">Is On Request?</label>
                                          <input type="checkbox" @if($packagesData->onrequest == 1) checked  @endif value="1" name="onrequest" id="onrequest" />
                                          </div>
                                          <div class="form-group pricelistpackage"  @if($packagesData->onrequest == 1) style="display:none;"  @endif >
                                           
                                              <div class="table-responsive">
                                              <table class="table table-bordered packagePricing" id="dynamic_field">
                                              <tr>
                                                  <th>Price title</th>
                                                  <th>Price from</th>
                                                  <th>Price to</th>
                                                  <th>Price type</th>
                                                  <th>Price</th>
                                              </tr>
                                            
                                              @if($packagesData->pricing && $packagesData->onrequest == 1)
                                              @foreach($packagesData->pricing as $keyd => $price)
                                              <tr id="row{{$keyd}}">
                                                <td>
                                                <input name="Price[{{$keyd}}][desc]" placeholder="Title.." value="{{$price['desc']}}" class="form-control" type="text">
                                                 
                                                </td>
                                                <td>
                                                <div class="input-group date">
                                                  <div class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                  </div>
                                                  <input name="Price[{{$keyd}}][datefrom]" value="{{$price['datefrom']}}" class="form-control pull-right datepicker"  type="text">
                                                </div>
                                                  
                                                </td>
                                                <td>
                                                <div class="input-group date">
                                                  <div class="input-group-addon">
                                                    <i class="fa fa-calendar"></i>
                                                  </div>
                                                  <input  name="Price[{{$keyd}}][dateto]" value="{{$price['dateto']}}" class="form-control pull-right datepicker" type="text">
                                                </div>
                                                 </td>
                                                <td>
                                                <select name="Price[{{$keyd}}][for]" class="form-control">
                                                    <option value="0"  @if($price['for'] == 0) selected="selected"  @endif  >Select Type </option>
                                                    <option value="1" @if($price['for'] == 1) selected="selected"  @endif >Per Person </option>
                                                    <option value="2" @if($price['for'] == 2) selected="selected"  @endif >Per Night </option>
                                                    <option value="3"  @if($price['for'] == 3) selected="selected"  @endif >Per Price </option>
                                                  </select>
                                                </td>
                                                <td>
                                                <div class="input-group" style="margin-bottom:5px;">
                                                    <span class="input-group-addon">INR
                                                    </span>
                                                    <input name="Price[{{$keyd}}][cost]" value="{{$price['cost']}}" class="form-control" placeholder="Price">
                                                  </div>
                                                </td>
                                                <td>
                                                  
                                                  @if($keyd == 0)
                                                  <button type="button" name="add" id="add-price-row" class="btn btn-success">Add More
                                                  </button>
                                                  @else
                                                  <button type="button" name="remove" id="{{$keyd}}" class="btn btn-danger btn_remove">X</button>
                                                  @endif
                                                </td>
                                              </tr>
                                              @endforeach
                                              @else
                                              <tr>
                                                    <td>
                                                    <input name="Price[0][desc]" placeholder="Title.." class="form-control" type="text">
                                                     
                                                    </td>
                                                    <td>
                                                    <div class="input-group date">
                                                      <div class="input-group-addon">
                                                        <i class="fa fa-calendar"></i>
                                                      </div>
                                                      <input name="Price[0][datefrom]" class="form-control pull-right datepicker"  type="text">
                                                    </div>
                                                      
                                                    </td>
                                                    <td>
                                                    <div class="input-group date">
                                                      <div class="input-group-addon">
                                                        <i class="fa fa-calendar"></i>
                                                      </div>
                                                      <input  name="Price[0][dateto]" class="form-control pull-right datepicker" type="text">
                                                    </div>
                                                     </td>
                                                    <td>
                                                    <select name="Price[0][for]" class="form-control">
                                                        <option value="0">Select Type </option>
                                                        <option value="1">Per Person </option>
                                                        <option value="2">Per Night </option>
                                                        <option value="2">Per Price </option>
                                                      </select>
                                                    </td>
                                                    <td>
                                                    <div class="input-group" style="margin-bottom:5px;">
                                                        <span class="input-group-addon">INR
                                                        </span>
                                                        <input name="Price[0][cost]" class="form-control" placeholder="Price">
                                                      </div>
                                                    </td>
                                                    <td>
                                                      <button type="button" name="add" id="add-price-row" class="btn btn-success">Add More
                                                      </button>
                                                    </td>
                                                  </tr>
                                                  @endif
                                            </table>
                                              </div>
                                           
                                          </div>
                                          </div>
                                      </div>
                                      
                                  </div>
                              </div>
                          </div>
                          <div class="panel panel-default">
                              <div class="panel-heading">
                                  <h4 class="panel-title">
                                      <a data-toggle="collapse" data-parent="#accordion" href="#Additional"><span class="glyphicon glyphicon-th-list">
                                      </span> Additional Information</a>
                                  </h4>
                              </div>
                              <div id="Additional" class="panel-collapse collapse">
                                  <div class="panel-body">
                                      <div class="row">
                                          <div class="col-md-12">
                                          <h4>Terms & Conditions
                                          </h4>

                                          <div class="form-group">
                                          <label for="">Is Visa Required?</label>
                                          <input type="checkbox" @if($packagesData->visa == 1) checked  @endif name="visa" value="1" id="onrequestvisa" />
                                          </div>
                                          <h5>Visa Terms & Policies
                                          </h5>
                                          <table class="table table-bordered" id="dynamic_field">
                                            <tbody>
                                              <tr>
                                                <td style="width: 60%;">
                                                  <div>
                                                    @foreach($visaPolicy as $pol)
                                                    <div class="checkbox">
                                                      <label>
                                                        <input class="visaMethods" value="{{$pol->policy}}" lang="{{$pol->id}}" type="checkbox" @if(in_array($pol->id,$packagesData->visa_policy)) checked="checked" @endif>{{$pol->policy}}
                                                      </label>
                                                    </div>
                                                    @endforeach
                                                    
                                                  </div>
                                                </td>
                                               
                                                <td>
                                                  <textarea  id="visa_policies" placeholder="Please state your Payment Terms and Methods..." rows="3" class="form-control">
                                                  </textarea>
                                                  <input type="hidden" name="visa_policies" id="visa_policies_input" value=""/>
                                                </td>
                                              </tr>
                                            </tbody>
                                          </table>
                                          <h5>Payment Terms & Methods
                                          </h5>
                                          <table class="table table-bordered" id="dynamic_field">
                                            <tbody>
                                              <tr>
                                                <td style="width: 60%;">
                                                  <div>
                                                    @foreach($paymentPolicy as $pol)
                                                    <div class="checkbox">
                                                      <label>
                                                        <input class="paymentMethods" value="{{$pol->policy}}" lang="{{$pol->id}}" type="checkbox" @if(in_array($pol->id,$packagesData->payment_policy)) checked="checked" @endif>{{$pol->policy}}
                                                      </label>
                                                    </div>
                                                    @endforeach
                                                    
                                                  </div>
                                                </td>
                                               
                                                <td>
                                                  <textarea  id="payment_policies" placeholder="Please state your Payment Terms and Methods..." rows="3" class="form-control">
                                                  </textarea>
                                                  <input type="hidden" name="payment_policies" id="payment_policies_input" value=""/>
                                                </td>
                                              </tr>
                                            </tbody>
                                          </table>
                                          <h5>Cancellation & Refund Policy
                                          </h5>
                                          <table class="table table-bordered" id="dynamic_field">
                                            <tbody>
                                              <tr>
                                                <td style="width: 60%;">
                                                  <div>
                                                     @foreach($cancelPolicy as $can)
                                                    <div class="checkbox">
                                                      <label>
                                                        <input class="cancellation" id="cancellation_input" value="{{$can->policy}}" lang="{{$can->id}}"  type="checkbox" @if(in_array($can->id,$packagesData->cancel_policy)) checked="checked" @endif>{{$can->policy}}
                                                      </label>
                                                    </div>
                                                    @endforeach
                                                   
                                                  </div>
                                                </td>
                                                <td>
                                                  <textarea  id="cancle_policy" placeholder="Please state your Payment Terms and Methods..." rows="3" class="form-control">
                                                  </textarea>
                  
                                                  <input type="hidden" name="cancellation" id="cancellation_input_field" value=""/>
                                                </td>
                                              </tr>
                                            </tbody>
                                          </table>
                                    
                                          </div>
                                      </div>
                                      
                                  </div>
                              </div>
                          </div>

                      </div>
                      <!-- end-->
                        
                    
                        <div style="text-align: center;">
                      
                          <button type="submit" name="add" id="remove" class="btn btn-danger btn-lg">Save 
                            <i class="fa  fa-arrow-right">
                            </i>
                          </button>
                        </div>
                      </form>
                        <!-- TAB-1 INNAR HTML END -->
                       
                      </div>    
                        <!-- END New Edit Template-->

                      </div>
                     
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <!-- /.content -->
      </div>
@endsection