@extends('layouts.master')
@section('content')
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<!-- Content Header (Page header) -->
<section class="content-header">
<h1> Users </h1>
{{-- <ol class="breadcrumb">
<li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
</ol> --}}
</section>
<!-- Main content -->
<section class="content" id="content">
<div class="row">
<div class="col-xs-12">
<div class="box">
 @if(Sentinel::getUser()->inRole('administrator') || Sentinel::getUser()->inRole('supervisor') || Sentinel::getUser()->inRole('super_admin') )
<div class="box-header">
<a href="{{URL::to('/user-create')}}" class="btn btn-success" ><i class="glyphicon glyphicon-plus-sign"></i> Add New User</a>  
</div>
@endif
<!-- /.box-header -->
<div class="box-body">
@if(Session::has('success'))
<div class="alert alert-warning alert-dismissible" role="alert">
<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
{{Session::get('success')}}
</div>
@endif
              
<table id="example1" class="table table-bordered table-striped example1">
<thead>
<tr>
  <th>First Name</th>
  <th>Last Name</th>
  <th>Email</th>
  <th>Role</th>
  <th>Status</th>
  <th>Login Status</th>
   <th>Last Login</th>
  <th>Actions</th>
</tr>
</thead>
<tbody>

@foreach($users as $user)          
<tr id="role_{{$user->id}}">
<td class="first_name"><span>{{$user->first_name}}</span></td>
<td class="last_name"><span>{{$user->last_name}}</span></td>
<td class="user_email"><span>{{$user->email}}</span></td>
<td class="user_role">
<span>
<label for="" class="label label-success">{{CustomHelpers::get_user_role($user->id)}}</label> 
</span>

</td>

  <td>
  	<?php
    $sevtinel_activated=Sentinel::findById($user->id);
    if ($activation = Activation::completed($sevtinel_activated))
    {
    echo "<p style='background:green;color:white;padding:2px 5px;text-align:center'>Activated</p>";
    }
   else
   {
    echo "<p style='background:#dd4b39;color:white;padding:2px 5px;text-align:center'>Not Activated</p>";
   }
  ?>
  </td> 
  <td>
  @if($user->login_status=="1")
<span style="color: green">Online</span>
  @else
<span style="color: red">Offline</span>
  @endif
</td>  
<td>
 
  <?php
$date=date_create($user->last_login);
echo date_format($date,"d M Y H:i:s");
?>
</td>              
 <td>

<form action="{{URL::to('/deleteuser')}}" method="post" onsubmit="return confirm('Are you sure?');">
{{csrf_field()}} 
<input type="hidden" name="id" value="{{$user->id}}"/>
@if((Sentinel::getUser()->inRole('supervisor') || Sentinel::getUser()->inRole('agent') || Sentinel::getUser()->inRole('employee') || Sentinel::getUser()->inRole('customer')) && (CustomHelpers::get_user_role($user->id)=='administrator' || CustomHelpers::get_user_role($user->id)=='super_admin'))

@elseif(Sentinel::getUser()->inRole('employee') && (CustomHelpers::get_user_role($user->id)=='administrator' || CustomHelpers::get_user_role($user->id)=='super_admin' || CustomHelpers::get_user_role($user->id)=='supervisor'))

@elseif(Sentinel::getUser()->inRole('agent') && (CustomHelpers::get_user_role($user->id)=='administrator' || CustomHelpers::get_user_role($user->id)=='super_admin' || CustomHelpers::get_user_role($user->id)=='supervisor' || CustomHelpers::get_user_role($user->id)=='employee'))

@else

<a href="{{URL::to('/edit-user/'.$user->id)}}" class="btn btn-info">Edit</a>

@endif
@if(Sentinel::getUser()->id==$user->id)
 |
<a href="" class="btn btn-success">Logged Admin</a>
@else
@if(Sentinel::getUser()->inRole('administrator') || Sentinel::getUser()->inRole('super_admin') )
 | <button type="submit" class="btn btn-xs btn-danger">Delete</button>
@endif
@endif

</form>
</td>
</tr>
@endforeach
</tbody>

</table>
              

</div>
<!-- /.box-body -->
</div>
<!-- /.box -->
</div>
<!-- /.col -->
</div>
<!-- /.row -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->

@endsection