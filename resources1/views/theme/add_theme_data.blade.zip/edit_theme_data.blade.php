@extends('layouts.master')
@section('content')
<style>
.error{color: red}
</style>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<section class="content">
	<div class="row">
		<div class="col-md-12">
			<div class="box">
				<div class="box-header">
					<a href="{{URL::to('/theme_data')}}" class="btn btn-success"><i class="glyphicon glyphicon-arrow-left"> </i> Back</a><br><br>
					<h3 class="box-title">Edit Theme</h3>
				</div>
				@if (Session::has('message'))
				<div class="alert alert-info">{{ Session::get('message') }}</div>
				@endif
				<div class="box-body">
					<form action="{{URL::to('/update_theme_data/'.$data_value->id)}}" method="post" enctype="multipart/form-data">
					<input type="hidden" name="type" value="Private Tour"/>
					{{csrf_field()}}
					<br>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label class="control-label" for="state">Select Theme</label>
								<select class="form-control" name="theme_name">
									@foreach($data as $typ)
									<option value="{{$typ->name}}" @if($data_value->theme_name == $typ->name) selected="selected" @endif>{{$typ->name}}  </option>
									@endforeach
								</select>
								<span class="error">{{ $errors->first("theme_name")}}</span>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="control-label" for="state">Select Image(1920*350)</label>
								<img src="{{URL::to('/').'/public/uploads/theme/'.$data_value->theme_image }}" width="100" height="50"></span>
								<input type="file" class="form-control" id="theme_image"  name="theme_image" value="{{$data_value->theme_image}}">
								<input type="hidden" name="theme_image_value" value="{{$data_value->theme_image}}">
								<span class="error">{{ $errors->first("theme_image")}}</span>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="control-label" for="state">Enter Paragraph 1</label>
								<input type="text" name="theme_para1" class="form-control" placeholder="Enter Paragraph 1" value="{{ $data_value->theme_para1 }}">
								<span class="error">{{ $errors->first("theme_para1")}}</span>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="control-label" for="state">Enter Paragraph 2</label>
								<input type="text" name="theme_para2" class="form-control" placeholder="Enter Paragraph 2" value="{{ $data_value->theme_para2 }}">
								<span class="error">{{ $errors->first("theme_para2")}}</span>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label class="control-label" for="state">About(Front End)</label>
								<textarea class="form-control ckeditor" rows="5" placeholder="Enter About Theme(Front End)" name="about_theme">{{ $data_value->about_theme }}</textarea>
								<span class="error">{{ $errors->first("about_theme")}}</span>
							</div>
						</div>
						@if(Sentinel::check())
						@if(Sentinel::getUser()->inRole('super_admin'))
						<div class="col-md-6">
							<div class="form-group">
								<label class="control-label" for="state">Title(SEO)</label>
								<input type="text" name="theme_title" class="form-control" placeholder="Enter Theme Title(SEO)" value="{{ $data_value->title }}">
								<span class="error">{{ $errors->first("theme_title")}}</span>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label class="control-label" for="state">Key(SEO)</label>
								<input type="text" name="theme_key" class="form-control" placeholder="Enter Theme Key(SEO)" value="{{ $data_value->theme_key }}">
								<span class="error">{{ $errors->first("theme_key")}}</span>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label class="control-label" for="state">Description(SEO)</label>
								<textarea class="form-control" name="theme_desc" placeholder="Enter Theme Description(SEO)" rows="4">{{ $data_value->theme_desc }}</textarea>
								<span class="error">{{ $errors->first("theme_desc")}}</span>
							</div>
						</div>
						@endif
						@endif
						<div class="col-md-12">
							<div id="add_dynamic" class="add_dynamic">
							@if($data_value->destination_theme_link!='')
							<?php
								$dynamic_details=unserialize($data_value->destination_theme_link);
								$a=0;
								$b=1;
							?>
							@foreach($dynamic_details as $rows=>$col)
								@if($b>1)
								<div id="thirdrow{{$b}}">
									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
												<label for="" class="required">Destination</label>
												<select class="select_theme_add_destination form-control" name="dynamic[{{$a}}][destination]" required>
													<option value="{{$col["destination"]}}" selected>{{$col["destination"]}}</option>
												</select>
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												<label for="" class="required">Theme</label>
												<select class="select_theme_type form-control" name="dynamic[{{$a}}][theme]" required>
													<option value="{{$col["theme"]}}" selected>{{$col["theme"]}}</option>
												</select>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label for="" class="required">Link</label>
												<input type="text" name="dynamic[{{$a}}][link]" value="{{$col["link"]}}" class="form-control" placeholder="Link">
											</div>
										</div>
										<div class="col-md-1"><label for="" class="required" style="visibility:hidden">Share</label> <button type="button" name="remove" id="{{$b}}" class="btn btn-danger btn_remove_third" style="display:block">X </button></div>
									</div>
								</div>
								@else
								<div id="thirdrow{{$b}}">
									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
												<label for="" class="required">Destination</label>
												<select class="select_theme_add_destination form-control" name="dynamic[{{$a}}][destination]" required>
													<option value="{{$col["destination"]}}" selected>{{$col["destination"]}}</option>
												</select>
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												<label for="" class="required">Theme</label>
												<select class="select_theme_type form-control" name="dynamic[{{$a}}][theme]" required>
													<option value="{{$col["theme"]}}" selected>{{$col["theme"]}}</option>
												</select>
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												<label for="" class="required">Link</label>
												<input type="text" name="dynamic[{{$a}}][link]" value="{{$col["link"]}}" class="form-control" placeholder="Link">
											</div>
										</div>
									</div>
								</div>
								@endif
							<?php
								$a++;
								$b++;
							?>
							@endforeach
							@else
							<div id="thirdrow1">
								<div class="row">
									<div class="col-md-4">
										<div class="form-group">
											<label for="" class="required">Destination</label>
											<select class="select_theme_add_destination form-control" name="dynamic[0][destination]" required></select>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label for="" class="required">Theme</label>
											<select class="select_theme_type form-control" name="dynamic[0][theme]" required></select>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label for="" class="required">Link</label>
											<input type="text" name="dynamic[0][link]" class="form-control" placeholder="Link">
										</div>
									</div>
								</div>
							</div>
							@endif
							</div>
							<button id="add_more" class="btn btn-success btn-sm" style="margin-top: 5px"><span class="fa fa-plus"></span> Add More</button>
						</div>
					</div>
					<br>
					<div class="row">
						<div class="col-sm-3"></div>
							<div class="col-sm-6">
								<button type="submit" name="add" id="remove" class="btn btn-danger btn-lg">Save<i class="fa  fa-arrow-right"></i></button>
							</div>
							<div class="col-sm-3"></div>
					</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</section>
</div>
@endsection
@section('custom_js_code_second')
<script type="text/javascript">
$(document).ready(function(){
	$('.select_theme_add_destination').select2({
		placeholder: "To",
		allowClear: true,
		ajax:{
			url: $("#APP_URL").val()+'/search-destination',
			type: "get",
			dataType: 'json',
			delay: 250,
			data: function (params) {
				return {
					searchTerm: params.term // search term
					};
				},
			processResults: function (response) {
				return {
					results: response
					};
				},
			cache: true
			}
		});
	$('.select_theme_type').select2({
		placeholder: "Theme",
		allowClear: true,
		ajax:{
			url: $("#APP_URL").val()+'/select_theme_type',
			type: "get",
			dataType: 'json',
			delay: 250,
			data: function (params) {
				return {
				searchTerm: params.term // search term
				};
			},
			processResults: function (response) {
				return {
					results: response
					};
				},
			cache: true
			}
		});
	})
//
$('#add_more').click(function(e){
	e.preventDefault()
	var name_count1=$(".add_dynamic").children("div:last").attr("id").slice(8)
	var name_count=parseInt(name_count1)-"1";
	name_count1++
	name_count++
	$(".add_dynamic").append('<div id="thirdrow'+name_count1+'"><div class="row"><div class="col-md-4"><div class="form-group"><label for="" class="required">Destination</label><select class="select_theme_add_destination form-control" name="dynamic['+name_count+'][destination]"></select></div></div><div class="col-md-4"><div class="form-group"><label for="" class="">Theme</label> <select class="select_theme_type form-control" name="dynamic['+name_count+'][theme]" >  </select></div></div><div class="col-md-3"><div class="form-group"><label for="" class="required">Link</label> <input type="text" name="dynamic['+name_count+'][link]" class="form-control" placeholder="Link"></div></div> <div class="col-md-1"><label for="" class="required" style="visibility:hidden">Share</label> <button type="button" name="remove" id="'+name_count1+'" class="btn btn-danger btn_remove_third" style="display:block">X </button></div> </div> </div>');
	//
	$('.select_theme_add_destination').select2({
		placeholder: "To",
		allowClear: true,
		ajax:{
			url: $("#APP_URL").val()+'/search-destination',
			type: "get",
			dataType: 'json',
			delay: 250,
			data: function (params) {
				return {
				searchTerm: params.term // search term
				};
			},
			processResults: function (response) {
				return {
					results: response
					};
				},
			cache: true
			}
		});
	//
	$('.select_theme_type').select2({
		placeholder: "Theme",
		allowClear: true,
		ajax:{
			url: $("#APP_URL").val()+'/select_theme_type',
			type: "get",
			dataType: 'json',
			delay: 250,
			data: function (params) {
				return {
					searchTerm: params.term // search term
					};
				},
			processResults: function (response) {
				return {
					results: response
					};
				},
				cache: true
			}
		});
	})
	$(document).on('click', '.btn_remove_third', function() {
		var button_id = $(this).attr("id");
		$('#thirdrow'+button_id+'').remove();
		});
</script>
@endsection