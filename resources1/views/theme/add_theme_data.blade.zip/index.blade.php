@extends('layouts.master')
@section('content')
<div class="content-wrapper">
<section class="content">
	<div class="row">
		<div class="col-md-12">
			<div class="box">
				<div class="box-header">
					<h3 class="box-title">Tour Theme</h3>
				</div>
				<div class="box-body">
					<div class="alert alert-success success-contaier-parent-hotel" id="success-contaier-parent-hotel" style="display:none">
						<p>Theme Data Deleted Successfully.</p>
					</div>
					<div class="alert alert-danger error-contaier-parent-hotel" id="error-contaier-parent-hotel" style="display:none">
						<ul class="error-contaier-hotel" id="error-contaier-hotel"> </ul>
					</div>
					<table id="example1" class="example1 table table-bordered table-striped">
						@if(Sentinel::check())
						@if(Sentinel::getUser()->inRole('administrator') || Sentinel::getUser()->inRole('supervisor') || Sentinel::getUser()->inRole('super_admin'))
						<div class="add">
							<a href="{{URL::to('/add_theme_data')}}" class="btn btn-success"><i class="glyphicon glyphicon-plus-sign"></i> Add New Theme</a>
						</div>
						@endif
						@endif
						<thead>
							<tr>
								<th>S.No.</th>
								<th>Theme</th>
								<th>Image</th>
								<th>Paragraph 1</th>
								<th>Paragraph 2</th>
								<th>About(Front End)</th>
								<th>Title(SEO)</th>
								<th>Key(SEO)</th>
								<th>Description(SEO)</th>
								<th>Actions</th>
							</tr>
						</thead>
						<tbody>
						<?php $i="1"; ?>
						@forelse($data as $single)
						<tr>
							<td>{{$i++}}</td>
							<td>{{ $single->theme_name }}</td>
							<td>
								@if($single->theme_image=="")
								@php  $image="noimage.jpg";  @endphp
								@else
								@php  $image=$single->theme_image;  @endphp
								@endif
								<img src="{{URL::to('/').'/public/uploads/theme/'.$image}}" width="50" height="50">
							</td>
							<td>{{ $single->theme_para1 }}</td>
							<td>{{ $single->theme_para2 }}</td>
							<td>{!! substr($single->about_theme,0,10) !!} @if(strlen($single->about_theme)>30) ... @endif</td>
							<td>{{ $single->title }}</td>
							<td>{{ $single->theme_key }}</td>
							<td>{{ substr($single->theme_desc,0,10) }} @if(strlen($single->theme_desc)>30) ... @endif</td>
							<td>
								<form action="{{URL::to('/delete_theme_data/'.$single->id)}}" onsubmit="return confirm('Do you really want to delete this.?');" method="post">
									<span class="btn-group">
									{{csrf_field()}}
									<input type="hidden" name="id" value=""/>
										<a class="btn btn-default btn-xcrud btn btn-warning" href="{{ URL::to('/edit_theme_data/'.$single->id) }}">Edit</a>
									@if(Sentinel::check())
									@if(Sentinel::getUser()->inRole('administrator') || Sentinel::getUser()->inRole('super_admin'))
										<button type="submit" class="btn btn-danger deletePackage" > Delete</button>
									@endif
									@endif
									</span>
								</form>
							</td>
						</tr>
						@empty
						<tr>
							<th colspan="9" class="text-center text-danger">Theme not available</th>
						</tr>
						@endforelse
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>
</div>
@endsection